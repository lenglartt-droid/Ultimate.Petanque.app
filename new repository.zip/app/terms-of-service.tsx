export { default } from './terms';
