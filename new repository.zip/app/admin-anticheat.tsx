import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, Pressable, StyleSheet, ActivityIndicator,
  TextInput, RefreshControl, Modal, Share,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { router, useLocalSearchParams } from 'expo-router';

import * as Haptics from '@/services/haptics';
import theme from '@/constants/theme';
import AdminQuickNav from '@/components/feature/AdminQuickNav';
import AdminGuard from '@/components/feature/AdminGuard';
import MiniTravelMap from '@/components/feature/MiniTravelMap';
import PageErrorBoundary from '@/components/ui/PageErrorBoundary';
import { useLanguage } from '@/hooks/useLanguage';
import { useAuth, useAlert, getSupabaseClient } from '@/template';
import {
  fetchSuspiciousPlayers, updateSuspiciousStatus, updateTrustScore,
  getTrustScoreColor, getTrustScoreIcon, getTrustLevelLabel, getLevelFromScore,
  banPlayer, fetchDeletionAlerts, DeletionAlert,
  reverseDeletedEloLoss, fetchDeletionTimeline, DeletionTimelinePoint,
} from '@/services/trustScoreService';
import { fetchDeviceRegistrations, adminUnlinkDevice, adminUnlinkAllForDevice } from '@/services/deviceFingerprintService';
import { fetchPendingTransferRequests, validateTransferRequest, rejectTransferRequest, DeviceTransferRequest } from '@/services/deviceTransferService';
import { extraTranslations } from '@/constants/i18nExtra';
import { recalculateAllElo, ELO_RANKS, getEloRank, ELO_INITIAL, applyInactivityDecay } from '@/services/eloService';
import { useAdminCache } from '@/hooks/useAdminCache';

const et = extraTranslations.trustScore;

type StatusFilter = 'all' | 'flagged' | 'watch' | 'ok' | 'dismissed' | 'banned' | 'geoAlerts' | 'temporalAlerts' | 'behavioralAlerts' | 'statisticalAlerts' | 'identityAlerts' | 'socialAlerts';
type TrustScoreFilter = 'all' | 'critical' | 'low' | 'medium' | 'high' | 'verified';
type SortMode = 'default' | 'trustAsc' | 'trustDesc' | 'analysisRecent' | 'analysisOld' | 'nocturnalDesc' | 'unrealisticDurationDesc' | 'massSubmissionDesc' | 'selfMatchDesc' | 'symmetricStreakDesc' | 'ghostRatioDesc';

const GEO_ALERT_FLAGS = new Set<string>([
  'impossible_travel',
  'impossible_travel_repeated',
  'micro_teleportation',
  'distant_from_home_city',
  'frequent_distant_from_home_city',
]);

const TEMPORAL_ALERT_FLAGS = new Set<string>([
  'unrealistic_duration',
  'unrealistic_duration_frequent',
  'nocturnal_pattern',
  'mass_submission',
  'mass_submission_repeated',
]);

const BEHAVIORAL_ALERT_FLAGS = new Set<string>([
  'self_match',
  'self_match_frequent',
  'symmetric_score_streak',
  'symmetric_score_streak_extreme',
  'ghost_opponents',
  'ghost_opponents_dominant',
]);

const STATISTICAL_ALERT_FLAGS = new Set<string>([
  'artificial_progression',
  'suspiciously_linear_elo',
  'benford_deviation',
  'benford_deviation_severe',
]);

const IDENTITY_ALERT_FLAGS = new Set<string>([
  'shared_fingerprint_recent',
  'shared_fingerprint_recent_multi',
  'email_farm',
]);

const SOCIAL_ALERT_FLAGS = new Set<string>([
  'witness_reputation_biased',
  'witness_reputation_extreme',
]);

const TRUST_SCORE_RANGES: Record<Exclude<TrustScoreFilter, 'all'>, { min: number; max: number; color: string }> = {
  critical: { min: 0, max: 24, color: '#EF4444' },
  low: { min: 25, max: 44, color: '#F97316' },
  medium: { min: 45, max: 64, color: '#D97706' },
  high: { min: 65, max: 79, color: '#3B82F6' },
  verified: { min: 80, max: 100, color: '#22C55E' },
};

export default function AdminAntiCheatScreen() {
  const insets = useSafeAreaInsets();
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const { showAlert } = useAlert();
  const isFr = language === 'fr';
  const adminCache = useAdminCache();
  const params = useLocalSearchParams<{ playerId?: string }>();

  const [players, setPlayers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [trustScoreFilter, setTrustScoreFilter] = useState<TrustScoreFilter>('all');
  const [sortMode, setSortMode] = useState<SortMode>('default');
  const [search, setSearch] = useState('');
  const [bulkBusy, setBulkBusy] = useState(false);
  const [resettingCooldownId, setResettingCooldownId] = useState<string | null>(null);

  // ELO recalculation
  const [recalculating, setRecalculating] = useState(false);

  // ELO dashboard
  const [eloDashboard, setEloDashboard] = useState<{
    totalPlayers: number;
    distribution: { tier: string; count: number; color: string; label: string }[];
    avgElo: number;
    decayCount: number;
    topPlayer: { name: string; elo: number } | null;
  } | null>(null);
  const [eloLoading, setEloLoading] = useState(true);
  const [applyingDecay, setApplyingDecay] = useState(false);

  // Deletion alerts
  const [deletionAlerts, setDeletionAlerts] = useState<DeletionAlert[]>([]);
  const [deletionAlertsLoading, setDeletionAlertsLoading] = useState(true);

  // Detail modal
  const [selectedPlayer, setSelectedPlayer] = useState<any | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [savingNotes, setSavingNotes] = useState(false);
  const [adjustScore, setAdjustScore] = useState('');
  const [showAdjustModal, setShowAdjustModal] = useState(false);

  // Deletion timeline & ELO reversal
  const [deletionTimeline, setDeletionTimeline] = useState<DeletionTimelinePoint[]>([]);
  const [timelineLoading, setTimelineLoading] = useState(false);
  const [reversingElo, setReversingElo] = useState(false);

  // Terrain coordinates for MiniTravelMap in geo alert pairs (keyed by matchId)
  const [pairCoordsMap, setPairCoordsMap] = useState<Map<string, { lat: number; lng: number }>>(new Map());

  // Bulk ELO reversal
  const [bulkReversing, setBulkReversing] = useState(false);

  // Deletion heatmap (day x hour) for detail modal
  const [deletionHeatmap, setDeletionHeatmap] = useState<number[][]>([]);

  // Device registrations management
  const [deviceRegs, setDeviceRegs] = useState<Array<{ id: string; fingerprint: string; email: string; userId: string | null; registeredAt: string; ipHint: string | null }>>([]);
  const [deviceRegsLoading, setDeviceRegsLoading] = useState(false);
  const [deviceRegsLoaded, setDeviceRegsLoaded] = useState(false);
  const [deviceSearch, setDeviceSearch] = useState('');
  const [unlinkingId, setUnlinkingId] = useState<string | null>(null);

  // Device transfer requests
  const [transferRequests, setTransferRequests] = useState<DeviceTransferRequest[]>([]);
  const [transferLoading, setTransferLoading] = useState(false);

  // Anti-cheat weekly analytics
  const [weeklyAnalytics, setWeeklyAnalytics] = useState<Array<{ week: string; blocked: number; registrations: number; multiAccount: number }>>([]);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);

  // Temporal alert trends (last 8 weeks): nocturnal matches, unrealistic durations, mass submission days
  const [temporalTrends, setTemporalTrends] = useState<Array<{ week: string; nocturnal: number; unrealistic: number; massSub: number }>>([]);
  const [temporalTrendsLoading, setTemporalTrendsLoading] = useState(false);

  // Behavioral alert trends (last 8 weeks): self-matches, symmetric-score matches, ghost proxy (solo matches)
  const [behavioralTrends, setBehavioralTrends] = useState<Array<{ week: string; selfMatch: number; symmetric: number; ghost: number }>>([]);
  const [behavioralTrendsLoading, setBehavioralTrendsLoading] = useState(false);

  // Bulk ban undo (10s window)
  const [undoBan, setUndoBan] = useState<{ targets: Array<{ id: string; prevStatus: string; prevTrustScore: number }>; expiresAt: number; label: string } | null>(null);
  const [undoRemaining, setUndoRemaining] = useState<number>(0);

  // Ban reason selector (prompted before executing bulk ban)
  const [banReasonPrompt, setBanReasonPrompt] = useState<{
    targets: Array<{ id: string; playerId?: string; playerName?: string; status: string; trustScore: number }>;
    kind: 'filtered' | 'behavioral';
  } | null>(null);
  const [selectedBanReason, setSelectedBanReason] = useState<'cheat' | 'spam' | 'harassment' | 'other'>('cheat');

  // Statistical detail modal (Benford + ELO regression visualization)
  const [showStatModal, setShowStatModal] = useState(false);
  const [statEloHistory, setStatEloHistory] = useState<Array<{ delta: number; recordedAt: string }>>([]);
  const [statHistLoading, setStatHistLoading] = useState(false);

  // Email farm cluster bulk ban
  const [emailFarmBusy, setEmailFarmBusy] = useState(false);

  // Email farm cluster registration timeline (fetched on demand)
  const [farmClusterTimeline, setFarmClusterTimeline] = useState<Array<{ email: string; ts: number; offsetHours: number; isCurrentUser: boolean }>>([]);

  // Admin behavioral digest history (last 30 entries, all players)
  const [adminDigestHistory, setAdminDigestHistory] = useState<Array<{
    id: string;
    userId: string;
    userName: string;
    playerId: string | null;
    playerName: string | null;
    flags: string[];
    alertSummary: string;
    sentAt: string;
    isResolved: boolean;
    resolvedAt: string | null;
  }>>([]);
  const [adminDigestLoading, setAdminDigestLoading] = useState(false);
  const [adminDigestLoaded, setAdminDigestLoaded] = useState(false);
  const [adminDigestSearch, setAdminDigestSearch] = useState('');

  const loadData = useCallback(async () => {
    setLoading(true);
    const cached = adminCache.getCached<any[]>('anticheat-players');
    if (cached) {
      setPlayers(cached);
      setLoading(false);
      // Background refresh
      fetchSuspiciousPlayers().then(({ players: p }) => {
        setPlayers(p);
        adminCache.setCached('anticheat-players', p, 30000);
      });
      return;
    }
    const { players: p, error } = await fetchSuspiciousPlayers();
    if (error) showAlert((et.adminTitle as any)?.[language] || 'Error', error);
    setPlayers(p);
    adminCache.setCached('anticheat-players', p, 30000);
    setLoading(false);
  }, [language]);

  useEffect(() => { loadData(); }, [loadData]);

  // Deep link: open detail modal when playerId is provided via URL params
  useEffect(() => {
    if (!params.playerId || players.length === 0 || selectedPlayer) return;
    const target = players.find(p => p.playerId === params.playerId);
    if (target) {
      setSelectedPlayer(target);
      setAdminNotes(target.adminNotes || '');
    }
  }, [params.playerId, players.length]);

  // Countdown timer for undo-ban toast
  useEffect(() => {
    if (!undoBan) { setUndoRemaining(0); return; }
    const tick = () => {
      const remaining = Math.max(0, Math.ceil((undoBan.expiresAt - Date.now()) / 1000));
      setUndoRemaining(remaining);
      if (remaining <= 0) setUndoBan(null);
    };
    tick();
    const timer = setInterval(tick, 250);
    return () => clearInterval(timer);
  }, [undoBan]);

  // Fetch terrain coords for pair match IDs when a player is selected
  useEffect(() => {
    if (!selectedPlayer) { setPairCoordsMap(new Map()); return; }
    // Only fetch coords for pairs that don't already embed them (backward compat)
    const collectMatchIds = (pairs: any[] | undefined): string[] => {
      if (!Array.isArray(pairs)) return [];
      const ids: string[] = [];
      for (const p of pairs) {
        const hasA = Number.isFinite(p?.latA) && Number.isFinite(p?.lngA);
        const hasB = Number.isFinite(p?.latB) && Number.isFinite(p?.lngB);
        if (hasA && hasB) continue;
        if (!hasA && p?.matchAId) ids.push(p.matchAId);
        if (!hasB && p?.matchBId) ids.push(p.matchBId);
      }
      return ids;
    };
    const allIds = Array.from(new Set<string>([
      ...collectMatchIds(selectedPlayer.details?.impossibleTravel?.pairs),
      ...collectMatchIds(selectedPlayer.details?.microTeleportation?.pairs),
    ]));
    if (allIds.length === 0) return;
    let cancelled = false;
    (async () => {
      try {
        const supabase = getSupabaseClient();
        const { data: matchData } = await supabase.from('matches').select('id, terrain_id').in('id', allIds);
        if (cancelled) return;
        const terrainIds = Array.from(new Set((matchData || []).map((m: any) => m.terrain_id).filter(Boolean))) as string[];
        if (terrainIds.length === 0) return;
        const { data: terrainsData } = await supabase.from('terrains').select('id, location').in('id', terrainIds);
        if (cancelled) return;
        const terrainCoords = new Map<string, { lat: number; lng: number }>();
        for (const t of terrainsData || []) {
          const tlat = t.location?.latitude;
          const tlng = t.location?.longitude;
          if (Number.isFinite(tlat) && Number.isFinite(tlng)) terrainCoords.set(t.id, { lat: tlat, lng: tlng });
        }
        const matchCoords = new Map<string, { lat: number; lng: number }>();
        for (const m of matchData || []) {
          const tc = m.terrain_id ? terrainCoords.get(m.terrain_id) : null;
          if (tc) matchCoords.set(m.id, tc);
        }
        if (!cancelled) setPairCoordsMap(matchCoords);
      } catch { /* silent */ }
    })();
    return () => { cancelled = true; };
  }, [selectedPlayer?.id]);

  // Fetch registration timestamps for the email farm cluster of the selected player.
  useEffect(() => {
    const emailFarm = selectedPlayer?.details?.emailFarm;
    const siblings: string[] = Array.isArray(emailFarm?.siblings) ? emailFarm.siblings : [];
    if (!emailFarm || siblings.length < 2 || !selectedPlayer?.userId) {
      setFarmClusterTimeline([]);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const supabase = getSupabaseClient();
        const [regRes, profRes] = await Promise.all([
          supabase.from('device_registrations').select('email, registered_at').in('email', siblings),
          supabase.from('user_profiles').select('email').eq('id', selectedPlayer.userId).single(),
        ]);
        if (cancelled) return;
        const data = regRes.data;
        const currentEmail = String((profRes.data as any)?.email || '').toLowerCase();
        if (!data || data.length === 0) { setFarmClusterTimeline([]); return; }
        const emailMap = new Map<string, number>();
        for (const r of data) {
          if (!r.email || !r.registered_at) continue;
          const ts = new Date(r.registered_at).getTime();
          if (!Number.isFinite(ts)) continue;
          const emailLower = String(r.email).toLowerCase();
          if (!emailMap.has(emailLower) || ts < emailMap.get(emailLower)!) {
            emailMap.set(emailLower, ts);
          }
        }
        const entries = Array.from(emailMap.entries()).sort((a, b) => a[1] - b[1]);
        if (entries.length === 0) { setFarmClusterTimeline([]); return; }
        const minTs = entries[0][1];
        setFarmClusterTimeline(entries.map(([email, ts]) => ({
          email,
          ts,
          offsetHours: (ts - minTs) / (1000 * 60 * 60),
          isCurrentUser: email === currentEmail,
        })));
      } catch { /* silent */ }
    })();
    return () => { cancelled = true; };
  }, [selectedPlayer?.id, selectedPlayer?.userId, selectedPlayer?.details?.emailFarm?.siblings?.length]);

  // Load deletion alerts
  useEffect(() => {
    (async () => {
      setDeletionAlertsLoading(true);
      const { alerts } = await fetchDeletionAlerts();
      setDeletionAlerts(alerts);
      setDeletionAlertsLoading(false);
    })();
  }, [players]);

  // Load ELO dashboard
  useEffect(() => {
    (async () => {
      setEloLoading(true);
      try {
        const supabase = getSupabaseClient();
        const { data: allPlayers } = await supabase
          .from('players')
          .select('id, name, elo_rating, last_match_date');
        if (allPlayers && allPlayers.length > 0) {
          const dist = ELO_RANKS.map(rank => {
            const nextRank = ELO_RANKS[ELO_RANKS.indexOf(rank) - 1];
            const max = nextRank ? nextRank.minElo : Infinity;
            const count = allPlayers.filter(p => {
              const elo = p.elo_rating || ELO_INITIAL;
              return elo >= rank.minElo && elo < max;
            }).length;
            return { tier: rank.tier, count, color: rank.color, label: rank.label[isFr ? 'fr' : 'en'] };
          }).reverse();
          const totalElo = allPlayers.reduce((s, p) => s + (p.elo_rating || ELO_INITIAL), 0);
          const avgElo = Math.round(totalElo / allPlayers.length);
          const cutoff = new Date();
          cutoff.setDate(cutoff.getDate() - 30);
          const decayCount = allPlayers.filter(p => p.last_match_date && new Date(p.last_match_date) < cutoff && (p.elo_rating || ELO_INITIAL) > 800).length;
          const top = allPlayers.reduce((best, p) => (p.elo_rating || 0) > (best?.elo_rating || 0) ? p : best, allPlayers[0]);
          setEloDashboard({
            totalPlayers: allPlayers.length,
            distribution: dist,
            avgElo,
            decayCount,
            topPlayer: top ? { name: top.name, elo: top.elo_rating || ELO_INITIAL } : null,
          });
        }
      } catch { }
      setEloLoading(false);
    })();
  }, [isFr]);

  // Auto-load lightweight collapsible sections once players are ready
  useEffect(() => {
    if (loading || players.length === 0) return;
    let cancelled = false;
    (async () => {
      try {
        if (!deviceRegsLoaded) {
          setDeviceRegsLoading(true);
          const { registrations } = await fetchDeviceRegistrations();
          if (!cancelled) { setDeviceRegs(registrations); setDeviceRegsLoaded(true); }
          if (!cancelled) setDeviceRegsLoading(false);
        }
        if (!cancelled && transferRequests.length === 0) {
          setTransferLoading(true);
          const { requests } = await fetchPendingTransferRequests();
          if (!cancelled) { setTransferRequests(requests); setTransferLoading(false); }
        }
      } catch { if (!cancelled) { setDeviceRegsLoading(false); setTransferLoading(false); } }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, players.length]);

  // Summary statistics
  const summaryStats = React.useMemo(() => {
    if (players.length === 0) return { total: 0, avg: 0, verified: 0, high: 0, medium: 0, low: 0, suspicious: 0, weeklyFlagged: 0 };
    const total = players.length;
    const avg = Math.round(players.reduce((s, p) => s + p.trustScore, 0) / total);
    let verified = 0, high = 0, medium = 0, low = 0, suspicious = 0;
    players.forEach(p => {
      const ts = p.trustScore;
      if (ts >= 80) verified++;
      else if (ts >= 65) high++;
      else if (ts >= 45) medium++;
      else if (ts >= 25) low++;
      else suspicious++;
    });
    // Weekly flagged: players analyzed in the last 7 days with flags
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const weeklyFlagged = players.filter(p => {
      if (p.flags.length === 0) return false;
      return p.analyzedAt ? new Date(p.analyzedAt) > oneWeekAgo : false;
    }).length;
    return { total, avg, verified, high, medium, low, suspicious, weeklyFlagged };
  }, [players]);

  const handleBatchDismissOk = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const okPlayers = players.filter(p => p.status === 'ok' && p.flags.length === 0);
    if (okPlayers.length === 0) return;
    for (const p of okPlayers) {
      await updateSuspiciousStatus(p.id, 'dismissed');
    }
    setPlayers(prev => prev.map(p => (p.status === 'ok' && p.flags.length === 0) ? { ...p, status: 'dismissed' } : p));
    showAlert(isFr ? `${okPlayers.length} joueurs ignores` : `${okPlayers.length} players dismissed`);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const handleRunFullScan = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    setScanning(true);
    try {
      const supabase = getSupabaseClient();
      await supabase.functions.invoke('detect-suspicious', { body: { mode: 'full', force: true } });
      setTimeout(async () => {
        await loadData();
        setScanning(false);
        showAlert((et.adminScanComplete as any)?.[language] || 'Done');
      }, 3000);
    } catch (e: any) {
      setScanning(false);
      showAlert('Error', e.message);
    }
  };

  const handleUpdateStatus = async (id: string, status: string) => {
    Haptics.selectionAsync();
    if (status === 'banned') {
      // Ban enforcement: set trust score to 0 and status to banned
      const player = players.find(p => p.id === id);
      const { error } = await banPlayer(id, player?.playerId || '');
      if (error) { showAlert('Error', error); return; }
      setPlayers(prev => prev.map(p => p.id === id ? { ...p, status: 'banned', trustScore: 0 } : p));
      if (selectedPlayer?.id === id) setSelectedPlayer((prev: any) => prev ? { ...prev, status: 'banned', trustScore: 0 } : prev);
    } else {
      const { error } = await updateSuspiciousStatus(id, status);
      if (error) { showAlert('Error', error); return; }
      setPlayers(prev => prev.map(p => p.id === id ? { ...p, status } : p));
      if (selectedPlayer?.id === id) setSelectedPlayer((prev: any) => prev ? { ...prev, status } : prev);
    }
  };

  const handleSaveNotes = async () => {
    if (!selectedPlayer) return;
    setSavingNotes(true);
    const { error } = await updateSuspiciousStatus(selectedPlayer.id, selectedPlayer.status, adminNotes);
    setSavingNotes(false);
    if (error) { showAlert('Error', error); return; }
    setPlayers(prev => prev.map(p => p.id === selectedPlayer.id ? { ...p, adminNotes } : p));
    setSelectedPlayer((prev: any) => prev ? { ...prev, adminNotes } : prev);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleAdjustScore = async () => {
    if (!selectedPlayer || !adjustScore) return;
    const newScore = parseInt(adjustScore);
    if (isNaN(newScore) || newScore < 0 || newScore > 100) {
      showAlert('Error', 'Score must be 0-100');
      return;
    }
    const { error } = await updateTrustScore(selectedPlayer.id, newScore);
    if (error) { showAlert('Error', error); return; }
    setPlayers(prev => prev.map(p => p.id === selectedPlayer.id ? { ...p, trustScore: newScore } : p));
    setSelectedPlayer((prev: any) => prev ? { ...prev, trustScore: newScore } : prev);
    setShowAdjustModal(false);
    setAdjustScore('');
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const filtered = players.filter(p => {
    if (statusFilter === 'geoAlerts') {
      if (!Array.isArray(p.flags) || !p.flags.some((f: string) => GEO_ALERT_FLAGS.has(f))) return false;
    } else if (statusFilter === 'temporalAlerts') {
      if (!Array.isArray(p.flags) || !p.flags.some((f: string) => TEMPORAL_ALERT_FLAGS.has(f))) return false;
    } else if (statusFilter === 'behavioralAlerts') {
      if (!Array.isArray(p.flags) || !p.flags.some((f: string) => BEHAVIORAL_ALERT_FLAGS.has(f))) return false;
    } else if (statusFilter === 'statisticalAlerts') {
      if (!Array.isArray(p.flags) || !p.flags.some((f: string) => STATISTICAL_ALERT_FLAGS.has(f))) return false;
    } else if (statusFilter === 'identityAlerts') {
      if (!Array.isArray(p.flags) || !p.flags.some((f: string) => IDENTITY_ALERT_FLAGS.has(f))) return false;
    } else if (statusFilter === 'socialAlerts') {
      if (!Array.isArray(p.flags) || !p.flags.some((f: string) => SOCIAL_ALERT_FLAGS.has(f))) return false;
    } else if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (trustScoreFilter !== 'all') {
      const range = TRUST_SCORE_RANGES[trustScoreFilter];
      if (p.trustScore < range.min || p.trustScore > range.max) return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      if (!(p.playerName || '').toLowerCase().includes(q) && !p.playerId.includes(q)) return false;
    }
    return true;
  }).sort((a, b) => {
    switch (sortMode) {
      case 'trustAsc': return (a.trustScore ?? 0) - (b.trustScore ?? 0);
      case 'trustDesc': return (b.trustScore ?? 0) - (a.trustScore ?? 0);
      case 'analysisRecent': {
        const aTime = a.analyzedAt ? new Date(a.analyzedAt).getTime() : 0;
        const bTime = b.analyzedAt ? new Date(b.analyzedAt).getTime() : 0;
        return bTime - aTime;
      }
      case 'analysisOld': {
        const aTime = a.analyzedAt ? new Date(a.analyzedAt).getTime() : 0;
        const bTime = b.analyzedAt ? new Date(b.analyzedAt).getTime() : 0;
        return aTime - bTime;
      }
      case 'nocturnalDesc': return ((b.details?.nocturnalActivity?.count || 0) - (a.details?.nocturnalActivity?.count || 0));
      case 'unrealisticDurationDesc': return ((b.details?.unrealisticDuration?.count || 0) - (a.details?.unrealisticDuration?.count || 0));
      case 'massSubmissionDesc': return ((b.details?.massSubmission?.daysCount || 0) - (a.details?.massSubmission?.daysCount || 0));
      case 'selfMatchDesc': return ((b.details?.selfMatches?.count || 0) - (a.details?.selfMatches?.count || 0));
      case 'symmetricStreakDesc': return ((b.details?.symmetricScores?.maxConsecutiveStreak || 0) - (a.details?.symmetricScores?.maxConsecutiveStreak || 0));
      case 'ghostRatioDesc': return ((b.details?.ghostOpponents?.ratio || 0) - (a.details?.ghostOpponents?.ratio || 0));
      default: return 0;
    }
  });

  const statusCounts = {
    all: players.length,
    flagged: players.filter(p => p.status === 'flagged').length,
    watch: players.filter(p => p.status === 'watch').length,
    ok: players.filter(p => p.status === 'ok').length,
    dismissed: players.filter(p => p.status === 'dismissed').length,
    banned: players.filter(p => p.status === 'banned').length,
    geoAlerts: players.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => GEO_ALERT_FLAGS.has(f))).length,
    temporalAlerts: players.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => TEMPORAL_ALERT_FLAGS.has(f))).length,
    behavioralAlerts: players.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => BEHAVIORAL_ALERT_FLAGS.has(f))).length,
    statisticalAlerts: players.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => STATISTICAL_ALERT_FLAGS.has(f))).length,
    identityAlerts: players.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => IDENTITY_ALERT_FLAGS.has(f))).length,
    socialAlerts: players.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => SOCIAL_ALERT_FLAGS.has(f))).length,
  };

  const trustScoreCounts = {
    all: players.length,
    critical: players.filter(p => p.trustScore <= 24).length,
    low: players.filter(p => p.trustScore >= 25 && p.trustScore <= 44).length,
    medium: players.filter(p => p.trustScore >= 45 && p.trustScore <= 64).length,
    high: players.filter(p => p.trustScore >= 65 && p.trustScore <= 79).length,
    verified: players.filter(p => p.trustScore >= 80).length,
  };

  const getTrustScoreLabel = (tf: TrustScoreFilter) => {
    if (tf === 'all') return isFr ? 'Tous' : 'All';
    if (tf === 'critical') return '0-24';
    if (tf === 'low') return '25-44';
    if (tf === 'medium') return '45-64';
    if (tf === 'high') return '65-79';
    if (tf === 'verified') return '80+';
    return tf;
  };



  const getStatusColor = (status: string) => {
    switch (status) {
      case 'flagged': return '#EF4444';
      case 'watch': return '#F97316';
      case 'ok': return '#22C55E';
      case 'dismissed': return '#6B7280';
      case 'banned': return '#DC2626';
      case 'geoAlerts': return '#F59E0B';
      case 'temporalAlerts': return '#8B5CF6';
      case 'behavioralAlerts': return '#EC4899';
      case 'statisticalAlerts': return '#0EA5E9';
      case 'identityAlerts': return '#DC2626';
      case 'socialAlerts': return '#F59E0B';
      default: return theme.textMuted;
    }
  };

  const getStatusLabel = (status: string) => {
    if (status === 'geoAlerts') return isFr ? 'Geo-alertes' : 'Geo alerts';
    if (status === 'temporalAlerts') return isFr ? 'Alertes temporelles' : 'Temporal alerts';
    if (status === 'behavioralAlerts') return isFr ? 'Comportement' : 'Behavioral';
    if (status === 'statisticalAlerts') return isFr ? 'Statistiques' : 'Statistical';
    if (status === 'identityAlerts') return isFr ? 'Identite' : 'Identity';
    if (status === 'socialAlerts') return isFr ? 'Social' : 'Social';
    const labels: Record<string, any> = {
      ok: et.adminStatusOk, watch: et.adminStatusWatch,
      flagged: et.adminStatusFlagged, banned: et.adminStatusBanned,
      dismissed: et.adminStatusDismissed,
    };
    return (labels[status] as any)?.[language] || status;
  };

  // Bulk actions applied to the currently filtered set
  const handleBulkDismissFiltered = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const targets = filtered.filter(p => p.status !== 'dismissed' && p.status !== 'banned');
    if (targets.length === 0) {
      showAlert(isFr ? 'Aucun joueur a ignorer' : 'No players to dismiss');
      return;
    }
    showAlert(
      isFr ? `Ignorer ${targets.length} joueur(s) ?` : `Dismiss ${targets.length} player(s)?`,
      isFr ? 'Applique aux resultats filtres.' : 'Applied to the current filtered results.',
      [
        { text: isFr ? 'Annuler' : 'Cancel', style: 'cancel' },
        {
          text: isFr ? 'Ignorer tout' : 'Dismiss all',
          onPress: async () => {
            setBulkBusy(true);
            let ok = 0;
            for (const p of targets) {
              const { error } = await updateSuspiciousStatus(p.id, 'dismissed');
              if (!error) ok++;
            }
            const ids = new Set(targets.map(t => t.id));
            setPlayers(prev => prev.map(p => ids.has(p.id) ? { ...p, status: 'dismissed' } : p));
            setBulkBusy(false);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            showAlert(isFr ? `${ok} joueur(s) ignore(s)` : `${ok} player(s) dismissed`);
          },
        },
      ]
    );
  };

  const handleBulkBanFiltered = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    const targets = filtered.filter(p => p.status !== 'banned');
    if (targets.length === 0) {
      showAlert(isFr ? 'Aucun joueur a bannir' : 'No players to ban');
      return;
    }
    setSelectedBanReason('cheat');
    setBanReasonPrompt({
      targets: targets.map(t => ({ id: t.id, playerId: t.playerId, playerName: t.playerName, status: t.status, trustScore: t.trustScore })),
      kind: 'filtered',
    });
  };

  const handleBulkTemporalNotify = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const targets = filtered.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => TEMPORAL_ALERT_FLAGS.has(f)));
    if (targets.length === 0) {
      showAlert(isFr ? 'Aucun joueur cible' : 'No targets');
      return;
    }
    showAlert(
      isFr ? `Envoyer un rappel a ${targets.length} joueur(s) ?` : `Send reminder to ${targets.length} player(s)?`,
      isFr ? 'Un push regroupe les alertes temporelles actives.' : 'A single push groups active temporal alerts.',
      [
        { text: isFr ? 'Annuler' : 'Cancel', style: 'cancel' },
        {
          text: isFr ? 'Envoyer' : 'Send',
          onPress: async () => {
            setBulkBusy(true);
            const supabase = getSupabaseClient();
            let sent = 0;
            try {
              const userIds = targets.map(t => t.userId);
              const { data: tokens } = await supabase
                .from('push_tokens')
                .select('user_id, token')
                .in('user_id', userIds)
                .eq('active', true);
              const tokenList = (tokens || []).map((t: any) => ({
                to: t.token,
                title: isFr ? 'Verifiez vos matchs' : 'Check your matches',
                body: isFr ? 'Des alertes temporelles ont ete detectees sur vos matchs recents.' : 'Temporal alerts detected on your recent matches.',
                data: { type: 'temporal_alert', bulk: true },
                channelId: 'tournament-reminders',
                priority: 'high',
              }));
              sent = tokenList.length;
              if (tokenList.length > 0) {
                await fetch('https://exp.host/--/api/v2/push/send', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                  body: JSON.stringify(tokenList),
                });
              }
            } catch { /* silent */ }
            setBulkBusy(false);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            showAlert(isFr ? `${sent} rappel(s) envoye(s)` : `${sent} reminder(s) sent`);
          },
        },
      ]
    );
  };

  // Bulk behavioral notify handler (sends a push reminder to all filtered players with behavioral alerts)
  const handleBulkBehavioralNotify = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const targets = filtered.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => BEHAVIORAL_ALERT_FLAGS.has(f)));
    if (targets.length === 0) {
      showAlert(isFr ? 'Aucun joueur cible' : 'No targets');
      return;
    }
    showAlert(
      isFr ? `Envoyer un rappel a ${targets.length} joueur(s) ?` : `Send reminder to ${targets.length} player(s)?`,
      isFr ? 'Un push regroupe les alertes comportementales actives.' : 'A single push groups active behavioral alerts.',
      [
        { text: isFr ? 'Annuler' : 'Cancel', style: 'cancel' },
        {
          text: isFr ? 'Envoyer' : 'Send',
          onPress: async () => {
            setBulkBusy(true);
            const supabase = getSupabaseClient();
            let sent = 0;
            try {
              const userIds = targets.map(t => t.userId);
              const { data: tokens } = await supabase
                .from('push_tokens')
                .select('user_id, token')
                .in('user_id', userIds)
                .eq('active', true);
              const tokenList = (tokens || []).map((t: any) => ({
                to: t.token,
                title: isFr ? 'Verifiez vos matchs' : 'Check your matches',
                body: isFr ? 'Des alertes comportementales ont ete detectees sur vos matchs recents.' : 'Behavioral alerts detected on your recent matches.',
                data: { type: 'behavioral_alert', bulk: true },
                channelId: 'tournament-reminders',
                priority: 'high',
              }));
              sent = tokenList.length;
              if (tokenList.length > 0) {
                await fetch('https://exp.host/--/api/v2/push/send', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                  body: JSON.stringify(tokenList),
                });
              }
            } catch { /* silent */ }
            setBulkBusy(false);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            showAlert(isFr ? `${sent} rappel(s) envoye(s)` : `${sent} reminder(s) sent`);
          },
        },
      ]
    );
  };

  // Bulk behavioral ban handler (bans all filtered players with behavioral alert flags)
  const handleBulkBanBehavioral = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    const targets = filtered.filter(p => Array.isArray(p.flags) && p.flags.some((f: string) => BEHAVIORAL_ALERT_FLAGS.has(f)) && p.status !== 'banned');
    if (targets.length === 0) {
      showAlert(isFr ? 'Aucun joueur a bannir' : 'No players to ban');
      return;
    }
    setSelectedBanReason('cheat');
    setBanReasonPrompt({
      targets: targets.map(t => ({ id: t.id, playerId: t.playerId, playerName: t.playerName, status: t.status, trustScore: t.trustScore })),
      kind: 'behavioral',
    });
  };

  // Confirm bulk ban with the selected reason - executes ban, logs to admin_activity_logs, and opens the undo toast
  const handleConfirmBanWithReason = async () => {
    if (!banReasonPrompt) return;
    const { targets, kind } = banReasonPrompt;
    const reason = selectedBanReason;
    setBanReasonPrompt(null);
    setBulkBusy(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    const snapshot: Array<{ id: string; prevStatus: string; prevTrustScore: number }> = [];
    let ok = 0;
    for (const p of targets) {
      snapshot.push({ id: p.id, prevStatus: p.status, prevTrustScore: p.trustScore });
      const { error } = await banPlayer(p.id, p.playerId || '');
      if (!error) ok++;
    }
    const ids = new Set(targets.map(t => t.id));
    setPlayers(prev => prev.map(p => ids.has(p.id) ? { ...p, status: 'banned', trustScore: 0 } : p));

    // Log to admin_activity_logs for traceability
    try {
      const supabase = getSupabaseClient();
      await supabase.from('admin_activity_logs').insert({
        admin_user_id: user?.id,
        admin_name: (user as any)?.username || user?.email || 'Admin',
        action_type: kind === 'behavioral' ? 'bulk_ban_behavioral' : 'bulk_ban_filtered',
        action_detail: `Reason: ${reason} | Banned: ${ok}/${targets.length} player(s)`,
        target_type: 'players',
        metadata: {
          reason,
          kind,
          bannedCount: ok,
          attemptedCount: targets.length,
          targetPreview: targets.slice(0, 20).map(t => ({ id: t.id, playerId: t.playerId, playerName: t.playerName })),
        },
      });
    } catch { /* silent */ }

    setBulkBusy(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    const kindLabel = kind === 'behavioral' ? (isFr ? ' comportemental(aux)' : ' behavioral') : '';
    const reasonLabel = isFr
      ? (reason === 'cheat' ? 'triche' : reason === 'spam' ? 'spam' : reason === 'harassment' ? 'harcelement' : 'autre')
      : reason;
    setUndoBan({
      targets: snapshot.slice(0, ok),
      expiresAt: Date.now() + 10_000,
      label: isFr ? `${ok} joueur(s)${kindLabel} banni(s) - ${reasonLabel}` : `${ok}${kindLabel} player(s) banned - ${reasonLabel}`,
    });
  };

  // Load ELO history for the currently selected player (for statistical detail modal)
  const loadStatEloHistory = async () => {
    if (!selectedPlayer?.playerId) return;
    setStatHistLoading(true);
    try {
      const supabase = getSupabaseClient();
      const { data } = await supabase
        .from('elo_history')
        .select('elo_delta, recorded_at')
        .eq('player_id', selectedPlayer.playerId)
        .order('recorded_at', { ascending: true })
        .limit(100);
      setStatEloHistory((data || []).map((d: any) => ({ delta: Number(d.elo_delta) || 0, recordedAt: d.recorded_at })));
    } catch { /* silent */ }
    setStatHistLoading(false);
  };

  // Bulk-ban every account tied to the selected player's email farm cluster
  // (same prefix + domain + 24h window). Logs action to admin_activity_logs.
  const handleBulkBanEmailFarmCluster = () => {
    if (!selectedPlayer?.details?.emailFarm) return;
    const emailFarm = selectedPlayer.details.emailFarm;
    const siblings: string[] = Array.isArray(emailFarm.siblings) ? emailFarm.siblings : [];
    if (siblings.length === 0) {
      showAlert(isFr ? 'Aucun compte a bannir' : 'No accounts to ban');
      return;
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    showAlert(
      isFr ? `Bannir tout le cluster (${siblings.length}) ?` : `Ban entire cluster (${siblings.length})?`,
      isFr
        ? `Prefixe "${emailFarm.prefix}" @${emailFarm.domain} en ${emailFarm.spanHours || 0}h`
        : `Prefix "${emailFarm.prefix}" @${emailFarm.domain} in ${emailFarm.spanHours || 0}h`,
      [
        { text: isFr ? 'Annuler' : 'Cancel', style: 'cancel' },
        {
          text: isFr ? 'Bannir tout le cluster' : 'Ban entire cluster',
          style: 'destructive',
          onPress: async () => {
            setEmailFarmBusy(true);
            try {
              const supabase = getSupabaseClient();
              const { data: profiles } = await supabase
                .from('user_profiles')
                .select('id, email')
                .in('email', siblings);
              const userIds = (profiles || []).map((p: any) => p.id);
              let banned = 0;
              if (userIds.length > 0) {
                const { data: clusterPlayers } = await supabase
                  .from('players')
                  .select('id, user_id')
                  .in('user_id', userIds);
                for (const pl of clusterPlayers || []) {
                  const existing = players.find(x => x.playerId === pl.id);
                  if (existing) {
                    const { error } = await banPlayer(existing.id, pl.id);
                    if (!error) banned++;
                  } else {
                    const { error } = await supabase
                      .from('suspicious_players')
                      .upsert({
                        player_id: pl.id,
                        user_id: pl.user_id,
                        trust_score: 0,
                        flags: ['email_farm'],
                        details: { emailFarm: { domain: emailFarm.domain, prefix: emailFarm.prefix } },
                        status: 'banned',
                        analyzed_at: new Date().toISOString(),
                        updated_at: new Date().toISOString(),
                      }, { onConflict: 'player_id' });
                    if (!error) banned++;
                  }
                }
              }
              await supabase.from('admin_activity_logs').insert({
                admin_user_id: user?.id,
                admin_name: (user as any)?.username || user?.email || 'Admin',
                action_type: 'bulk_ban_email_farm',
                action_detail: `Cluster ${emailFarm.prefix}@${emailFarm.domain}: ${banned}/${siblings.length} banned`,
                target_type: 'players',
                metadata: {
                  reason: 'email_farm',
                  domain: emailFarm.domain,
                  prefix: emailFarm.prefix,
                  clusterSize: siblings.length,
                  bannedCount: banned,
                  spanHours: emailFarm.spanHours || 0,
                  siblings: siblings.slice(0, 20),
                },
              });
              await loadData();
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              showAlert(isFr ? `${banned} compte(s) banni(s)` : `${banned} account(s) banned`);
            } catch (e: any) {
              showAlert('Error', e.message);
            }
            setEmailFarmBusy(false);
          },
        },
      ]
    );
  };

  // CSV export for admin behavioral digest history
  const handleExportDigestCSV = async () => {
    if (adminDigestHistory.length === 0) {
      showAlert(isFr ? 'Aucune donnee a exporter' : 'No data to export');
      return;
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const headers = ['ID', 'User', 'Player', 'Flags', 'Summary', 'Sent At', 'Resolved', 'Resolved At'];
    const rows = adminDigestHistory.map(h => [
      h.id,
      h.userName,
      h.playerName || '-',
      h.flags.join('|'),
      (h.alertSummary || '').replace(/"/g, "'").replace(/\n/g, ' '),
      h.sentAt,
      h.isResolved ? 'yes' : 'no',
      h.resolvedAt || '-',
    ]);
    const csv = [headers.join(','), ...rows.map(r => r.map(v => `"${v}"`).join(','))].join('\n');
    try {
      await Share.share({ message: csv, title: 'Behavioral Digest History Export' });
    } catch { /* silent */ }
  };

  // Load admin behavioral digest history (last 30 entries with user + player joins)
  const loadAdminDigestHistory = async () => {
    if (adminDigestLoaded) {
      setAdminDigestLoaded(false);
      setAdminDigestHistory([]);
      return;
    }
    setAdminDigestLoading(true);
    try {
      const supabase = getSupabaseClient();
      const { data: bdh } = await supabase
        .from('behavioral_digest_history')
        .select('id, user_id, player_id, flags, alert_summary, sent_at, is_resolved, resolved_at')
        .order('sent_at', { ascending: false })
        .limit(30);
      const userIds = Array.from(new Set((bdh || []).map((d: any) => d.user_id).filter(Boolean))) as string[];
      const playerIds = Array.from(new Set((bdh || []).map((d: any) => d.player_id).filter(Boolean))) as string[];
      const [usersRes, playersRes] = await Promise.all([
        userIds.length > 0
          ? supabase.from('user_profiles').select('id, username, email').in('id', userIds)
          : Promise.resolve({ data: [] as any[] }),
        playerIds.length > 0
          ? supabase.from('players').select('id, name').in('id', playerIds)
          : Promise.resolve({ data: [] as any[] }),
      ]);
      const userMap = new Map<string, string>((usersRes.data || []).map((u: any) => [u.id, u.username || u.email || String(u.id).substring(0, 8)]));
      const playerMap = new Map<string, string>((playersRes.data || []).map((p: any) => [p.id, p.name]));
      setAdminDigestHistory((bdh || []).map((d: any) => ({
        id: d.id,
        userId: d.user_id,
        userName: userMap.get(d.user_id) || String(d.user_id).substring(0, 8),
        playerId: d.player_id,
        playerName: d.player_id ? (playerMap.get(d.player_id) || null) : null,
        flags: Array.isArray(d.flags) ? d.flags : [],
        alertSummary: d.alert_summary || '',
        sentAt: d.sent_at,
        isResolved: !!d.is_resolved,
        resolvedAt: d.resolved_at,
      })));
    } catch { /* silent */ }
    setAdminDigestLoading(false);
    setAdminDigestLoaded(true);
  };

  // Undo the most recent bulk ban within the 10-second window
  const handleUndoBan = async () => {
    if (!undoBan) return;
    const currentUndo = undoBan;
    setUndoBan(null);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setBulkBusy(true);
    let restored = 0;
    for (const t of currentUndo.targets) {
      try {
        const { error: sErr } = await updateSuspiciousStatus(t.id, t.prevStatus);
        const { error: tErr } = await updateTrustScore(t.id, t.prevTrustScore);
        if (!sErr && !tErr) restored++;
      } catch { /* silent */ }
    }
    const idToPrev = new Map(currentUndo.targets.map(t => [t.id, t]));
    setPlayers(prev => prev.map(p => {
      const prevData = idToPrev.get(p.id);
      if (!prevData) return p;
      return { ...p, status: prevData.prevStatus, trustScore: prevData.prevTrustScore };
    }));
    setBulkBusy(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    showAlert(isFr ? `${restored} bannissement(s) annule(s)` : `${restored} ban(s) undone`);
  };

  // Reset the anti-cheat digest push cooldown for a given user so the next scan re-notifies them
  const handleResetCooldown = async (userId: string) => {
    if (!userId) return;
    Haptics.selectionAsync();
    setResettingCooldownId(userId);
    try {
      const supabase = getSupabaseClient();
      const { error } = await supabase
        .from('user_preferences')
        .upsert({ user_id: userId, last_anticheat_digest_sent: null }, { onConflict: 'user_id' });
      if (error) {
        showAlert(isFr ? `Erreur: ${error.message}` : `Error: ${error.message}`);
      } else {
        showAlert(isFr ? 'Cooldown push reinitialise' : 'Push cooldown reset');
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (e: any) {
      showAlert(isFr ? `Erreur: ${e?.message || 'inconnue'}` : `Error: ${e?.message || 'unknown'}`);
    }
    setResettingCooldownId(null);
  };

  // Bulk ELO reversal handler
  const handleBulkReverseElo = async () => {
    if (bulkReversing || deletionAlerts.length === 0) return;
    const totalAvoided = deletionAlerts.reduce((s, a) => s + a.avoidedEloLoss, 0);
    showAlert(
      ((et.bulkReverseEloConfirmTitle as any)?.[language] || 'Reverse ELO for {count} player(s)?').replace('{count}', String(deletionAlerts.length)),
      ((et.bulkReverseEloConfirmMsg as any)?.[language] || 'Subtract total {elo} ELO pts').replace('{elo}', String(totalAvoided)),
      [
        { text: isFr ? 'Annuler' : 'Cancel', style: 'cancel' },
        {
          text: (et.reverseElo as any)?.[language] || 'Reverse',
          style: 'destructive',
          onPress: async () => {
            setBulkReversing(true);
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
            let reversed = 0;
            let totalEloSubtracted = 0;
            for (const alert of deletionAlerts) {
              if (alert.avoidedEloLoss === 0) continue;
              const { error, eloBefore, eloAfter } = await reverseDeletedEloLoss(alert.userId, alert.playerId);
              if (!error) {
                reversed++;
                totalEloSubtracted += (eloBefore - eloAfter);
              }
            }
            setBulkReversing(false);
            const msg = ((et.bulkReverseEloSuccess as any)?.[language] || '{count} reversed, {elo} pts')
              .replace('{count}', String(reversed))
              .replace('{elo}', String(totalEloSubtracted));
            showAlert(msg);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ]
    );
  };

  return (
    <PageErrorBoundary pageName="AntiCheat">
    <AdminGuard language={language}>
    <SafeAreaView edges={['top']} style={st.container}>
      <View style={st.header}>
        <View style={{ flex: 1 }}>
          <Text style={st.headerTitle}>{(et.adminTitle as any)?.[language] || 'Anti-cheat'}</Text>
          <Text style={st.headerSub}>{filtered.length} {(et.adminDesc as any)?.[language] || 'players'}</Text>
        </View>
        <Pressable
          style={[st.headerIconBtn, { backgroundColor: '#991B1B' }]}
          onPress={() => { Haptics.selectionAsync(); router.push('/admin-anticheat-config' as any); }}
          hitSlop={6}
          accessibilityLabel={isFr ? 'Configuration auto-ban' : 'Auto-ban settings'}
        >
          <MaterialIcons name="tune" size={18} color="#FFF" />
        </Pressable>
        <Pressable
          style={[st.headerIconBtn, { backgroundColor: '#7C3AED' }, recalculating && { opacity: 0.6 }]}
          onPress={async () => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
            setRecalculating(true);
            const { success, error, playersUpdated } = await recalculateAllElo();
            setRecalculating(false);
            if (success) {
              showAlert(t('leaderboard', 'eloRecalculated').replace('{count}', String(playersUpdated)));
            } else {
              showAlert('Error', error || 'Unknown error');
            }
          }}
          disabled={recalculating}
          hitSlop={6}
          accessibilityLabel={isFr ? 'Recalculer ELO' : 'Recalculate ELO'}
        >
          {recalculating ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="calculate" size={18} color="#FFF" />}
        </Pressable>
        <Pressable
          style={[st.headerIconBtn, { backgroundColor: '#EF4444' }, scanning && { opacity: 0.6 }]}
          onPress={handleRunFullScan}
          disabled={scanning}
          hitSlop={6}
          accessibilityLabel={isFr ? 'Lancer un scan complet' : 'Run full scan'}
        >
          {scanning ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="radar" size={18} color="#FFF" />}
        </Pressable>
      </View>

      <AdminQuickNav currentRoute="/admin-anticheat" />

      <ScrollView
        style={st.mainScroll}
        contentContainerStyle={[st.mainScrollContent, { paddingBottom: insets.bottom + 32 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={theme.primary} colors={[theme.primary]} />}
      >

      {/* ============ OVERVIEW HERO (always visible - shows before data loads) ============ */}
      <View style={st.heroSection}>
        <View style={st.heroHeader}>
          <View style={st.heroIconWrap}>
            <MaterialIcons name="security" size={22} color="#EF4444" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.heroTitle}>{isFr ? "Vue d'ensemble Anti-triche" : 'Anti-cheat Overview'}</Text>
            <Text style={st.heroSub}>
              {loading
                ? (isFr ? 'Chargement des donnees...' : 'Loading data...')
                : players.length === 0
                  ? (isFr ? 'Aucun joueur analyse - Lancez un scan complet pour commencer' : 'No players analyzed - Run a full scan to start')
                  : (isFr ? `${players.length} joueur(s) analyse(s) - Score moyen ${summaryStats.avg}/100` : `${players.length} player(s) analyzed - Avg score ${summaryStats.avg}/100`)}
            </Text>
          </View>
          {loading ? <ActivityIndicator size="small" color="#EF4444" /> : null}
        </View>
        <View style={st.heroKpis}>
          <View style={[st.heroKpi, { borderColor: '#EF4444' + '25' }]}>
            <Text style={[st.heroKpiValue, { color: '#EF4444' }]}>{statusCounts.flagged}</Text>
            <Text style={st.heroKpiLabel}>{isFr ? 'Signales' : 'Flagged'}</Text>
          </View>
          <View style={[st.heroKpi, { borderColor: '#F97316' + '25' }]}>
            <Text style={[st.heroKpiValue, { color: '#F97316' }]}>{statusCounts.watch}</Text>
            <Text style={st.heroKpiLabel}>{isFr ? 'Surveille' : 'Watch'}</Text>
          </View>
          <View style={[st.heroKpi, { borderColor: '#DC2626' + '25' }]}>
            <Text style={[st.heroKpiValue, { color: '#DC2626' }]}>{statusCounts.banned}</Text>
            <Text style={st.heroKpiLabel}>{isFr ? 'Bannis' : 'Banned'}</Text>
          </View>
          <View style={[st.heroKpi, { borderColor: '#22C55E' + '25' }]}>
            <Text style={[st.heroKpiValue, { color: '#22C55E' }]}>{statusCounts.ok}</Text>
            <Text style={st.heroKpiLabel}>OK</Text>
          </View>
        </View>
        {!loading && players.length === 0 ? (
          <Pressable
            style={[st.heroCTA, scanning && { opacity: 0.6 }]}
            onPress={handleRunFullScan}
            disabled={scanning}
          >
            {scanning ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="radar" size={16} color="#FFF" />}
            <Text style={st.heroCTAText}>
              {scanning
                ? (isFr ? 'Analyse en cours...' : 'Scanning...')
                : (isFr ? 'Lancer le premier scan' : 'Run first scan')}
            </Text>
          </Pressable>
        ) : (
          <View style={st.heroActionsRow}>
            <Pressable
              style={st.heroQuickAction}
              onPress={() => { Haptics.selectionAsync(); router.push('/admin-anticheat-config' as any); }}
            >
              <MaterialIcons name="tune" size={14} color="#991B1B" />
              <Text style={[st.heroQuickActionText, { color: '#991B1B' }]}>{isFr ? 'Config auto-ban' : 'Auto-ban config'}</Text>
            </Pressable>
            <Pressable
              style={st.heroQuickAction}
              onPress={handleRunFullScan}
              disabled={scanning}
            >
              <MaterialIcons name="radar" size={14} color="#EF4444" />
              <Text style={[st.heroQuickActionText, { color: '#EF4444' }]}>{isFr ? 'Nouveau scan' : 'New scan'}</Text>
            </Pressable>
          </View>
        )}
      </View>

      {/* ============ DELETION ALERTS ============ */}
      {!deletionAlertsLoading && deletionAlerts.length > 0 ? (
        <View style={st.deletionSection}>
          <View style={st.deletionHeader}>
            <View style={[st.deletionIconWrap, { backgroundColor: '#EF444415' }]}>
              <MaterialIcons name="delete-sweep" size={18} color="#EF4444" />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={st.deletionTitle}>{(et.deletionAlertTitle as any)?.[language] || 'Defeat Deletion Alerts'}</Text>
              <Text style={st.deletionSubtitle}>{(et.deletionAlertDesc as any)?.[language] || 'Players who deleted lost matches'}</Text>
            </View>
            <View style={st.deletionCountBadge}>
              <Text style={st.deletionCountText}>{deletionAlerts.length}</Text>
            </View>
          </View>
          {deletionAlerts.slice(0, 5).map((alert, idx) => {
            const isCritical = alert.recentDeletedLost7d >= 5 || alert.deletedLostMatches >= 10;
            const severityColor = isCritical ? '#EF4444' : '#F59E0B';
            const severityLabel = isCritical
              ? ((et.deletionCritical as any)?.[language] || 'Critical')
              : ((et.deletionWarning as any)?.[language] || 'Warning');
            return (
              <Pressable
                key={alert.playerId}
                style={[st.deletionCard, { borderLeftColor: severityColor }]}
                onPress={() => {
                  const p = players.find(pl => pl.playerId === alert.playerId);
                  if (p) { setSelectedPlayer(p); setAdminNotes(p.adminNotes || ''); }
                  else router.push(`/player/${alert.playerId}` as any);
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                  <View style={st.deletionAvatar}>
                    {alert.playerAvatar ? (
                      <Image source={{ uri: alert.playerAvatar }} style={{ width: 32, height: 32, borderRadius: 10 }} contentFit="cover" />
                    ) : (
                      <Text style={{ fontSize: 13, fontWeight: '700', color: theme.textSecondary }}>{(alert.playerName || '?').charAt(0)}</Text>
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={st.deletionPlayerName}>{alert.playerName || alert.playerId.substring(0, 8)}</Text>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 2 }}>
                      <View style={[st.deletionSeverity, { backgroundColor: severityColor + '15', borderColor: severityColor + '30' }]}>
                        <MaterialIcons name={isCritical ? 'error' : 'warning'} size={10} color={severityColor} />
                        <Text style={[st.deletionSeverityText, { color: severityColor }]}>{severityLabel}</Text>
                      </View>
                      <View style={[st.deletionTrustBadge, { borderColor: getTrustScoreColor(alert.trustScore) }]}>
                        <Text style={[st.deletionTrustText, { color: getTrustScoreColor(alert.trustScore) }]}>{alert.trustScore}</Text>
                      </View>
                    </View>
                  </View>
                  <MaterialIcons name="chevron-right" size={20} color={theme.textMuted} />
                </View>
                <View style={st.deletionStatsRow}>
                  <View style={st.deletionStatItem}>
                    <Text style={[st.deletionStatValue, { color: '#EF4444' }]}>{alert.recentDeletedLost7d}</Text>
                    <Text style={st.deletionStatLabel}>{(et.recentDeletions7d as any)?.[language] || '7d'}</Text>
                  </View>
                  <View style={st.deletionStatDivider} />
                  <View style={st.deletionStatItem}>
                    <Text style={[st.deletionStatValue, { color: '#F97316' }]}>{alert.deletedLostMatches}</Text>
                    <Text style={st.deletionStatLabel}>{(et.deletedLostMatches as any)?.[language] || 'Losses del.'}</Text>
                  </View>
                  <View style={st.deletionStatDivider} />
                  <View style={st.deletionStatItem}>
                    <Text style={[st.deletionStatValue, { color: '#DC2626' }]}>-{alert.avoidedEloLoss}</Text>
                    <Text style={st.deletionStatLabel}>{(et.avoidedEloLoss as any)?.[language] || 'ELO avoided'}</Text>
                  </View>
                  <View style={st.deletionStatDivider} />
                  <View style={st.deletionStatItem}>
                    <Text style={[st.deletionStatValue, { color: theme.textSecondary }]}>{alert.totalDeletedMatches}</Text>
                    <Text style={st.deletionStatLabel}>{(et.totalDeletedMatches as any)?.[language] || 'Total del.'}</Text>
                  </View>
                </View>
              </Pressable>
            );
          })}
          {deletionAlerts.length > 5 ? (
            <Text style={st.deletionMoreText}>+{deletionAlerts.length - 5} {isFr ? 'autres alertes' : 'more alerts'}</Text>
          ) : null}
          {/* Bulk ELO reversal */}
          <Pressable
            style={[st.bulkReverseBtn, bulkReversing && { opacity: 0.6 }]}
            onPress={handleBulkReverseElo}
            disabled={bulkReversing}
          >
            {bulkReversing ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="undo" size={14} color="#FFF" />}
            <Text style={st.bulkReverseBtnText}>
              {bulkReversing
                ? ((et.bulkReversing as any)?.[language] || 'Reversing...')
                : `${(et.bulkReverseElo as any)?.[language] || 'Reverse all'} (-${deletionAlerts.reduce((s, a) => s + a.avoidedEloLoss, 0)} ELO)`}
            </Text>
          </Pressable>
        </View>
      ) : null}

      {/* ============ ELO Dashboard ============ */}
      {!eloLoading && eloDashboard ? (
        <View style={st.eloDashSection}>
          <View style={st.eloDashHeader}>
            <View style={[st.eloDashIcon, { backgroundColor: '#9333EA15' }]}>
              <MaterialIcons name="diamond" size={18} color="#9333EA" />
            </View>
            <Text style={st.eloDashTitle}>{isFr ? 'Tableau de bord ELO' : 'ELO Dashboard'}</Text>
          </View>

          {/* Top stats */}
          <View style={st.eloDashStatsRow}>
            <View style={st.eloDashStat}>
              <Text style={[st.eloDashStatValue, { color: '#9333EA' }]}>{eloDashboard.totalPlayers}</Text>
              <Text style={st.eloDashStatLabel}>{isFr ? 'Joueurs' : 'Players'}</Text>
            </View>
            <View style={st.eloDashStat}>
              <Text style={[st.eloDashStatValue, { color: getEloRank(eloDashboard.avgElo).color }]}>{eloDashboard.avgElo}</Text>
              <Text style={st.eloDashStatLabel}>{isFr ? 'ELO moyen' : 'Avg ELO'}</Text>
            </View>
            <View style={st.eloDashStat}>
              <Text style={[st.eloDashStatValue, { color: '#F59E0B' }]}>{eloDashboard.decayCount}</Text>
              <Text style={st.eloDashStatLabel}>{isFr ? 'En decay' : 'Decaying'}</Text>
            </View>
            {eloDashboard.topPlayer ? (
              <View style={st.eloDashStat}>
                <Text style={[st.eloDashStatValue, { color: getEloRank(eloDashboard.topPlayer.elo).color, fontSize: 14 }]}>{eloDashboard.topPlayer.elo}</Text>
                <Text style={st.eloDashStatLabel} numberOfLines={1}>{eloDashboard.topPlayer.name.split(' ')[0]}</Text>
              </View>
            ) : null}
          </View>

          {/* Rank distribution bar */}
          <View style={st.eloDashDistRow}>
            {eloDashboard.distribution.map(d => {
              const pct = eloDashboard.totalPlayers > 0 ? Math.round((d.count / eloDashboard.totalPlayers) * 100) : 0;
              return (
                <View key={d.tier} style={st.eloDashDistItem}>
                  <View style={st.eloDashDistBarTrack}>
                    <View style={[st.eloDashDistBarFill, { height: `${Math.max(pct, 4)}%`, backgroundColor: d.color }]} />
                  </View>
                  <Text style={[st.eloDashDistPct, { color: d.color }]}>{pct}%</Text>
                  <Text style={st.eloDashDistLabel} numberOfLines={1}>{d.label}</Text>
                  <Text style={[st.eloDashDistCount, { color: d.color }]}>{d.count}</Text>
                </View>
              );
            })}
          </View>

          {/* Action buttons */}
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
            <Pressable
              style={[st.eloDashActionBtn, { backgroundColor: '#F59E0B15', borderColor: '#F59E0B30' }, applyingDecay && { opacity: 0.6 }]}
              onPress={async () => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                setApplyingDecay(true);
                const { playersDecayed } = await applyInactivityDecay();
                setApplyingDecay(false);
                showAlert(isFr ? `Decay applique a ${playersDecayed} joueurs` : `Decay applied to ${playersDecayed} players`);
              }}
              disabled={applyingDecay}
            >
              {applyingDecay ? <ActivityIndicator size="small" color="#F59E0B" /> : <MaterialIcons name="timer-off" size={14} color="#F59E0B" />}
              <Text style={{ fontSize: 11, fontWeight: '700', color: '#F59E0B' }}>{isFr ? 'Appliquer decay' : 'Apply decay'}</Text>
            </Pressable>
            <Pressable
              style={[st.eloDashActionBtn, { backgroundColor: '#7C3AED15', borderColor: '#7C3AED30' }, recalculating && { opacity: 0.6 }]}
              onPress={async () => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
                setRecalculating(true);
                const { success, error, playersUpdated } = await recalculateAllElo();
                setRecalculating(false);
                if (success) {
                  showAlert(t('leaderboard', 'eloRecalculated').replace('{count}', String(playersUpdated)));
                } else {
                  showAlert('Error', error || 'Unknown');
                }
              }}
              disabled={recalculating}
            >
              {recalculating ? <ActivityIndicator size="small" color="#7C3AED" /> : <MaterialIcons name="calculate" size={14} color="#7C3AED" />}
              <Text style={{ fontSize: 11, fontWeight: '700', color: '#7C3AED' }}>{recalculating ? '...' : (isFr ? 'Recalculer ELO' : 'Recalc ELO')}</Text>
            </Pressable>
          </View>
        </View>
      ) : null}

      {/* Summary Statistics Dashboard */}
      {!loading && players.length > 0 ? (
        <View style={st.summarySection}>
          {/* Top stats row */}
          <View style={st.summaryRow}>
            <View style={st.summaryCard}>
              <Text style={st.summaryValue}>{summaryStats.total}</Text>
              <Text style={st.summaryLabel}>{isFr ? 'Analyses' : 'Analyzed'}</Text>
            </View>
            <View style={st.summaryCard}>
              <Text style={[st.summaryValue, { color: summaryStats.avg >= 65 ? '#22C55E' : summaryStats.avg >= 45 ? '#D97706' : '#EF4444' }]}>{summaryStats.avg}</Text>
              <Text style={st.summaryLabel}>{isFr ? 'Score moyen' : 'Avg score'}</Text>
            </View>
            <View style={st.summaryCard}>
              <Text style={[st.summaryValue, { color: '#EF4444' }]}>{summaryStats.weeklyFlagged}</Text>
              <Text style={st.summaryLabel}>{isFr ? 'Signales 7j' : 'Flagged 7d'}</Text>
            </View>
          </View>
          {/* Pie chart (simplified bar distribution) */}
          <View style={st.distRow}>
            {[
              { label: isFr ? 'Verifie' : 'Verified', count: summaryStats.verified, color: '#22C55E' },
              { label: isFr ? 'Fiable' : 'Trusted', count: summaryStats.high, color: '#3B82F6' },
              { label: 'Standard', count: summaryStats.medium, color: '#D97706' },
              { label: isFr ? 'A surveiller' : 'Watch', count: summaryStats.low, color: '#F97316' },
              { label: isFr ? 'Suspect' : 'Suspicious', count: summaryStats.suspicious, color: '#EF4444' },
            ].map(d => {
              const pct = summaryStats.total > 0 ? Math.round((d.count / summaryStats.total) * 100) : 0;
              return (
                <View key={d.label} style={st.distItem}>
                  <View style={st.distBarTrack}>
                    <View style={[st.distBarFill, { height: `${Math.max(pct, 4)}%`, backgroundColor: d.color }]} />
                  </View>
                  <Text style={[st.distPct, { color: d.color }]}>{pct}%</Text>
                  <Text style={st.distLabel} numberOfLines={1}>{d.label}</Text>
                  <Text style={st.distCount}>{d.count}</Text>
                </View>
              );
            })}
          </View>
          {/* Batch dismiss button */}
          {summaryStats.total > 0 ? (
            <Pressable style={st.batchDismissBtn} onPress={handleBatchDismissOk}>
              <MaterialIcons name="check-circle" size={16} color="#22C55E" />
              <Text style={st.batchDismissBtnText}>
                {isFr ? 'Ignorer tous les OK sans alertes' : 'Dismiss all OK with no flags'}
                {' '}({players.filter(p => p.status === 'ok' && p.flags.length === 0).length})
              </Text>
            </Pressable>
          ) : null}
        </View>
      ) : null}

      {/* ============ MATCH VALIDATION RATIO (per player) ============ */}
      {!loading && players.length > 0 ? (() => {
        // Compute validated vs local match ratio from players data
        const playersWithDetails = players.filter((p: any) => p.details);
        const totalAnalyzed = playersWithDetails.length;
        const highLocalRatio = playersWithDetails.filter((p: any) => {
          const mp = p.details?.multiPlayerRatio || 0;
          return mp < 30 && (p.details?.totalMatches || p.details?.matchesPlayed || 0) >= 5;
        });
        const avgMultiPlayerRatio = totalAnalyzed > 0
          ? Math.round(playersWithDetails.reduce((s: number, p: any) => s + (p.details?.multiPlayerRatio || 0), 0) / totalAnalyzed)
          : 0;

        return (
          <View style={st.deviceSection}>
            <View style={st.deviceHeaderRow}>
              <View style={[st.deviceIcon, { backgroundColor: '#3B82F615' }]}>
                <MaterialIcons name="fact-check" size={18} color="#3B82F6" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={st.deviceTitle}>{isFr ? 'Ratio Matchs Valides' : 'Validated Match Ratio'}</Text>
                <Text style={st.deviceSubtitle}>{isFr ? 'Matchs multi-joueurs vs solo' : 'Multi-player vs solo matches'}</Text>
              </View>
              <View style={{ alignItems: 'center', backgroundColor: avgMultiPlayerRatio >= 50 ? '#22C55E15' : '#EF444415', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 }}>
                <Text style={{ fontSize: 16, fontWeight: '900', color: avgMultiPlayerRatio >= 50 ? '#22C55E' : '#EF4444' }}>{avgMultiPlayerRatio}%</Text>
                <Text style={{ fontSize: 8, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'moy. multi' : 'avg multi'}</Text>
              </View>
            </View>

            {/* Summary stats */}
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
              <View style={{ flex: 1, alignItems: 'center', backgroundColor: theme.backgroundSecondary, borderRadius: 10, paddingVertical: 10 }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: '#3B82F6' }}>{totalAnalyzed}</Text>
                <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Analyses' : 'Analyzed'}</Text>
              </View>
              <View style={{ flex: 1, alignItems: 'center', backgroundColor: theme.backgroundSecondary, borderRadius: 10, paddingVertical: 10 }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: '#EF4444' }}>{highLocalRatio.length}</Text>
                <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600', textAlign: 'center' }}>{isFr ? '<30% multi' : '<30% multi'}</Text>
              </View>
              <View style={{ flex: 1, alignItems: 'center', backgroundColor: theme.backgroundSecondary, borderRadius: 10, paddingVertical: 10 }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: '#22C55E' }}>{totalAnalyzed - highLocalRatio.length}</Text>
                <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600', textAlign: 'center' }}>{isFr ? 'Conformes' : 'Compliant'}</Text>
              </View>
            </View>

            {/* Ratio distribution bar */}
            {totalAnalyzed > 0 ? (
              <View style={{ marginTop: 10, height: 10, flexDirection: 'row', borderRadius: 5, overflow: 'hidden', backgroundColor: theme.backgroundSecondary }}>
                <View style={{ flex: Math.max(totalAnalyzed - highLocalRatio.length, 0.1), backgroundColor: '#22C55E', borderRadius: 5 }} />
                <View style={{ flex: Math.max(highLocalRatio.length, 0.1), backgroundColor: '#EF4444' }} />
              </View>
            ) : null}

            {/* Top offenders (high local ratio) */}
            {highLocalRatio.length > 0 ? (
              <View style={{ marginTop: 12 }}>
                <Text style={{ fontSize: 11, fontWeight: '700', color: '#EF4444', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 }}>
                  {isFr ? 'Joueurs a forte proportion solo' : 'High solo ratio players'}
                </Text>
                {highLocalRatio.slice(0, 5).map((p: any) => (
                  <Pressable
                    key={p.id}
                    style={{ flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, marginBottom: 6 }}
                    onPress={() => { setSelectedPlayer(p); setAdminNotes(p.adminNotes || ''); }}
                  >
                    <View style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: '#EF444415', alignItems: 'center', justifyContent: 'center' }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: '#EF4444' }}>{p.details?.multiPlayerRatio || 0}%</Text>
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={{ fontSize: 13, fontWeight: '600', color: theme.textPrimary }}>{p.playerName || p.playerId.substring(0, 8)}</Text>
                      <Text style={{ fontSize: 10, color: theme.textMuted }}>
                        {p.details?.totalMatches || p.details?.matchesPlayed || 0} {isFr ? 'matchs' : 'matches'} • {p.details?.uniqueOpponents || 0} {isFr ? 'adversaires' : 'opponents'}
                      </Text>
                    </View>
                    <View style={[st.scoreCircle, { width: 36, height: 36, borderWidth: 2, borderColor: getTrustScoreColor(p.trustScore) }]}>
                      <Text style={[st.scoreText, { fontSize: 12, color: getTrustScoreColor(p.trustScore) }]}>{p.trustScore}</Text>
                    </View>
                  </Pressable>
                ))}
                {highLocalRatio.length > 5 ? (
                  <Text style={{ fontSize: 11, color: theme.textMuted, textAlign: 'center', marginTop: 4 }}>+{highLocalRatio.length - 5} {isFr ? 'autres' : 'more'}</Text>
                ) : null}
              </View>
            ) : null}
          </View>
        );
      })() : null}

      {/* ============ ANTI-CHEAT WEEKLY ANALYTICS ============ */}
      <View style={st.deviceSection}>
        <Pressable
          style={st.deviceHeaderRow}
          onPress={async () => {
            if (weeklyAnalytics.length > 0) { setWeeklyAnalytics([]); return; }
            setAnalyticsLoading(true);
            try {
              const supabase = getSupabaseClient();
              // Get registrations over last 12 weeks
              const twelveWeeksAgo = new Date(); twelveWeeksAgo.setDate(twelveWeeksAgo.getDate() - 84);
              const { data: regData } = await supabase.from('device_registrations').select('registered_at, device_fingerprint, email').gte('registered_at', twelveWeeksAgo.toISOString()).order('registered_at', { ascending: true });
              // Group by week
              const weekMap = new Map<string, { blocked: number; registrations: number; multiAccount: number }>();
              const fpEmailMap = new Map<string, Set<string>>();
              for (const r of regData || []) {
                const d = new Date(r.registered_at);
                const monday = new Date(d); monday.setDate(d.getDate() - ((d.getDay() + 6) % 7)); monday.setHours(0, 0, 0, 0);
                const wk = monday.toISOString().split('T')[0];
                if (!weekMap.has(wk)) weekMap.set(wk, { blocked: 0, registrations: 0, multiAccount: 0 });
                weekMap.get(wk)!.registrations++;
                if (r.device_fingerprint && r.email) {
                  if (!fpEmailMap.has(r.device_fingerprint)) fpEmailMap.set(r.device_fingerprint, new Set());
                  fpEmailMap.get(r.device_fingerprint)!.add(r.email.toLowerCase());
                  if (fpEmailMap.get(r.device_fingerprint)!.size > 1) {
                    weekMap.get(wk)!.multiAccount++;
                  }
                }
              }
              const weeks = Array.from(weekMap.entries()).sort((a, b) => a[0].localeCompare(b[0])).map(([week, stats]) => ({ week: week.substring(5), ...stats }));
              setWeeklyAnalytics(weeks);
            } catch { /* silent */ }
            setAnalyticsLoading(false);
          }}
        >
          <View style={[st.deviceIcon, { backgroundColor: '#7C3AED15' }]}>
            <MaterialIcons name="analytics" size={18} color="#7C3AED" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.deviceTitle}>{isFr ? 'Analytiques Anti-Triche' : 'Anti-Cheat Analytics'}</Text>
            <Text style={st.deviceSubtitle}>{isFr ? 'Tendances hebdomadaires (12 sem.)' : 'Weekly trends (12 wks)'}</Text>
          </View>
          {analyticsLoading ? <ActivityIndicator size="small" color="#7C3AED" /> : (
            <MaterialIcons name={weeklyAnalytics.length > 0 ? 'expand-less' : 'expand-more'} size={22} color={theme.textMuted} />
          )}
        </Pressable>
        {weeklyAnalytics.length > 0 ? (
          <View style={{ paddingTop: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 3, height: 90, backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 10, paddingBottom: 24 }}>
              {weeklyAnalytics.map((w, i) => {
                const maxReg = Math.max(...weeklyAnalytics.map(wk => wk.registrations), 1);
                const regH = Math.max(4, (w.registrations / maxReg) * 50);
                const maH = Math.max(2, (w.multiAccount / Math.max(maxReg, 1)) * 50);
                return (
                  <View key={w.week} style={{ flex: 1, alignItems: 'center', gap: 2 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 1 }}>
                      <View style={{ width: 6, height: regH, borderRadius: 3, backgroundColor: '#3B82F6' }} />
                      {w.multiAccount > 0 ? <View style={{ width: 5, height: maH, borderRadius: 3, backgroundColor: '#EF4444' }} /> : null}
                    </View>
                    <Text style={{ fontSize: 6, color: theme.textMuted, fontWeight: '500' }}>{w.week}</Text>
                  </View>
                );
              })}
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 16, marginTop: 8 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#3B82F6' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Inscriptions' : 'Registrations'}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#EF4444' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Multi-comptes' : 'Multi-accounts'}</Text>
              </View>
            </View>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, alignItems: 'center' }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: '#3B82F6' }}>{weeklyAnalytics.reduce((s, w) => s + w.registrations, 0)}</Text>
                <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Total inscriptions' : 'Total registrations'}</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, alignItems: 'center' }}>
                <Text style={{ fontSize: 18, fontWeight: '800', color: '#EF4444' }}>{weeklyAnalytics.reduce((s, w) => s + w.multiAccount, 0)}</Text>
                <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Violations' : 'Violations'}</Text>
              </View>
            </View>
          </View>
        ) : null}
      </View>

      {/* ============ TEMPORAL ALERT TRENDS (last 8 weeks) ============ */}
      <View style={st.deviceSection}>
        <Pressable
          style={st.deviceHeaderRow}
          onPress={async () => {
            if (temporalTrends.length > 0) { setTemporalTrends([]); return; }
            setTemporalTrendsLoading(true);
            try {
              const supabase = getSupabaseClient();
              const eightWeeksAgo = new Date(); eightWeeksAgo.setDate(eightWeeksAgo.getDate() - 56);
              const { data: matchData } = await supabase
                .from('matches')
                .select('id, date, created_at, duration')
                .gte('created_at', eightWeeksAgo.toISOString())
                .order('created_at', { ascending: true });
              const weekMap = new Map<string, { nocturnal: number; unrealistic: number; dailyCounts: Map<string, number> }>();
              for (const m of matchData || []) {
                const d = new Date(m.date || m.created_at);
                if (!Number.isFinite(d.getTime())) continue;
                const monday = new Date(d); monday.setDate(d.getDate() - ((d.getDay() + 6) % 7)); monday.setHours(0, 0, 0, 0);
                const wk = monday.toISOString().split('T')[0];
                if (!weekMap.has(wk)) weekMap.set(wk, { nocturnal: 0, unrealistic: 0, dailyCounts: new Map() });
                const w = weekMap.get(wk)!;
                const hour = d.getUTCHours();
                if (hour >= 3 && hour < 6) w.nocturnal++;
                if (Number.isFinite(m.duration) && (m.duration < 5 || m.duration > 240)) w.unrealistic++;
                const day = d.toISOString().split('T')[0];
                w.dailyCounts.set(day, (w.dailyCounts.get(day) || 0) + 1);
              }
              const weeks = Array.from(weekMap.entries())
                .sort((a, b) => a[0].localeCompare(b[0]))
                .slice(-8)
                .map(([week, stats]) => {
                  const massSub = Array.from(stats.dailyCounts.values()).filter(c => c > 20).length;
                  return { week: week.substring(5), nocturnal: stats.nocturnal, unrealistic: stats.unrealistic, massSub };
                });
              setTemporalTrends(weeks);
            } catch { /* silent */ }
            setTemporalTrendsLoading(false);
          }}
        >
          <View style={[st.deviceIcon, { backgroundColor: '#8B5CF615' }]}>
            <MaterialIcons name="query-stats" size={18} color="#8B5CF6" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.deviceTitle}>{isFr ? 'Tendances alertes temporelles' : 'Temporal Alert Trends'}</Text>
            <Text style={st.deviceSubtitle}>{isFr ? '8 dernieres semaines (nocturnes, durees, volume)' : 'Last 8 weeks (nocturnal, durations, volume)'}</Text>
          </View>
          {temporalTrendsLoading ? <ActivityIndicator size="small" color="#8B5CF6" /> : (
            <MaterialIcons name={temporalTrends.length > 0 ? 'expand-less' : 'expand-more'} size={22} color={theme.textMuted} />
          )}
        </Pressable>
        {temporalTrends.length > 0 ? (
          <View style={{ paddingTop: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 4, height: 100, backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 10, paddingBottom: 24 }}>
              {(() => {
                const avgSum = temporalTrends.length > 0
                  ? temporalTrends.reduce((s, x) => s + x.nocturnal + x.unrealistic + x.massSub, 0) / temporalTrends.length
                  : 0;
                const alertThreshold = avgSum * 2;
                const maxVal = Math.max(...temporalTrends.map(x => Math.max(x.nocturnal, x.unrealistic, x.massSub)), 1);
                return temporalTrends.map((w) => {
                  const nH = Math.max(2, (w.nocturnal / maxVal) * 60);
                  const uH = Math.max(2, (w.unrealistic / maxVal) * 60);
                  const mH = Math.max(2, (w.massSub / maxVal) * 60);
                  const sum = w.nocturnal + w.unrealistic + w.massSub;
                  const isAlert = alertThreshold > 0 && sum > alertThreshold;
                  return (
                    <View key={w.week} style={{ flex: 1, alignItems: 'center', gap: 2 }}>
                      {isAlert ? (
                        <View style={{ backgroundColor: '#EF4444', borderRadius: 6, width: 12, height: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 2 }}>
                          <MaterialIcons name="priority-high" size={8} color="#FFF" />
                        </View>
                      ) : null}
                      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 1 }}>
                        {w.nocturnal > 0 ? <View style={{ width: 5, height: nH, borderRadius: 3, backgroundColor: '#7C3AED' }} /> : null}
                        {w.unrealistic > 0 ? <View style={{ width: 5, height: uH, borderRadius: 3, backgroundColor: '#F97316' }} /> : null}
                        {w.massSub > 0 ? <View style={{ width: 5, height: mH, borderRadius: 3, backgroundColor: '#DC2626' }} /> : null}
                      </View>
                      <Text style={{ fontSize: 7, color: isAlert ? '#EF4444' : theme.textMuted, fontWeight: isAlert ? '800' : '500' }}>{w.week}</Text>
                    </View>
                  );
                });
              })()}
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 8, flexWrap: 'wrap' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#7C3AED' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Nocturnes' : 'Nocturnal'}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#F97316' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Durees' : 'Durations'}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#DC2626' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Volume >20/j' : 'Volume >20/day'}</Text>
              </View>
            </View>
            <View style={{ flexDirection: 'row', gap: 6, marginTop: 10 }}>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 8, alignItems: 'center' }}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: '#7C3AED' }}>{temporalTrends.reduce((s, w) => s + w.nocturnal, 0)}</Text>
                <Text style={{ fontSize: 8, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Nocturnes' : 'Nocturnal'}</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 8, alignItems: 'center' }}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: '#F97316' }}>{temporalTrends.reduce((s, w) => s + w.unrealistic, 0)}</Text>
                <Text style={{ fontSize: 8, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Durees' : 'Durations'}</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 8, alignItems: 'center' }}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: '#DC2626' }}>{temporalTrends.reduce((s, w) => s + w.massSub, 0)}</Text>
                <Text style={{ fontSize: 8, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Jours >20' : 'Days >20'}</Text>
              </View>
            </View>
            {(() => {
              const avgSum = temporalTrends.length > 0
                ? temporalTrends.reduce((s, x) => s + x.nocturnal + x.unrealistic + x.massSub, 0) / temporalTrends.length
                : 0;
              const alertThreshold = avgSum * 2;
              const alertWeeks = alertThreshold > 0
                ? temporalTrends.filter(x => (x.nocturnal + x.unrealistic + x.massSub) > alertThreshold).length
                : 0;
              if (alertWeeks === 0) return null;
              return (
                <View style={{ marginTop: 8, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#EF444415', borderRadius: 10, paddingVertical: 8, paddingHorizontal: 10, borderWidth: 1, borderColor: '#EF444430' }}>
                  <MaterialIcons name="warning" size={14} color="#EF4444" />
                  <Text style={{ fontSize: 11, fontWeight: '700', color: '#EF4444', flex: 1 }}>
                    {isFr
                      ? `${alertWeeks} semaine(s) au-dessus de 2x la moyenne (${Math.round(alertThreshold)})`
                      : `${alertWeeks} week(s) above 2x average (${Math.round(alertThreshold)})`}
                  </Text>
                </View>
              );
            })()}
          </View>
        ) : null}
      </View>

      {/* ============ BEHAVIORAL ALERT TRENDS (last 8 weeks) ============ */}
      <View style={st.deviceSection}>
        <Pressable
          style={st.deviceHeaderRow}
          onPress={async () => {
            if (behavioralTrends.length > 0) { setBehavioralTrends([]); return; }
            setBehavioralTrendsLoading(true);
            try {
              const supabase = getSupabaseClient();
              const eightWeeksAgo = new Date(); eightWeeksAgo.setDate(eightWeeksAgo.getDate() - 56);
              const { data: matchData } = await supabase
                .from('matches')
                .select('id, date, created_at, team_a, team_b, participant_user_ids')
                .gte('created_at', eightWeeksAgo.toISOString())
                .order('created_at', { ascending: true });
              const weekMap = new Map<string, { selfMatch: number; symmetric: number; ghost: number }>();
              for (const m of matchData || []) {
                const d = new Date(m.date || m.created_at);
                if (!Number.isFinite(d.getTime())) continue;
                const monday = new Date(d); monday.setDate(d.getDate() - ((d.getDay() + 6) % 7)); monday.setHours(0, 0, 0, 0);
                const wk = monday.toISOString().split('T')[0];
                if (!weekMap.has(wk)) weekMap.set(wk, { selfMatch: 0, symmetric: 0, ghost: 0 });
                const w = weekMap.get(wk)!;
                const teamA = (m.team_a?.players || []) as string[];
                const teamB = (m.team_b?.players || []) as string[];
                if (teamA.length > 0 && teamB.length > 0) {
                  const setA = new Set(teamA);
                  if (teamB.some((p: string) => setA.has(p))) w.selfMatch++;
                }
                const sa = Number(m.team_a?.score) || 0;
                const sb = Number(m.team_b?.score) || 0;
                if ((sa === 13 && sb <= 1) || (sb === 13 && sa <= 1)) w.symmetric++;
                const pids = m.participant_user_ids || [];
                if (!Array.isArray(pids) || pids.length <= 1) w.ghost++;
              }
              const weeks = Array.from(weekMap.entries())
                .sort((a, b) => a[0].localeCompare(b[0]))
                .slice(-8)
                .map(([week, stats]) => ({ week: week.substring(5), selfMatch: stats.selfMatch, symmetric: stats.symmetric, ghost: stats.ghost }));
              setBehavioralTrends(weeks);
            } catch { /* silent */ }
            setBehavioralTrendsLoading(false);
          }}
        >
          <View style={[st.deviceIcon, { backgroundColor: '#EC489915' }]}>
            <MaterialIcons name="psychology" size={18} color="#EC4899" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.deviceTitle}>{isFr ? 'Tendances alertes comportementales' : 'Behavioral Alert Trends'}</Text>
            <Text style={st.deviceSubtitle}>{isFr ? '8 dernieres semaines (auto-affrontements, scores extremes, solo)' : 'Last 8 weeks (self-matches, extreme scores, solo)'}</Text>
          </View>
          {behavioralTrendsLoading ? <ActivityIndicator size="small" color="#EC4899" /> : (
            <MaterialIcons name={behavioralTrends.length > 0 ? 'expand-less' : 'expand-more'} size={22} color={theme.textMuted} />
          )}
        </Pressable>
        {behavioralTrends.length > 0 ? (
          <View style={{ paddingTop: 12 }}>
            <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 4, height: 100, backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 10, paddingBottom: 24 }}>
              {(() => {
                const avgSum = behavioralTrends.length > 0
                  ? behavioralTrends.reduce((s, x) => s + x.selfMatch + x.symmetric + x.ghost, 0) / behavioralTrends.length
                  : 0;
                const alertThreshold = avgSum * 2;
                const maxVal = Math.max(...behavioralTrends.map(x => Math.max(x.selfMatch, x.symmetric, x.ghost)), 1);
                return behavioralTrends.map((w) => {
                  const smH = Math.max(2, (w.selfMatch / maxVal) * 60);
                  const syH = Math.max(2, (w.symmetric / maxVal) * 60);
                  const ghH = Math.max(2, (w.ghost / maxVal) * 60);
                  const sum = w.selfMatch + w.symmetric + w.ghost;
                  const isAlert = alertThreshold > 0 && sum > alertThreshold;
                  return (
                    <View key={w.week} style={{ flex: 1, alignItems: 'center', gap: 2 }}>
                      {isAlert ? (
                        <View style={{ backgroundColor: '#EF4444', borderRadius: 6, width: 12, height: 12, alignItems: 'center', justifyContent: 'center', marginBottom: 2 }}>
                          <MaterialIcons name="priority-high" size={8} color="#FFF" />
                        </View>
                      ) : null}
                      <View style={{ flexDirection: 'row', alignItems: 'flex-end', gap: 1 }}>
                        {w.selfMatch > 0 ? <View style={{ width: 5, height: smH, borderRadius: 3, backgroundColor: '#EC4899' }} /> : null}
                        {w.symmetric > 0 ? <View style={{ width: 5, height: syH, borderRadius: 3, backgroundColor: '#F43F5E' }} /> : null}
                        {w.ghost > 0 ? <View style={{ width: 5, height: ghH, borderRadius: 3, backgroundColor: '#A855F7' }} /> : null}
                      </View>
                      <Text style={{ fontSize: 7, color: isAlert ? '#EF4444' : theme.textMuted, fontWeight: isAlert ? '800' : '500' }}>{w.week}</Text>
                    </View>
                  );
                });
              })()}
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 8, flexWrap: 'wrap' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#EC4899' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Auto-affrontements' : 'Self-matches'}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#F43F5E' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Scores 13-0/13-1' : '13-0/13-1 scores'}</Text>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#A855F7' }} />
                <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Solo (proxy fantomes)' : 'Solo (ghost proxy)'}</Text>
              </View>
            </View>
            <View style={{ flexDirection: 'row', gap: 6, marginTop: 10 }}>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 8, alignItems: 'center' }}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: '#EC4899' }}>{behavioralTrends.reduce((s, w) => s + w.selfMatch, 0)}</Text>
                <Text style={{ fontSize: 8, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Auto-affr.' : 'Self-m.'}</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 8, alignItems: 'center' }}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: '#F43F5E' }}>{behavioralTrends.reduce((s, w) => s + w.symmetric, 0)}</Text>
                <Text style={{ fontSize: 8, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Symetriques' : 'Symmetric'}</Text>
              </View>
              <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 8, alignItems: 'center' }}>
                <Text style={{ fontSize: 16, fontWeight: '800', color: '#A855F7' }}>{behavioralTrends.reduce((s, w) => s + w.ghost, 0)}</Text>
                <Text style={{ fontSize: 8, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Solo' : 'Solo'}</Text>
              </View>
            </View>
            {(() => {
              const avgSum = behavioralTrends.length > 0
                ? behavioralTrends.reduce((s, x) => s + x.selfMatch + x.symmetric + x.ghost, 0) / behavioralTrends.length
                : 0;
              const alertThreshold = avgSum * 2;
              const alertWeeks = alertThreshold > 0
                ? behavioralTrends.filter(x => (x.selfMatch + x.symmetric + x.ghost) > alertThreshold).length
                : 0;
              if (alertWeeks === 0) return null;
              return (
                <View style={{ marginTop: 8, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#EF444415', borderRadius: 10, paddingVertical: 8, paddingHorizontal: 10, borderWidth: 1, borderColor: '#EF444430' }}>
                  <MaterialIcons name="warning" size={14} color="#EF4444" />
                  <Text style={{ fontSize: 11, fontWeight: '700', color: '#EF4444', flex: 1 }}>
                    {isFr
                      ? `${alertWeeks} semaine(s) au-dessus de 2x la moyenne (${Math.round(alertThreshold)})`
                      : `${alertWeeks} week(s) above 2x average (${Math.round(alertThreshold)})`}
                  </Text>
                </View>
              );
            })()}
          </View>
        ) : null}
      </View>

      {/* ============ ADMIN BEHAVIORAL DIGEST HISTORY (last 30 entries, all players) ============ */}
      <View style={st.deviceSection}>
        <Pressable style={st.deviceHeaderRow} onPress={loadAdminDigestHistory}>
          <View style={[st.deviceIcon, { backgroundColor: '#F43F5E15' }]}>
            <MaterialIcons name="history" size={18} color="#F43F5E" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.deviceTitle}>{isFr ? 'Historique rappels comportementaux' : 'Behavioral Digest History'}</Text>
            <Text style={st.deviceSubtitle}>{isFr ? '30 dernieres entrees (tous joueurs)' : 'Last 30 entries (all players)'}</Text>
          </View>
          {adminDigestLoading ? <ActivityIndicator size="small" color="#F43F5E" /> : (
            <MaterialIcons name={adminDigestLoaded ? 'expand-less' : 'expand-more'} size={22} color={theme.textMuted} />
          )}
        </Pressable>
        {adminDigestLoaded ? (
          <View style={{ paddingTop: 10 }}>
            <View style={[st.searchBar, { marginHorizontal: 0, marginBottom: 10 }]}>
              <MaterialIcons name="search" size={18} color={theme.textMuted} />
              <TextInput
                style={st.searchInput}
                value={adminDigestSearch}
                onChangeText={setAdminDigestSearch}
                placeholder={isFr ? 'Filtrer par joueur ou user...' : 'Filter by player or user...'}
                placeholderTextColor={theme.textMuted}
              />
              {adminDigestSearch.length > 0 ? (
                <Pressable onPress={() => setAdminDigestSearch('')} hitSlop={8}>
                  <MaterialIcons name="close" size={16} color={theme.textMuted} />
                </Pressable>
              ) : null}
            </View>
            {(() => {
              const filteredList = adminDigestHistory.filter(h => {
                if (!adminDigestSearch.trim()) return true;
                const q = adminDigestSearch.toLowerCase();
                return h.userName.toLowerCase().includes(q) || (h.playerName || '').toLowerCase().includes(q);
              });
              const activeCount = adminDigestHistory.filter(h => !h.isResolved).length;
              const resolvedCount = adminDigestHistory.filter(h => h.isResolved).length;
              return (
                <>
                  <View style={{ flexDirection: 'row', gap: 6, marginBottom: 10 }}>
                    <View style={{ flex: 1, alignItems: 'center', backgroundColor: theme.backgroundSecondary, borderRadius: 10, paddingVertical: 8 }}>
                      <Text style={{ fontSize: 16, fontWeight: '800', color: theme.textPrimary }}>{adminDigestHistory.length}</Text>
                      <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Total' : 'Total'}</Text>
                    </View>
                    <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#F43F5E10', borderRadius: 10, paddingVertical: 8 }}>
                      <Text style={{ fontSize: 16, fontWeight: '800', color: '#F43F5E' }}>{activeCount}</Text>
                      <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Actifs' : 'Active'}</Text>
                    </View>
                    <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#22C55E10', borderRadius: 10, paddingVertical: 8 }}>
                      <Text style={{ fontSize: 16, fontWeight: '800', color: '#22C55E' }}>{resolvedCount}</Text>
                      <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Resolus' : 'Resolved'}</Text>
                    </View>
                  </View>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <Text style={{ fontSize: 11, color: theme.textMuted, fontWeight: '600' }}>
                      {`${filteredList.length} / ${adminDigestHistory.length} ${isFr ? 'entree(s)' : 'entry(ies)'}`}
                    </Text>
                    <Pressable style={st.digestExportBtn} onPress={handleExportDigestCSV}>
                      <MaterialIcons name="file-download" size={13} color="#F43F5E" />
                      <Text style={st.digestExportBtnText}>{isFr ? 'Export CSV' : 'Export CSV'}</Text>
                    </Pressable>
                  </View>
                  {filteredList.length === 0 ? (
                    <View style={{ paddingVertical: 20, alignItems: 'center', gap: 6 }}>
                      <MaterialIcons name="filter-list" size={24} color={theme.textMuted} />
                      <Text style={{ fontSize: 11, color: theme.textMuted, fontWeight: '600' }}>
                        {isFr ? 'Aucune entree' : 'No entries'}
                      </Text>
                    </View>
                  ) : filteredList.map(h => {
                    const dateStr = new Date(h.sentAt).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
                    const resolvedColor = h.isResolved ? '#22C55E' : '#F43F5E';
                    return (
                      <Pressable
                        key={h.id}
                        style={[st.digestRow, { borderLeftColor: resolvedColor }, h.playerId && { paddingRight: 6 }]}
                        onPress={() => {
                          if (!h.playerId) return;
                          Haptics.selectionAsync();
                          router.push(`/player/${h.playerId}` as any);
                        }}
                        disabled={!h.playerId}
                      >
                        <View style={{ flex: 1 }}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 3 }}>
                            <MaterialIcons name="person" size={11} color={theme.textMuted} />
                            <Text style={st.digestUser} numberOfLines={1}>{h.playerName || h.userName}</Text>
                          </View>
                          <Text style={st.digestDate}>{dateStr}</Text>
                          {h.alertSummary ? (
                            <Text style={st.digestSummary} numberOfLines={2}>{h.alertSummary}</Text>
                          ) : null}
                        </View>
                        <View style={[st.digestStatusBadge, { backgroundColor: resolvedColor + '15', borderColor: resolvedColor + '30' }]}>
                          <MaterialIcons name={h.isResolved ? 'check-circle' : 'radio-button-checked'} size={10} color={resolvedColor} />
                          <Text style={[st.digestStatusText, { color: resolvedColor }]}>
                            {h.isResolved ? (isFr ? 'Resolu' : 'Resolved') : (isFr ? 'Actif' : 'Active')}
                          </Text>
                        </View>
                        {h.playerId ? (
                          <MaterialIcons name="chevron-right" size={16} color={theme.textMuted} />
                        ) : null}
                      </Pressable>
                    );
                  })}
                </>
              );
            })()}
          </View>
        ) : null}
      </View>

      {/* ============ DEVICE TRANSFER REQUESTS ============ */}
      <View style={st.deviceSection}>
        <Pressable
          style={st.deviceHeaderRow}
          onPress={async () => {
            if (transferRequests.length > 0) { setTransferRequests([]); return; }
            setTransferLoading(true);
            const { requests, error: trErr } = await fetchPendingTransferRequests();
            if (trErr) showAlert('Error', trErr);
            setTransferRequests(requests);
            setTransferLoading(false);
          }}
        >
          <View style={[st.deviceIcon, { backgroundColor: '#F59E0B15' }]}>
            <MaterialIcons name="swap-horiz" size={18} color="#F59E0B" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.deviceTitle}>{isFr ? 'Transferts d\'appareils' : 'Device Transfers'}</Text>
            <Text style={st.deviceSubtitle}>{isFr ? 'Demandes en attente de validation' : 'Pending validation requests'}</Text>
          </View>
          {transferLoading ? <ActivityIndicator size="small" color="#F59E0B" /> : (
            <MaterialIcons name={transferRequests.length > 0 ? 'expand-less' : 'expand-more'} size={22} color={theme.textMuted} />
          )}
        </Pressable>
        {transferRequests.length > 0 ? (
          <View style={{ paddingTop: 10 }}>
            {transferRequests.map((tr) => (
              <View key={tr.id} style={st.deviceCard}>
                <View style={{ marginBottom: 8 }}>
                  <Text style={{ fontSize: 14, fontWeight: '700', color: theme.textPrimary }}>{tr.username || tr.userEmail || tr.userId.substring(0, 8)}</Text>
                  <Text style={{ fontSize: 11, color: theme.textMuted, marginTop: 2 }}>Code: <Text style={{ fontWeight: '800', color: '#F59E0B', letterSpacing: 2 }}>{tr.transferCode}</Text></Text>
                  <Text style={{ fontSize: 10, color: theme.textMuted, marginTop: 2 }}>
                    {isFr ? 'Expire' : 'Expires'}: {new Date(tr.expiresAt).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </Text>
                  {tr.oldFingerprint ? <Text style={{ fontSize: 8, color: theme.textMuted, fontFamily: 'monospace', marginTop: 2 }}>{tr.oldFingerprint}</Text> : null}
                </View>
                <View style={{ flexDirection: 'row', gap: 8 }}>
                  <Pressable
                    style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: '#22C55E15', paddingVertical: 10, borderRadius: 10 }}
                    onPress={async () => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                      const { error: vErr } = await validateTransferRequest(tr.id);
                      if (vErr) { showAlert('Error', vErr); return; }
                      setTransferRequests(prev => prev.filter(r => r.id !== tr.id));
                      showAlert(isFr ? 'Transfert valide' : 'Transfer validated');
                    }}
                  >
                    <MaterialIcons name="check" size={16} color="#22C55E" />
                    <Text style={{ fontSize: 12, fontWeight: '700', color: '#22C55E' }}>{isFr ? 'Valider' : 'Validate'}</Text>
                  </Pressable>
                  <Pressable
                    style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: '#EF444415', paddingVertical: 10, borderRadius: 10 }}
                    onPress={async () => {
                      Haptics.selectionAsync();
                      const { error: rErr } = await rejectTransferRequest(tr.id);
                      if (rErr) { showAlert('Error', rErr); return; }
                      setTransferRequests(prev => prev.filter(r => r.id !== tr.id));
                    }}
                  >
                    <MaterialIcons name="close" size={16} color="#EF4444" />
                    <Text style={{ fontSize: 12, fontWeight: '700', color: '#EF4444' }}>{isFr ? 'Rejeter' : 'Reject'}</Text>
                  </Pressable>
                </View>
              </View>
            ))}
            {transferRequests.length === 0 ? (
              <Text style={{ fontSize: 12, color: theme.textMuted, textAlign: 'center', paddingVertical: 16 }}>{isFr ? 'Aucune demande en attente' : 'No pending requests'}</Text>
            ) : null}
          </View>
        ) : null}
      </View>

      {/* ============ DEVICE MANAGEMENT ============ */}
      <View style={st.deviceSection}>
        <Pressable
          style={st.deviceHeaderRow}
          onPress={async () => {
            if (deviceRegsLoaded) {
              setDeviceRegsLoaded(false);
              setDeviceRegs([]);
              return;
            }
            setDeviceRegsLoading(true);
            const { registrations, error: err } = await fetchDeviceRegistrations();
            if (err) showAlert('Error', err);
            setDeviceRegs(registrations);
            setDeviceRegsLoading(false);
            setDeviceRegsLoaded(true);
          }}
        >
          <View style={[st.deviceIcon, { backgroundColor: '#0EA5E915' }]}>
            <MaterialIcons name="devices" size={18} color="#0EA5E9" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.deviceTitle}>{isFr ? 'Gestion des appareils' : 'Device Management'}</Text>
            <Text style={st.deviceSubtitle}>{isFr ? 'Delier des comptes de leurs appareils' : 'Unlink accounts from their devices'}</Text>
          </View>
          {deviceRegsLoading ? <ActivityIndicator size="small" color="#0EA5E9" /> : (
            <MaterialIcons name={deviceRegsLoaded ? 'expand-less' : 'expand-more'} size={22} color={theme.textMuted} />
          )}
        </Pressable>

        {deviceRegsLoaded ? (
          <View style={{ paddingTop: 10 }}>
            <View style={[st.searchBar, { marginHorizontal: 0, marginBottom: 10 }]}>
              <MaterialIcons name="search" size={18} color={theme.textMuted} />
              <TextInput style={st.searchInput} value={deviceSearch} onChangeText={setDeviceSearch} placeholder={isFr ? 'Filtrer par email ou fingerprint...' : 'Filter by email or fingerprint...'} placeholderTextColor={theme.textMuted} />
              {deviceSearch.length > 0 ? <Pressable onPress={() => setDeviceSearch('')} hitSlop={8}><MaterialIcons name="close" size={16} color={theme.textMuted} /></Pressable> : null}
            </View>

            {(() => {
              const filteredDevices = deviceRegs.filter(d => {
                if (!deviceSearch.trim()) return true;
                const q = deviceSearch.toLowerCase();
                return d.email.toLowerCase().includes(q) || d.fingerprint.toLowerCase().includes(q);
              });

              // Group by fingerprint for multi-account detection
              const fpGroups = new Map<string, typeof filteredDevices>();
              filteredDevices.forEach(d => {
                if (!fpGroups.has(d.fingerprint)) fpGroups.set(d.fingerprint, []);
                fpGroups.get(d.fingerprint)!.push(d);
              });
              const multiAccountFps = Array.from(fpGroups.entries()).filter(([_, regs]) => {
                const uniqueEmails = new Set(regs.map(r => r.email.toLowerCase()));
                return uniqueEmails.size > 1;
              });

              return (
                <>
                  {/* Multi-account alerts */}
                  {multiAccountFps.length > 0 ? (
                    <View style={{ backgroundColor: '#EF444408', borderRadius: 12, padding: 10, marginBottom: 10, borderWidth: 1, borderColor: '#EF444420' }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                        <MaterialIcons name="warning" size={14} color="#EF4444" />
                        <Text style={{ fontSize: 12, fontWeight: '700', color: '#EF4444' }}>
                          {multiAccountFps.length} {isFr ? 'appareil(s) multi-compte detecte(s)' : 'multi-account device(s) detected'}
                        </Text>
                      </View>
                      {multiAccountFps.slice(0, 3).map(([fp, regs]) => {
                        const emails = [...new Set(regs.map(r => r.email))];
                        return (
                          <View key={fp} style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 6, borderTopWidth: 1, borderTopColor: '#EF444415' }}>
                            <Text style={{ fontSize: 9, fontWeight: '600', color: theme.textMuted, fontFamily: 'monospace' }}>{fp.substring(0, 12)}...</Text>
                            <View style={{ flex: 1 }}>
                              {emails.map(e => <Text key={e} style={{ fontSize: 11, color: '#EF4444', fontWeight: '600' }}>{e}</Text>)}
                            </View>
                            <Pressable
                              style={{ backgroundColor: '#EF444415', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 }}
                              onPress={async () => {
                                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                                const { error: err, count } = await adminUnlinkAllForDevice(fp);
                                if (err) { showAlert('Error', err); return; }
                                setDeviceRegs(prev => prev.filter(d => d.fingerprint !== fp));
                                showAlert(isFr ? `${count} enregistrement(s) supprime(s)` : `${count} registration(s) removed`);
                              }}
                            >
                              <Text style={{ fontSize: 10, fontWeight: '700', color: '#EF4444' }}>{isFr ? 'Tout delier' : 'Unlink all'}</Text>
                            </Pressable>
                          </View>
                        );
                      })}
                    </View>
                  ) : null}

                  <Text style={{ fontSize: 11, color: theme.textMuted, marginBottom: 8, fontWeight: '600' }}>
                    {filteredDevices.length} {isFr ? 'enregistrement(s)' : 'registration(s)'}
                  </Text>

                  {filteredDevices.slice(0, 50).map((d) => (
                    <View key={d.id} style={st.deviceCard}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                        <View style={{ flex: 1 }}>
                          <Text style={{ fontSize: 13, fontWeight: '600', color: theme.textPrimary }}>{d.email || 'Unknown'}</Text>
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 }}>
                            <Text style={{ fontSize: 9, color: theme.textMuted, fontFamily: 'monospace' }}>{d.fingerprint}</Text>
                            {(d as any).authMethod ? (
                              <View style={{ backgroundColor: (d as any).authMethod === 'google' ? '#EA433515' : '#3B82F615', paddingHorizontal: 5, paddingVertical: 1, borderRadius: 4 }}>
                                <Text style={{ fontSize: 8, fontWeight: '700', color: (d as any).authMethod === 'google' ? '#EA4335' : '#3B82F6' }}>{((d as any).authMethod || 'email').toUpperCase()}</Text>
                              </View>
                            ) : null}
                          </View>
                          <Text style={{ fontSize: 10, color: theme.textMuted, marginTop: 2 }}>
                            {new Date(d.registeredAt).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </Text>
                        </View>
                        <Pressable
                          style={[st.deviceUnlinkBtn, unlinkingId === d.id && { opacity: 0.6 }]}
                          onPress={async () => {
                            Haptics.selectionAsync();
                            setUnlinkingId(d.id);
                            const { error: err } = await adminUnlinkDevice(d.id);
                            setUnlinkingId(null);
                            if (err) { showAlert('Error', err); return; }
                            setDeviceRegs(prev => prev.filter(r => r.id !== d.id));
                            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                          }}
                          disabled={unlinkingId === d.id}
                        >
                          {unlinkingId === d.id ? <ActivityIndicator size="small" color="#EF4444" /> : (
                            <><MaterialIcons name="link-off" size={14} color="#EF4444" /><Text style={{ fontSize: 11, fontWeight: '700', color: '#EF4444' }}>{isFr ? 'Delier' : 'Unlink'}</Text></>
                          )}
                        </Pressable>
                      </View>
                    </View>
                  ))}
                  {filteredDevices.length > 50 ? (
                    <Text style={{ fontSize: 11, color: theme.textMuted, textAlign: 'center', paddingVertical: 8 }}>+{filteredDevices.length - 50} {isFr ? 'autres' : 'more'}...</Text>
                  ) : null}
                </>
              );
            })()}
          </View>
        ) : null}
      </View>

      {/* Status filter chips */}
      <View><ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={st.filterRow}>
        {(['all', 'geoAlerts', 'temporalAlerts', 'behavioralAlerts', 'statisticalAlerts', 'identityAlerts', 'socialAlerts', 'flagged', 'watch', 'ok', 'dismissed', 'banned'] as StatusFilter[]).map(sf => {
          const isAlertFilter = sf === 'geoAlerts' || sf === 'temporalAlerts' || sf === 'behavioralAlerts' || sf === 'statisticalAlerts' || sf === 'identityAlerts' || sf === 'socialAlerts';
          const isActive = statusFilter === sf;
          const alertColor = isAlertFilter ? getStatusColor(sf) : theme.textSecondary;
          return (
            <Pressable
              key={sf}
              style={[st.filterChip, isAlertFilter && !isActive && { borderColor: alertColor, borderWidth: 1.5, backgroundColor: alertColor + '08' }, isActive && { backgroundColor: sf === 'all' ? theme.primary : getStatusColor(sf), borderColor: sf === 'all' ? theme.primary : getStatusColor(sf) }]}
              onPress={() => { Haptics.selectionAsync(); setStatusFilter(sf); }}
            >
              {isAlertFilter && !isActive ? (
                <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: alertColor }} />
              ) : null}
              <Text style={[st.filterChipText, isAlertFilter && !isActive && { color: alertColor, fontWeight: '700' }, isActive && { color: '#FFF' }]}>{sf === 'all' ? (isFr ? 'Tous' : 'All') : getStatusLabel(sf)}</Text>
              <View style={[st.filterCount, isAlertFilter && !isActive && { backgroundColor: alertColor + '20' }, isActive && { backgroundColor: 'rgba(255,255,255,0.3)' }]}>
                <Text style={[st.filterCountText, isAlertFilter && !isActive && { color: alertColor }, isActive && { color: '#FFF' }]}>{statusCounts[sf]}</Text>
              </View>
            </Pressable>
          );
        })}
      </ScrollView></View>

      {/* Trust score range filter chips */}
      <View style={st.trustFilterWrap}>
        <View style={st.trustFilterHeader}>
          <MaterialIcons name="verified-user" size={12} color={theme.textMuted} />
          <Text style={st.trustFilterLabel}>{isFr ? 'Score de confiance' : 'Trust score'}</Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={st.filterRow}>
          {(['all', 'verified', 'high', 'medium', 'low', 'critical'] as TrustScoreFilter[]).map(tf => {
            const rangeColor = tf === 'all' ? theme.primary : TRUST_SCORE_RANGES[tf].color;
            const isActive = trustScoreFilter === tf;
            return (
              <Pressable
                key={tf}
                style={[st.filterChip, isActive && { backgroundColor: rangeColor, borderColor: rangeColor }]}
                onPress={() => { Haptics.selectionAsync(); setTrustScoreFilter(tf); }}
              >
                <Text style={[st.filterChipText, isActive && { color: '#FFF' }]}>{getTrustScoreLabel(tf)}</Text>
                <View style={[st.filterCount, isActive && { backgroundColor: 'rgba(255,255,255,0.3)' }]}>
                  <Text style={[st.filterCountText, isActive && { color: '#FFF' }]}>{trustScoreCounts[tf]}</Text>
                </View>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      {/* Sort mode chips */}
      <View style={st.trustFilterWrap}>
        <View style={st.trustFilterHeader}>
          <MaterialIcons name="sort" size={12} color={theme.textMuted} />
          <Text style={st.trustFilterLabel}>{isFr ? 'Trier par' : 'Sort by'}</Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={st.filterRow}>
          {(['default', 'trustAsc', 'trustDesc', 'analysisRecent', 'analysisOld', 'nocturnalDesc', 'unrealisticDurationDesc', 'massSubmissionDesc', 'selfMatchDesc', 'symmetricStreakDesc', 'ghostRatioDesc'] as SortMode[]).map(sm => {
            const isActive = sortMode === sm;
            const iconName: any = sm === 'trustAsc' ? 'arrow-upward'
              : sm === 'trustDesc' ? 'arrow-downward'
              : sm === 'analysisRecent' ? 'schedule'
              : sm === 'analysisOld' ? 'history'
              : sm === 'nocturnalDesc' ? 'nightlight-round'
              : sm === 'unrealisticDurationDesc' ? 'timer-off'
              : sm === 'massSubmissionDesc' ? 'flash-on'
              : sm === 'selfMatchDesc' ? 'content-copy'
              : sm === 'symmetricStreakDesc' ? 'repeat'
              : sm === 'ghostRatioDesc' ? 'person-off'
              : 'list';
            const label = sm === 'default' ? (isFr ? 'Par defaut' : 'Default')
              : sm === 'trustAsc' ? (isFr ? 'Score bas' : 'Score low')
              : sm === 'trustDesc' ? (isFr ? 'Score haut' : 'Score high')
              : sm === 'analysisRecent' ? (isFr ? 'Analyse recente' : 'Recent scan')
              : sm === 'analysisOld' ? (isFr ? 'Analyse ancienne' : 'Old scan')
              : sm === 'nocturnalDesc' ? (isFr ? 'Nocturnes' : 'Nocturnal')
              : sm === 'unrealisticDurationDesc' ? (isFr ? 'Durees' : 'Durations')
              : sm === 'massSubmissionDesc' ? (isFr ? 'Volume' : 'Volume')
              : sm === 'selfMatchDesc' ? (isFr ? 'Auto-affr.' : 'Self-match')
              : sm === 'symmetricStreakDesc' ? (isFr ? 'Serie sym.' : 'Symmetric')
              : (isFr ? 'Fantomes' : 'Ghosts');
            return (
              <Pressable
                key={sm}
                style={[st.filterChip, isActive && { backgroundColor: '#7C3AED', borderColor: '#7C3AED' }]}
                onPress={() => { Haptics.selectionAsync(); setSortMode(sm); }}
              >
                <MaterialIcons name={iconName} size={12} color={isActive ? '#FFF' : theme.textSecondary} />
                <Text style={[st.filterChipText, isActive && { color: '#FFF' }]}>{label}</Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      {/* Search */}
      <View style={st.searchBar}>
        <MaterialIcons name="search" size={18} color={theme.textMuted} />
        <TextInput style={st.searchInput} value={search} onChangeText={setSearch} placeholder={isFr ? 'Rechercher un joueur...' : 'Search player...'} placeholderTextColor={theme.textMuted} />
        {search.length > 0 ? <Pressable onPress={() => setSearch('')} hitSlop={8}><MaterialIcons name="close" size={16} color={theme.textMuted} /></Pressable> : null}
      </View>

      {/* Bulk actions on the currently filtered results */}
      {(statusFilter !== 'all' || trustScoreFilter !== 'all' || search.trim().length > 0) && filtered.length > 0 ? (
        <View style={st.bulkActionsBar}>
          <View style={st.bulkActionsInfo}>
            <MaterialIcons name="playlist-add-check" size={14} color={theme.primary} />
            <Text style={st.bulkActionsCount}>{filtered.length} {isFr ? 'filtre(s)' : 'filtered'}</Text>
          </View>
          <View style={st.bulkActionsBtns}>
            <Pressable
              style={[st.bulkActionBtn, { backgroundColor: '#6B728015' }, bulkBusy && { opacity: 0.5 }]}
              onPress={handleBulkDismissFiltered}
              disabled={bulkBusy}
            >
              {bulkBusy ? <ActivityIndicator size="small" color="#6B7280" /> : <MaterialIcons name="check" size={13} color="#6B7280" />}
              <Text style={[st.bulkActionBtnText, { color: '#6B7280' }]}>{isFr ? 'Ignorer tout' : 'Dismiss all'}</Text>
            </Pressable>
            <Pressable
              style={[st.bulkActionBtn, { backgroundColor: '#EF444415' }, bulkBusy && { opacity: 0.5 }]}
              onPress={handleBulkBanFiltered}
              disabled={bulkBusy}
            >
              {bulkBusy ? <ActivityIndicator size="small" color="#EF4444" /> : <MaterialIcons name="block" size={13} color="#EF4444" />}
              <Text style={[st.bulkActionBtnText, { color: '#EF4444' }]}>{isFr ? 'Bannir tout' : 'Ban all'}</Text>
            </Pressable>
            {statusFilter === 'temporalAlerts' ? (
              <Pressable
                style={[st.bulkActionBtn, { backgroundColor: '#8B5CF615' }, bulkBusy && { opacity: 0.5 }]}
                onPress={handleBulkTemporalNotify}
                disabled={bulkBusy}
              >
                {bulkBusy ? <ActivityIndicator size="small" color="#8B5CF6" /> : <MaterialIcons name="notifications-active" size={13} color="#8B5CF6" />}
                <Text style={[st.bulkActionBtnText, { color: '#8B5CF6' }]}>{isFr ? 'Rappel push' : 'Notify'}</Text>
              </Pressable>
            ) : null}
            {statusFilter === 'behavioralAlerts' ? (
              <Pressable
                style={[st.bulkActionBtn, { backgroundColor: '#EC489915' }, bulkBusy && { opacity: 0.5 }]}
                onPress={handleBulkBehavioralNotify}
                disabled={bulkBusy}
              >
                {bulkBusy ? <ActivityIndicator size="small" color="#EC4899" /> : <MaterialIcons name="psychology" size={13} color="#EC4899" />}
                <Text style={[st.bulkActionBtnText, { color: '#EC4899' }]}>{isFr ? 'Rappel push' : 'Notify'}</Text>
              </Pressable>
            ) : null}
            {statusFilter === 'behavioralAlerts' ? (
              <Pressable
                style={[st.bulkActionBtn, { backgroundColor: '#DB277715' }, bulkBusy && { opacity: 0.5 }]}
                onPress={handleBulkBanBehavioral}
                disabled={bulkBusy}
              >
                {bulkBusy ? <ActivityIndicator size="small" color="#DB2777" /> : <MaterialIcons name="gpp-bad" size={13} color="#DB2777" />}
                <Text style={[st.bulkActionBtnText, { color: '#DB2777' }]}>{isFr ? 'Bannir comport.' : 'Ban behav.'}</Text>
              </Pressable>
            ) : null}
          </View>
        </View>
      ) : null}

      <View style={st.listInner}>
        {loading ? (
          <View style={{ paddingVertical: 60, alignItems: 'center' }}>
            <ActivityIndicator size="large" color={theme.primary} />
          </View>
        ) : filtered.length === 0 ? (
          <View style={{ paddingVertical: 60, alignItems: 'center' }}>
            <MaterialIcons name="check-circle" size={48} color={theme.success} />
            <Text style={{ fontSize: 16, fontWeight: '600', color: theme.textPrimary, marginTop: 12 }}>
              {(et.adminNoPlayers as any)?.[language] || 'No players'}
            </Text>
          </View>
        ) : (
          filtered.map((p, idx) => {
            const scoreColor = getTrustScoreColor(p.trustScore);
            const level = getLevelFromScore(p.trustScore);
            return (
              <View key={p.id}>
                <Pressable
                  style={[st.playerCard, { borderLeftColor: getStatusColor(p.status) }]}
                  onPress={() => { setSelectedPlayer(p); setAdminNotes(p.adminNotes || ''); }}
                >
                  <View style={st.playerHeader}>
                    <View style={st.playerAvatar}>
                      {p.playerAvatar ? (
                        <Image source={{ uri: p.playerAvatar }} style={{ width: 40, height: 40, borderRadius: 12 }} contentFit="cover" />
                      ) : (
                        <Text style={{ fontSize: 16, fontWeight: '700', color: theme.textSecondary }}>{(p.playerName || '?').charAt(0)}</Text>
                      )}
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={st.playerName}>{p.playerName || p.playerId.substring(0, 8)}</Text>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 }}>
                        <View style={[st.statusBadge, { backgroundColor: getStatusColor(p.status) + '15', borderColor: getStatusColor(p.status) + '30' }]}>
                          <Text style={[st.statusBadgeText, { color: getStatusColor(p.status) }]}>{getStatusLabel(p.status)}</Text>
                        </View>
                        {p.flags.length > 0 ? (
                          <View style={st.flagCountBadge}>
                            <MaterialIcons name="flag" size={10} color="#EF4444" />
                            <Text style={st.flagCountText}>{p.flags.length}</Text>
                          </View>
                        ) : null}
                      </View>
                    </View>
                    <View style={[st.scoreCircle, { borderColor: scoreColor }]}>
                      <Text style={[st.scoreText, { color: scoreColor }]}>{p.trustScore}</Text>
                    </View>
                  </View>
                  {p.flags.length > 0 ? (
                    <View style={st.flagsRow}>
                      {p.flags.slice(0, 3).map((flag: string, fi: number) => (
                        <View key={fi} style={st.flagChip}>
                          <Text style={st.flagChipText}>{flag.replace(/_/g, ' ')}</Text>
                        </View>
                      ))}
                      {p.flags.length > 3 ? <Text style={st.flagMore}>+{p.flags.length - 3}</Text> : null}
                    </View>
                  ) : null}
                  {/* Quick actions */}
                  <View style={st.quickActions}>
                    {p.status !== 'dismissed' ? (
                      <Pressable style={[st.qAction, { backgroundColor: '#6B728015' }]} onPress={() => handleUpdateStatus(p.id, 'dismissed')}>
                        <MaterialIcons name="check" size={14} color="#6B7280" />
                        <Text style={[st.qActionText, { color: '#6B7280' }]}>{(et.adminDismiss as any)?.[language] || 'Dismiss'}</Text>
                      </Pressable>
                    ) : null}
                    {p.status !== 'banned' ? (
                      <Pressable style={[st.qAction, { backgroundColor: '#EF444415' }]} onPress={() => handleUpdateStatus(p.id, 'banned')}>
                        <MaterialIcons name="block" size={14} color="#EF4444" />
                        <Text style={[st.qActionText, { color: '#EF4444' }]}>{(et.adminBan as any)?.[language] || 'Ban'}</Text>
                      </Pressable>
                    ) : null}
                    {p.status === 'banned' || p.status === 'dismissed' ? (
                      <Pressable style={[st.qAction, { backgroundColor: '#22C55E15' }]} onPress={() => handleUpdateStatus(p.id, 'ok')}>
                        <MaterialIcons name="undo" size={14} color="#22C55E" />
                        <Text style={[st.qActionText, { color: '#22C55E' }]}>{isFr ? 'Restaurer' : 'Restore'}</Text>
                      </Pressable>
                    ) : null}
                  </View>
                </Pressable>
              </View>
            );
          })
        )}
      </View>

      </ScrollView>

      {undoBan ? (
        <View style={st.undoToast}>
          <View style={st.undoToastIcon}>
            <MaterialIcons name="block" size={18} color="#FFF" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={st.undoToastLabel}>{undoBan.label}</Text>
            <Text style={st.undoToastSub}>{isFr ? `Annulez dans ${undoRemaining}s` : `Undo in ${undoRemaining}s`}</Text>
          </View>
          <Pressable style={st.undoToastBtn} onPress={handleUndoBan}>
            <MaterialIcons name="undo" size={14} color="#FFF" />
            <Text style={st.undoToastBtnText}>{isFr ? 'Annuler' : 'Undo'}</Text>
          </Pressable>
        </View>
      ) : null}

      {/* Detail Modal */}
      <Modal visible={selectedPlayer !== null} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setSelectedPlayer(null)}>
        <SafeAreaView style={st.detailContainer}>
          <View style={st.detailHeader}>
            <Pressable style={st.detailClose} onPress={() => setSelectedPlayer(null)}>
              <MaterialIcons name="close" size={24} color={theme.textPrimary} />
            </Pressable>
            <Text style={st.detailTitle}>{selectedPlayer?.playerName || 'Player'}</Text>
            <Pressable style={st.detailViewBtn} onPress={() => { setSelectedPlayer(null); router.push(`/player/${selectedPlayer?.playerId}` as any); }}>
              <MaterialIcons name="open-in-new" size={20} color={theme.primary} />
            </Pressable>
          </View>
          {selectedPlayer ? (
            <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32 }} showsVerticalScrollIndicator={false}>
              {/* Load deletion timeline when player selected */}
              {(() => {
                // Use a self-invoking component pattern to trigger load
                return null;
              })()}
              {/* Score hero */}
              <View style={[st.detailScoreCard, { borderColor: getTrustScoreColor(selectedPlayer.trustScore) + '30' }]}>
                <View style={[st.detailScoreCircle, { borderColor: getTrustScoreColor(selectedPlayer.trustScore) }]}>
                  <Text style={[st.detailScoreValue, { color: getTrustScoreColor(selectedPlayer.trustScore) }]}>{selectedPlayer.trustScore}</Text>
                  <Text style={st.detailScoreMax}>/100</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[st.detailLevel, { color: getTrustScoreColor(selectedPlayer.trustScore) }]}>
                    {getTrustLevelLabel(getLevelFromScore(selectedPlayer.trustScore), isFr)}
                  </Text>
                  <Text style={st.detailStatus}>Status: {getStatusLabel(selectedPlayer.status)}</Text>
                  <Text style={st.detailAnalyzed}>
                    {selectedPlayer.analyzedAt ? new Date(selectedPlayer.analyzedAt).toLocaleString(isFr ? 'fr-FR' : 'en-US') : '-'}
                  </Text>
                </View>
                <Pressable
                  style={st.adjustBtn}
                  onPress={() => { setAdjustScore(String(selectedPlayer.trustScore)); setShowAdjustModal(true); }}
                >
                  <MaterialIcons name="edit" size={16} color={theme.primary} />
                  <Text style={st.adjustBtnText}>{(et.adminAdjustScore as any)?.[language] || 'Adjust'}</Text>
                </Pressable>
              </View>

              {/* Statistical analysis trigger (Benford + ELO regression) */}
              {(selectedPlayer.details?.eloVariance || selectedPlayer.details?.benfordAnalysis) ? (
                <Pressable
                  style={st.statAnalysisSection}
                  onPress={() => { setShowStatModal(true); loadStatEloHistory(); }}
                >
                  <View style={[st.sectionIconBg, { backgroundColor: '#0EA5E915' }]}>
                    <MaterialIcons name="analytics" size={16} color="#0EA5E9" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={st.statAnalysisTitle}>{isFr ? 'Analyses statistiques' : 'Statistical analysis'}</Text>
                    <Text style={st.statAnalysisSub}>
                      {isFr ? 'Distribution Benford + courbe ELO avec regression' : 'Benford distribution + ELO curve with regression'}
                    </Text>
                  </View>
                  <MaterialIcons name="chevron-right" size={20} color="#0EA5E9" />
                </Pressable>
              ) : null}

              {/* Stats from details */}
              {selectedPlayer.details ? (
                <View style={st.detailSection}>
                  <Text style={st.detailSectionTitle}>{(et.adminPlayerStats as any)?.[language] || 'Stats'}</Text>
                  <View style={st.detailStatsGrid}>
                    {[
                      { label: 'Matches', value: selectedPlayer.details.totalMatches || selectedPlayer.details.matchesPlayed || '-' },
                      { label: 'Multi-player %', value: `${selectedPlayer.details.multiPlayerRatio || 0}%` },
                      { label: isFr ? 'Adversaires uniques' : 'Unique opponents', value: selectedPlayer.details.uniqueOpponents || '-' },
                      { label: isFr ? 'Coherence' : 'Consistency', value: `${selectedPlayer.details.performanceConsistency || 0}%` },
                      { label: isFr ? 'Modifs externes' : 'External mods', value: selectedPlayer.details.modificationLogs?.external || 0 },
                      { label: isFr ? 'Matchs/semaine' : 'Matches/week', value: selectedPlayer.details.matchesPerWeek || '-' },
                      { label: isFr ? 'Defaites supprimees' : 'Deleted losses', value: selectedPlayer.details.deletionAnalysis?.deletedLostMatches || 0 },
                      { label: isFr ? 'Perte ELO evitee' : 'ELO loss avoided', value: selectedPlayer.details.deletionAnalysis?.avoidedEloLoss ? `-${selectedPlayer.details.deletionAnalysis.avoidedEloLoss}` : '0' },
                      { label: isFr ? 'Anciennete (jours)' : 'Account age (days)', value: selectedPlayer.details.accountAgeDays || '-' },
                      { label: isFr ? 'Signalements' : 'Reports', value: selectedPlayer.details.totalReports || 0 },
                    ].map((stat, i) => (
                      <View key={i} style={st.detailStatItem}>
                        <Text style={st.detailStatValue}>{stat.value}</Text>
                        <Text style={st.detailStatLabel}>{stat.label}</Text>
                      </View>
                    ))}
                  </View>
                </View>
              ) : null}

              {/* Deletion Timeline & ELO Reversal */}
              {selectedPlayer.details?.deletionAnalysis?.deletedLostMatches > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <MaterialIcons name="delete-sweep" size={16} color="#EF4444" />
                      <Text style={st.detailSectionTitle}>{(et.deletionTimeline as any)?.[language] || 'Deletion History'}</Text>
                    </View>
                    <Pressable
                      style={[st.timelineLoadBtn, timelineLoading && { opacity: 0.6 }]}
                      onPress={async () => {
                        setTimelineLoading(true);
                        const { timeline } = await fetchDeletionTimeline(selectedPlayer.userId);
                        setDeletionTimeline(timeline);
                        // Build heatmap (7 days x 24 hours)
                        try {
                          const supabase = getSupabaseClient();
                          const { data: softDels } = await supabase
                            .from('soft_deletes')
                            .select('deleted_at')
                            .eq('user_id', selectedPlayer.userId)
                            .eq('table_name', 'matches');
                          const hm: number[][] = Array.from({ length: 7 }, () => Array(24).fill(0));
                          for (const sd of softDels || []) {
                            const dt = new Date(sd.deleted_at);
                            const dow = (dt.getDay() + 6) % 7; // Monday=0
                            const hour = dt.getHours();
                            hm[dow][hour]++;
                          }
                          setDeletionHeatmap(hm);
                        } catch { setDeletionHeatmap([]); }
                        setTimelineLoading(false);
                      }}
                      disabled={timelineLoading}
                    >
                      {timelineLoading ? <ActivityIndicator size="small" color="#EF4444" /> : <MaterialIcons name="refresh" size={14} color="#EF4444" />}
                      <Text style={{ fontSize: 11, fontWeight: '600', color: '#EF4444' }}>{timelineLoading ? '...' : (isFr ? 'Charger' : 'Load')}</Text>
                    </Pressable>
                  </View>

                  {/* Deletion Heatmap (day x hour) */}
                  {deletionHeatmap.length > 0 ? (
                    <View style={st.heatmapContainer}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 }}>
                        <MaterialIcons name="grid-on" size={14} color="#7C3AED" />
                        <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textSecondary }}>{(et.deletionHeatmapTitle as any)?.[language] || 'Deletion Heatmap'}</Text>
                      </View>
                      <Text style={{ fontSize: 9, color: theme.textMuted, marginBottom: 6 }}>{(et.deletionHeatmapDesc as any)?.[language] || 'Day vs hour'}</Text>
                      <View style={{ flexDirection: 'row', gap: 1 }}>
                        <View style={{ gap: 1, marginRight: 2 }}>
                          <View style={{ height: 12 }} />
                          {[isFr ? 'L' : 'M', isFr ? 'Ma' : 'Tu', isFr ? 'Me' : 'W', isFr ? 'J' : 'Th', isFr ? 'V' : 'F', isFr ? 'S' : 'Sa', isFr ? 'D' : 'Su'].map((d, i) => (
                            <View key={i} style={{ height: 12, justifyContent: 'center' }}>
                              <Text style={{ fontSize: 7, fontWeight: '600', color: theme.textMuted }}>{d}</Text>
                            </View>
                          ))}
                        </View>
                        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 1 }}>
                          {Array.from({ length: 24 }, (_, h) => {
                            return (
                              <View key={h} style={{ gap: 1, alignItems: 'center' }}>
                                <Text style={{ fontSize: 6, fontWeight: '600', color: theme.textMuted, height: 12, textAlign: 'center' }}>{h}</Text>
                                {Array.from({ length: 7 }, (_, d) => {
                                  const count = deletionHeatmap[d]?.[h] || 0;
                                  const maxHeat = Math.max(...deletionHeatmap.flat(), 1);
                                  const intensity = count / maxHeat;
                                  const bg = count === 0 ? theme.backgroundSecondary
                                    : intensity < 0.33 ? '#FDE047'
                                    : intensity < 0.66 ? '#F97316'
                                    : '#EF4444';
                                  return (
                                    <View key={d} style={{ width: 12, height: 12, borderRadius: 2, backgroundColor: bg }} />
                                  );
                                })}
                              </View>
                            );
                          })}
                        </ScrollView>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6, justifyContent: 'flex-end' }}>
                        <Text style={{ fontSize: 7, color: theme.textMuted }}>0</Text>
                        {[theme.backgroundSecondary, '#FDE047', '#F97316', '#EF4444'].map((c, i) => (
                          <View key={i} style={{ width: 10, height: 10, borderRadius: 2, backgroundColor: c }} />
                        ))}
                        <Text style={{ fontSize: 7, color: theme.textMuted }}>max</Text>
                      </View>
                    </View>
                  ) : null}

                  {/* Deletion summary stats */}
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EF4444' }]}>{selectedPlayer.details?.deletionAnalysis?.deletedLostMatches || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{(et.deletedLostMatches as any)?.[language] || 'Lost del.'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#DC2626' }]}>-{selectedPlayer.details?.deletionAnalysis?.avoidedEloLoss || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{(et.avoidedEloLoss as any)?.[language] || 'ELO avoided'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#F97316' }]}>{selectedPlayer.details?.deletionAnalysis?.recentDeletedLost7d || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{(et.recentDeletions7d as any)?.[language] || '7d'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details?.deletionAnalysis?.totalDeletedMatches || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{(et.totalDeletedMatches as any)?.[language] || 'Total'}</Text>
                    </View>
                  </View>

                  {/* Timeline chart */}
                  {deletionTimeline.length > 0 ? (
                    <View style={st.timelineContainer}>
                      <Text style={st.timelineLabel}>{(et.deletionTimelineDesc as any)?.[language] || 'Deleted losses per week'}</Text>
                      <View style={st.timelineChart}>
                        {(() => {
                          const maxVal = Math.max(...deletionTimeline.map(t => t.deletedLostCount), 1);
                          const maxElo = Math.max(...deletionTimeline.map(t => t.avoidedEloLoss), 1);
                          return deletionTimeline.slice(-12).map((point, idx) => {
                            const barHeight = Math.max(4, (point.deletedLostCount / maxVal) * 60);
                            const eloBarHeight = Math.max(2, (point.avoidedEloLoss / maxElo) * 60);
                            const weekLabel = point.weekStart.substring(5);
                            return (
                              <View key={point.weekStart} style={st.timelineBarGroup}>
                                <View style={st.timelineBarsWrap}>
                                  <View style={[st.timelineBar, { height: barHeight, backgroundColor: '#EF4444' }]} />
                                  <View style={[st.timelineBarElo, { height: eloBarHeight, backgroundColor: '#F59E0B' }]} />
                                </View>
                                <Text style={st.timelineBarValue}>{point.deletedLostCount}</Text>
                                <Text style={st.timelineBarWeek}>{weekLabel}</Text>
                                {point.avoidedEloLoss > 0 ? (
                                  <Text style={st.timelineBarEloValue}>-{point.avoidedEloLoss}</Text>
                                ) : null}
                              </View>
                            );
                          });
                        })()}
                      </View>
                      <View style={st.timelineLegend}>
                        <View style={st.timelineLegendItem}>
                          <View style={[st.timelineLegendDot, { backgroundColor: '#EF4444' }]} />
                          <Text style={st.timelineLegendText}>{(et.deletionTimelineLost as any)?.[language] || 'Losses'}</Text>
                        </View>
                        <View style={st.timelineLegendItem}>
                          <View style={[st.timelineLegendDot, { backgroundColor: '#F59E0B' }]} />
                          <Text style={st.timelineLegendText}>ELO</Text>
                        </View>
                      </View>
                    </View>
                  ) : null}

                  {/* ELO Reversal button */}
                  <Pressable
                    style={[st.reverseEloBtn, reversingElo && { opacity: 0.6 }]}
                    onPress={() => {
                      const avoidedElo = selectedPlayer.details?.deletionAnalysis?.avoidedEloLoss || 0;
                      if (avoidedElo === 0) {
                        showAlert((et.reverseEloNone as any)?.[language] || 'No ELO to reverse');
                        return;
                      }
                      showAlert(
                        (et.reverseEloConfirmTitle as any)?.[language] || 'Reverse ELO?',
                        ((et.reverseEloConfirmMsg as any)?.[language] || 'Subtract {elo} ELO pts').replace('{elo}', String(avoidedElo)),
                        [
                          { text: isFr ? 'Annuler' : 'Cancel', style: 'cancel' },
                          {
                            text: (et.reverseElo as any)?.[language] || 'Reverse',
                            style: 'destructive',
                            onPress: async () => {
                              setReversingElo(true);
                              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
                              const { error, eloBefore, eloAfter, matchesReversed } = await reverseDeletedEloLoss(
                                selectedPlayer.userId,
                                selectedPlayer.playerId
                              );
                              setReversingElo(false);
                              if (error) {
                                showAlert('Error', error);
                              } else {
                                const msg = ((et.reverseEloSuccess as any)?.[language] || 'Reversed: {before} -> {after} ({count})')
                                  .replace('{before}', String(eloBefore))
                                  .replace('{after}', String(eloAfter))
                                  .replace('{count}', String(matchesReversed));
                                showAlert(msg);
                                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                              }
                            },
                          },
                        ]
                      );
                    }}
                    disabled={reversingElo}
                  >
                    {reversingElo ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="undo" size={16} color="#FFF" />}
                    <Text style={st.reverseEloBtnText}>
                      {reversingElo
                        ? ((et.reversing as any)?.[language] || 'Reversing...')
                        : `${(et.reverseElo as any)?.[language] || 'Reverse ELO'} (-${selectedPlayer.details?.deletionAnalysis?.avoidedEloLoss || 0} pts)`}
                    </Text>
                  </Pressable>
                </View>
              ) : null}

              {/* Home City Mismatch */}
              {(selectedPlayer.flags.includes('distant_from_home_city') || selectedPlayer.flags.includes('frequent_distant_from_home_city')) && selectedPlayer.details?.homeCityConsistency ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="location-off" size={16} color="#F97316" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Matchs eloignes de la ville declaree' : 'Matches far from declared city'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#F97316' }]}>{selectedPlayer.details.homeCityConsistency.distantMatchesCount || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Distants' : 'Distant'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EF4444' }]}>{selectedPlayer.details.homeCityConsistency.distantRatio || 0}%</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Ratio' : 'Ratio'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details.homeCityConsistency.totalMatchesWithGeo || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Total geo' : 'Geo total'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary, fontSize: 12 }]} numberOfLines={1}>{selectedPlayer.details.homeCityConsistency.homeCity || '-'}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Ville declaree' : 'Home city'}</Text>
                    </View>
                  </View>
                  {Array.isArray(selectedPlayer.details.homeCityConsistency.examples) && selectedPlayer.details.homeCityConsistency.examples.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Exemples (${selectedPlayer.details.homeCityConsistency.examples.length})` : `Examples (${selectedPlayer.details.homeCityConsistency.examples.length})`}
                      </Text>
                      {selectedPlayer.details.homeCityConsistency.examples.map((ex: any, i: number) => (
                        <View key={i} style={st.geoAlertRow}>
                          <View style={[st.geoAlertIcon, { backgroundColor: '#F9731615' }]}>
                            <MaterialIcons name="place" size={14} color="#F97316" />
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={st.geoAlertTitle} numberOfLines={1}>{ex.terrainName || (isFr ? 'Terrain inconnu' : 'Unknown terrain')}</Text>
                            <Text style={st.geoAlertMeta}>
                              {ex.distanceKm} km • {ex.date ? new Date(ex.date).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                            </Text>
                          </View>
                          <View style={[st.geoAlertBadge, { backgroundColor: '#F9731615' }]}>
                            <Text style={[st.geoAlertBadgeText, { color: '#F97316' }]}>{ex.distanceKm} km</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Impossible Travel */}
              {selectedPlayer.details?.impossibleTravel && selectedPlayer.details.impossibleTravel.count > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="flight-takeoff" size={16} color="#EF4444" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Trajets geographiques impossibles' : 'Impossible geographic travel'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EF4444' }]}>{selectedPlayer.details.impossibleTravel.count}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Trajets' : 'Trips'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details.impossibleTravel.matchesWithGeo || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Matchs geo' : 'Geo matches'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EF4444', fontSize: 12 }]}>{'> 500 km'}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? '< 6 h' : '< 6 h'}</Text>
                    </View>
                  </View>
                  {Array.isArray(selectedPlayer.details.impossibleTravel.pairs) && selectedPlayer.details.impossibleTravel.pairs.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Paires (${selectedPlayer.details.impossibleTravel.pairs.length})` : `Pairs (${selectedPlayer.details.impossibleTravel.pairs.length})`}
                      </Text>
                      {selectedPlayer.details.impossibleTravel.pairs.map((p: any, i: number) => {
                        const coordsA = (Number.isFinite(p.latA) && Number.isFinite(p.lngA))
                          ? { lat: p.latA, lng: p.lngA }
                          : (p.matchAId ? pairCoordsMap.get(p.matchAId) : null);
                        const coordsB = (Number.isFinite(p.latB) && Number.isFinite(p.lngB))
                          ? { lat: p.latB, lng: p.lngB }
                          : (p.matchBId ? pairCoordsMap.get(p.matchBId) : null);
                        return (
                        <View key={i} style={st.geoAlertPairCard}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                            <MaterialIcons name="place" size={12} color="#EF4444" />
                            <Text style={st.geoAlertPairTerrain} numberOfLines={1}>{p.terrainA || (isFr ? 'Terrain A' : 'Terrain A')}</Text>
                            <MaterialIcons name="arrow-forward" size={12} color={theme.textMuted} />
                            <Text style={st.geoAlertPairTerrain} numberOfLines={1}>{p.terrainB || (isFr ? 'Terrain B' : 'Terrain B')}</Text>
                          </View>
                          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
                            <View style={[st.geoAlertMetric, { backgroundColor: '#EF444415' }]}>
                              <Text style={[st.geoAlertMetricValue, { color: '#EF4444' }]}>{p.distanceKm} km</Text>
                            </View>
                            <View style={[st.geoAlertMetric, { backgroundColor: '#F5A0B15' }]}>
                              <Text style={[st.geoAlertMetricValue, { color: '#F97316' }]}>{p.hoursBetween} h</Text>
                            </View>
                            <View style={[st.geoAlertMetric, { backgroundColor: '#DC262615' }]}>
                              <Text style={[st.geoAlertMetricValue, { color: '#DC2626' }]}>{p.requiredSpeedKmh} km/h</Text>
                            </View>
                          </View>
                          {p.matchADate ? (
                            <Text style={st.geoAlertPairDate}>
                              {new Date(p.matchADate).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                              {' → '}
                              {p.matchBDate ? new Date(p.matchBDate).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '-'}
                            </Text>
                          ) : null}
                          {coordsA && coordsB ? (
                            <MiniTravelMap
                              latA={coordsA.lat} lngA={coordsA.lng}
                              latB={coordsB.lat} lngB={coordsB.lng}
                              labelA={p.terrainA} labelB={p.terrainB}
                              distanceKm={p.distanceKm}
                              color="#EF4444"
                              height={130}
                            />
                          ) : null}
                        </View>
                        );
                      })}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Micro-Teleportation */}
              {selectedPlayer.details?.microTeleportation && selectedPlayer.details.microTeleportation.count > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="speed" size={16} color="#F97316" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Micro-teleportations' : 'Micro-teleportations'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#F97316' }]}>{selectedPlayer.details.microTeleportation.count}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Detectees' : 'Detected'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details.microTeleportation.matchesWithGeo || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Matchs geo' : 'Geo matches'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#F97316', fontSize: 12 }]}>{'> 200 km'}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? '< 2 h' : '< 2 h'}</Text>
                    </View>
                  </View>
                  {Array.isArray(selectedPlayer.details.microTeleportation.pairs) && selectedPlayer.details.microTeleportation.pairs.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Paires (${selectedPlayer.details.microTeleportation.pairs.length})` : `Pairs (${selectedPlayer.details.microTeleportation.pairs.length})`}
                      </Text>
                      {selectedPlayer.details.microTeleportation.pairs.map((p: any, i: number) => {
                        const coordsA = (Number.isFinite(p.latA) && Number.isFinite(p.lngA))
                          ? { lat: p.latA, lng: p.lngA }
                          : (p.matchAId ? pairCoordsMap.get(p.matchAId) : null);
                        const coordsB = (Number.isFinite(p.latB) && Number.isFinite(p.lngB))
                          ? { lat: p.latB, lng: p.lngB }
                          : (p.matchBId ? pairCoordsMap.get(p.matchBId) : null);
                        return (
                        <View key={i} style={[st.geoAlertPairCard, { borderLeftColor: '#F97316' }]}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                            <MaterialIcons name="place" size={12} color="#F97316" />
                            <Text style={st.geoAlertPairTerrain} numberOfLines={1}>{p.terrainA || (isFr ? 'Terrain A' : 'Terrain A')}</Text>
                            <MaterialIcons name="arrow-forward" size={12} color={theme.textMuted} />
                            <Text style={st.geoAlertPairTerrain} numberOfLines={1}>{p.terrainB || (isFr ? 'Terrain B' : 'Terrain B')}</Text>
                          </View>
                          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
                            <View style={[st.geoAlertMetric, { backgroundColor: '#F9731615' }]}>
                              <Text style={[st.geoAlertMetricValue, { color: '#F97316' }]}>{p.distanceKm} km</Text>
                            </View>
                            <View style={[st.geoAlertMetric, { backgroundColor: '#D9770615' }]}>
                              <Text style={[st.geoAlertMetricValue, { color: '#D97706' }]}>{p.hoursBetween} h</Text>
                            </View>
                            <View style={[st.geoAlertMetric, { backgroundColor: '#EA580C15' }]}>
                              <Text style={[st.geoAlertMetricValue, { color: '#EA580C' }]}>{p.requiredSpeedKmh} km/h</Text>
                            </View>
                          </View>
                          {p.matchADate ? (
                            <Text style={st.geoAlertPairDate}>
                              {new Date(p.matchADate).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                              {' → '}
                              {p.matchBDate ? new Date(p.matchBDate).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '-'}
                            </Text>
                          ) : null}
                          {coordsA && coordsB ? (
                            <MiniTravelMap
                              latA={coordsA.lat} lngA={coordsA.lng}
                              latB={coordsB.lat} lngB={coordsB.lng}
                              labelA={p.terrainA} labelB={p.terrainB}
                              distanceKm={p.distanceKm}
                              color="#F97316"
                              height={130}
                            />
                          ) : null}
                        </View>
                        );
                      })}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Unrealistic Match Duration */}
              {selectedPlayer.details?.unrealisticDuration && selectedPlayer.details.unrealisticDuration.count > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="timer-off" size={16} color="#F97316" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Durees de matchs irrealistes' : 'Unrealistic match durations'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#F97316' }]}>{selectedPlayer.details.unrealisticDuration.count}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Matchs' : 'Matches'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EF4444' }]}>{selectedPlayer.details.unrealisticDuration.ratio || 0}%</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Ratio' : 'Ratio'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details.unrealisticDuration.totalWithDuration || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Total dur.' : 'Total dur.'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#8B5CF6', fontSize: 11 }]}>{'<5m / >4h'}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Seuils' : 'Thresholds'}</Text>
                    </View>
                  </View>
                  {Array.isArray(selectedPlayer.details.unrealisticDuration.examples) && selectedPlayer.details.unrealisticDuration.examples.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Exemples (${selectedPlayer.details.unrealisticDuration.examples.length})` : `Examples (${selectedPlayer.details.unrealisticDuration.examples.length})`}
                      </Text>
                      {selectedPlayer.details.unrealisticDuration.examples.map((ex: any, i: number) => {
                        const kind = ex.tooShort ? (isFr ? 'Trop court' : 'Too short') : (isFr ? 'Trop long' : 'Too long');
                        const kindColor = ex.tooShort ? '#F97316' : '#EF4444';
                        return (
                          <View key={i} style={st.geoAlertRow}>
                            <View style={[st.geoAlertIcon, { backgroundColor: kindColor + '15' }]}>
                              <MaterialIcons name="schedule" size={14} color={kindColor} />
                            </View>
                            <View style={{ flex: 1 }}>
                              <Text style={st.geoAlertTitle} numberOfLines={1}>{ex.durationMin} min - {kind}</Text>
                              <Text style={st.geoAlertMeta}>{ex.date ? new Date(ex.date).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '-'}</Text>
                            </View>
                            <View style={[st.geoAlertBadge, { backgroundColor: kindColor + '15' }]}>
                              <Text style={[st.geoAlertBadgeText, { color: kindColor }]}>{ex.durationMin}m</Text>
                            </View>
                          </View>
                        );
                      })}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Nocturnal Pattern */}
              {selectedPlayer.details?.nocturnalActivity && selectedPlayer.details.nocturnalActivity.count > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="nightlight-round" size={16} color="#7C3AED" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Activite nocturne (3h-6h locale)' : 'Nocturnal activity (3AM-6AM local)'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#7C3AED' }]}>{selectedPlayer.details.nocturnalActivity.count}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Matchs' : 'Matches'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#8B5CF6' }]}>{selectedPlayer.details.nocturnalActivity.ratio || 0}%</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Ratio' : 'Ratio'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details.nocturnalActivity.totalMatches || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Total' : 'Total'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#7C3AED', fontSize: 12 }]}>3h-6h</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Fenetre' : 'Window'}</Text>
                    </View>
                  </View>
                  {selectedPlayer.details.nocturnalActivity.timezoneAware ? (
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8, backgroundColor: '#7C3AED08', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 }}>
                      <MaterialIcons name="public" size={12} color="#7C3AED" />
                      <Text style={{ fontSize: 10, fontWeight: '600', color: '#7C3AED', flex: 1 }}>
                        {isFr ? 'Detection basee sur le fuseau horaire estime du terrain' : 'Detection based on estimated terrain timezone'}
                      </Text>
                    </View>
                  ) : null}
                  {Array.isArray(selectedPlayer.details.nocturnalActivity.examples) && selectedPlayer.details.nocturnalActivity.examples.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Exemples (${selectedPlayer.details.nocturnalActivity.examples.length})` : `Examples (${selectedPlayer.details.nocturnalActivity.examples.length})`}
                      </Text>
                      {selectedPlayer.details.nocturnalActivity.examples.map((ex: any, i: number) => (
                        <View key={i} style={st.geoAlertRow}>
                          <View style={[st.geoAlertIcon, { backgroundColor: '#7C3AED15' }]}>
                            <MaterialIcons name="nights-stay" size={14} color="#7C3AED" />
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={st.geoAlertTitle} numberOfLines={1}>{isFr ? 'Heure locale' : 'Local hour'}: {String(ex.hour ?? 0).padStart(2, '0')}:00</Text>
                            <Text style={st.geoAlertMeta}>
                              {ex.date ? new Date(ex.date).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                              {ex.hasTerrainTz ? ` - UTC${ex.tzOffsetHours >= 0 ? '+' : ''}${ex.tzOffsetHours}` : ' - UTC'}
                            </Text>
                          </View>
                          <View style={[st.geoAlertBadge, { backgroundColor: '#7C3AED15' }]}>
                            <Text style={[st.geoAlertBadgeText, { color: '#7C3AED' }]}>{String(ex.hour ?? 0).padStart(2, '0')}h</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Mass Submission */}
              {selectedPlayer.details?.massSubmission && selectedPlayer.details.massSubmission.daysCount > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="flash-on" size={16} color="#DC2626" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Soumission massive de matchs' : 'Mass match submission'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#DC2626' }]}>{selectedPlayer.details.massSubmission.daysCount}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Jours' : 'Days'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EF4444' }]}>{selectedPlayer.details.massSubmission.maxDailyCount || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Max/jour' : 'Max/day'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary, fontSize: 12 }]}>{'>20 / 24h'}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Seuil' : 'Threshold'}</Text>
                    </View>
                  </View>
                  {Array.isArray(selectedPlayer.details.massSubmission.examples) && selectedPlayer.details.massSubmission.examples.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Exemples (${selectedPlayer.details.massSubmission.examples.length})` : `Examples (${selectedPlayer.details.massSubmission.examples.length})`}
                      </Text>
                      {selectedPlayer.details.massSubmission.examples.map((ex: any, i: number) => (
                        <View key={i} style={st.geoAlertRow}>
                          <View style={[st.geoAlertIcon, { backgroundColor: '#DC262615' }]}>
                            <MaterialIcons name="today" size={14} color="#DC2626" />
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={st.geoAlertTitle} numberOfLines={1}>{ex.day ? new Date(ex.day).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' }) : '-'}</Text>
                            <Text style={st.geoAlertMeta}>{ex.count} {isFr ? 'matchs enregistres' : 'matches recorded'}</Text>
                          </View>
                          <View style={[st.geoAlertBadge, { backgroundColor: '#DC262615' }]}>
                            <Text style={[st.geoAlertBadgeText, { color: '#DC2626' }]}>{ex.count}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Self-Match Detection */}
              {selectedPlayer.details?.selfMatches && selectedPlayer.details.selfMatches.count > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="content-copy" size={16} color="#EC4899" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Auto-affrontements detectes' : 'Self-match detection'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EC4899' }]}>{selectedPlayer.details.selfMatches.count}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Matchs' : 'Matches'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#DB2777' }]}>{selectedPlayer.details.selfMatches.ratio || 0}%</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Ratio' : 'Ratio'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details.selfMatches.totalMatches || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Total' : 'Total'}</Text>
                    </View>
                  </View>
                  {Array.isArray(selectedPlayer.details.selfMatches.examples) && selectedPlayer.details.selfMatches.examples.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Exemples (${selectedPlayer.details.selfMatches.examples.length})` : `Examples (${selectedPlayer.details.selfMatches.examples.length})`}
                      </Text>
                      {selectedPlayer.details.selfMatches.examples.map((ex: any, i: number) => (
                        <View key={i} style={st.geoAlertRow}>
                          <View style={[st.geoAlertIcon, { backgroundColor: '#EC489915' }]}>
                            <MaterialIcons name={ex.directOverlap ? 'person' : 'people'} size={14} color="#EC4899" />
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={st.geoAlertTitle} numberOfLines={1}>
                              {ex.directOverlap ? (isFr ? 'Meme joueur des deux cotes' : 'Same player on both sides') : (isFr ? 'Meme proprietaire' : 'Same owner')}
                            </Text>
                            <Text style={st.geoAlertMeta}>
                              {ex.date ? new Date(ex.date).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                              {Array.isArray(ex.overlappingPlayers) && ex.overlappingPlayers.length > 0 ? ` - ${ex.overlappingPlayers.join(', ')}` : ''}
                            </Text>
                          </View>
                          <View style={[st.geoAlertBadge, { backgroundColor: '#EC489915' }]}>
                            <Text style={[st.geoAlertBadgeText, { color: '#EC4899' }]}>{ex.directOverlap ? (isFr ? 'Direct' : 'Direct') : (isFr ? 'Owner' : 'Owner')}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Symmetric Score Streak */}
              {selectedPlayer.details?.symmetricScores && selectedPlayer.details.symmetricScores.maxConsecutiveStreak > 5 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="repeat" size={16} color="#F43F5E" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Serie de scores symetriques' : 'Symmetric score streak'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#F43F5E' }]}>{selectedPlayer.details.symmetricScores.maxConsecutiveStreak}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Max serie' : 'Max streak'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#E11D48' }]}>{selectedPlayer.details.symmetricScores.totalSymmetricMatches || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Total sym.' : 'Total sym.'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#BE123C' }]}>{selectedPlayer.details.symmetricScores.ratio || 0}%</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Ratio' : 'Ratio'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary, fontSize: 12 }]}>13-0/13-1</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Motif' : 'Pattern'}</Text>
                    </View>
                  </View>
                  {selectedPlayer.details.symmetricScores.streakStartDate ? (
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8, backgroundColor: '#F43F5E08', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 }}>
                      <MaterialIcons name="date-range" size={12} color="#F43F5E" />
                      <Text style={{ fontSize: 10, fontWeight: '600', color: '#F43F5E', flex: 1 }}>
                        {new Date(selectedPlayer.details.symmetricScores.streakStartDate).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short' })}
                        {' - '}
                        {selectedPlayer.details.symmetricScores.streakEndDate ? new Date(selectedPlayer.details.symmetricScores.streakEndDate).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}
                      </Text>
                    </View>
                  ) : null}
                  {Array.isArray(selectedPlayer.details.symmetricScores.examples) && selectedPlayer.details.symmetricScores.examples.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Exemples (${selectedPlayer.details.symmetricScores.examples.length})` : `Examples (${selectedPlayer.details.symmetricScores.examples.length})`}
                      </Text>
                      {selectedPlayer.details.symmetricScores.examples.map((ex: any, i: number) => (
                        <View key={i} style={st.geoAlertRow}>
                          <View style={[st.geoAlertIcon, { backgroundColor: '#F43F5E15' }]}>
                            <MaterialIcons name="emoji-events" size={14} color="#F43F5E" />
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={st.geoAlertTitle} numberOfLines={1}>{isFr ? 'Score' : 'Score'}: {ex.score}</Text>
                            <Text style={st.geoAlertMeta}>{ex.date ? new Date(ex.date).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' }) : '-'}</Text>
                          </View>
                          <View style={[st.geoAlertBadge, { backgroundColor: '#F43F5E15' }]}>
                            <Text style={[st.geoAlertBadgeText, { color: '#F43F5E' }]}>{ex.score}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Ghost Opponents */}
              {selectedPlayer.details?.ghostOpponents && selectedPlayer.details.ghostOpponents.ghostCount > 0 ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="person-off" size={16} color="#A855F7" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Adversaires fantomes' : 'Ghost opponents'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#A855F7' }]}>{selectedPlayer.details.ghostOpponents.ghostCount}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Fantomes' : 'Ghosts'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#9333EA' }]}>{selectedPlayer.details.ghostOpponents.ratio || 0}%</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Ratio' : 'Ratio'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary }]}>{selectedPlayer.details.ghostOpponents.totalOpponents || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Total adv.' : 'Total opp.'}</Text>
                    </View>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 8, backgroundColor: '#A855F708', borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 }}>
                    <MaterialIcons name="info" size={12} color="#A855F7" />
                    <Text style={{ fontSize: 10, fontWeight: '600', color: '#A855F7', flex: 1 }}>
                      {isFr ? 'Joueurs jamais rencontres dans les matchs d\'autres utilisateurs' : 'Players never seen in other users\' matches'}
                    </Text>
                  </View>
                  {Array.isArray(selectedPlayer.details.ghostOpponents.examples) && selectedPlayer.details.ghostOpponents.examples.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Exemples (${selectedPlayer.details.ghostOpponents.examples.length})` : `Examples (${selectedPlayer.details.ghostOpponents.examples.length})`}
                      </Text>
                      {selectedPlayer.details.ghostOpponents.examples.map((ex: any, i: number) => (
                        <View key={i} style={st.geoAlertRow}>
                          <View style={[st.geoAlertIcon, { backgroundColor: '#A855F715' }]}>
                            <MaterialIcons name={ex.sameOwner ? 'account-circle' : 'person'} size={14} color="#A855F7" />
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={st.geoAlertTitle} numberOfLines={1}>{ex.opponentName || (isFr ? 'Inconnu' : 'Unknown')}</Text>
                            <Text style={st.geoAlertMeta}>{ex.sameOwner ? (isFr ? 'Cree par le meme utilisateur' : 'Created by same user') : (isFr ? 'Aucun autre match enregistre' : 'No other matches recorded')}</Text>
                          </View>
                          {ex.sameOwner ? (
                            <View style={[st.geoAlertBadge, { backgroundColor: '#EC489915' }]}>
                              <Text style={[st.geoAlertBadgeText, { color: '#EC4899' }]}>{isFr ? 'Meme user' : 'Same user'}</Text>
                            </View>
                          ) : null}
                        </View>
                      ))}
                    </View>
                  ) : null}
                </View>
              ) : null}

              {/* Email Farm Cluster */}
              {selectedPlayer.details?.emailFarm ? (
                <View style={st.detailSection}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 }}>
                    <MaterialIcons name="alternate-email" size={16} color="#DC2626" />
                    <Text style={st.detailSectionTitle}>{isFr ? 'Cluster email farm' : 'Email farm cluster'}</Text>
                  </View>
                  <View style={st.deletionSummaryRow}>
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#DC2626' }]}>{selectedPlayer.details.emailFarm.clusterSize || 0}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Comptes' : 'Accounts'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: '#EF4444' }]}>{selectedPlayer.details.emailFarm.spanHours || 0}h</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Fenetre' : 'Window'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary, fontSize: 11 }]} numberOfLines={1}>{selectedPlayer.details.emailFarm.prefix}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Prefixe' : 'Prefix'}</Text>
                    </View>
                    <View style={st.deletionSummaryDivider} />
                    <View style={st.deletionSummaryItem}>
                      <Text style={[st.deletionSummaryValue, { color: theme.textSecondary, fontSize: 11 }]} numberOfLines={1}>{selectedPlayer.details.emailFarm.domain}</Text>
                      <Text style={st.deletionSummaryLabel}>{isFr ? 'Domaine' : 'Domain'}</Text>
                    </View>
                  </View>
                  {Array.isArray(selectedPlayer.details.emailFarm.siblings) && selectedPlayer.details.emailFarm.siblings.length > 0 ? (
                    <View style={{ marginTop: 12 }}>
                      <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                        {isFr ? `Comptes lies (${selectedPlayer.details.emailFarm.siblings.length})` : `Linked accounts (${selectedPlayer.details.emailFarm.siblings.length})`}
                      </Text>
                      {selectedPlayer.details.emailFarm.siblings.slice(0, 6).map((email: string, i: number) => (
                        <View key={i} style={st.geoAlertRow}>
                          <View style={[st.geoAlertIcon, { backgroundColor: '#DC262615' }]}>
                            <MaterialIcons name="email" size={14} color="#DC2626" />
                          </View>
                          <Text style={[st.geoAlertTitle, { flex: 1 }]} numberOfLines={1}>{email}</Text>
                        </View>
                      ))}
                    </View>
                  ) : null}
                  {farmClusterTimeline.length >= 2 ? (
                    <View style={{ marginTop: 14 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                        <MaterialIcons name="schedule" size={12} color="#DC2626" />
                        <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, textTransform: 'uppercase', letterSpacing: 0.4, flex: 1 }}>
                          {isFr ? 'Timeline du cluster' : 'Cluster timeline'}
                        </Text>
                        <View style={{ backgroundColor: '#DC262615', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 }}>
                          <Text style={{ fontSize: 9, fontWeight: '800', color: '#DC2626' }}>
                            {selectedPlayer.details.emailFarm.spanHours || 0}h / 24h
                          </Text>
                        </View>
                      </View>
                      {(() => {
                        const maxOffset = Math.max(...farmClusterTimeline.map(e => e.offsetHours), 0.1);
                        const displayMax = Math.max(0.5, maxOffset);
                        return farmClusterTimeline.map((entry, i) => {
                          const barPct = Math.min(100, (entry.offsetHours / displayMax) * 100);
                          const color = entry.isCurrentUser ? '#EF4444' : '#F97316';
                          const localPart = entry.email.split('@')[0];
                          const offsetLabel = entry.offsetHours < 0.017
                            ? '+0m'
                            : entry.offsetHours < 1
                              ? `+${Math.round(entry.offsetHours * 60)}m`
                              : `+${entry.offsetHours.toFixed(1)}h`;
                          return (
                            <View key={i} style={st.farmTimelineRow}>
                              <View style={st.farmTimelineLabel}>
                                <Text style={[st.farmTimelineEmail, entry.isCurrentUser && { color: '#EF4444', fontWeight: '800' as const }]} numberOfLines={1}>
                                  {localPart}
                                </Text>
                                {entry.isCurrentUser ? (
                                  <Text style={st.farmTimelineCurrent}>{isFr ? 'Ce joueur' : 'This player'}</Text>
                                ) : null}
                              </View>
                              <View style={st.farmTimelineBar}>
                                <View style={st.farmTimelineTrack} />
                                <View style={[st.farmTimelineFill, { width: `${Math.max(2, barPct)}%`, backgroundColor: color + '55' }]} />
                                <View style={[st.farmTimelineDot, { left: `${barPct}%`, backgroundColor: color }]} />
                              </View>
                              <Text style={[st.farmTimelineOffset, entry.isCurrentUser && { color: '#EF4444' }]}>
                                {offsetLabel}
                              </Text>
                            </View>
                          );
                        });
                      })()}
                      <View style={{ flexDirection: 'row', gap: 12, marginTop: 6, marginLeft: 96 }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#EF4444' }} />
                          <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Ce joueur' : 'This player'}</Text>
                        </View>
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#F97316' }} />
                          <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Autre compte' : 'Other'}</Text>
                        </View>
                      </View>
                    </View>
                  ) : null}
                  <Pressable
                    style={[st.emailFarmBanBtn, emailFarmBusy && { opacity: 0.6 }]}
                    onPress={handleBulkBanEmailFarmCluster}
                    disabled={emailFarmBusy}
                  >
                    {emailFarmBusy ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="block" size={16} color="#FFF" />}
                    <Text style={st.emailFarmBanBtnText}>
                      {emailFarmBusy
                        ? (isFr ? 'Bannissement...' : 'Banning...')
                        : (isFr ? `Bannir tout le cluster (${selectedPlayer.details.emailFarm.siblings?.length || 0})` : `Ban entire cluster (${selectedPlayer.details.emailFarm.siblings?.length || 0})`)}
                    </Text>
                  </Pressable>
                </View>
              ) : null}

              {/* Flags */}
              <View style={st.detailSection}>
                <Text style={st.detailSectionTitle}>{(et.adminFlags as any)?.[language] || 'Flags'} ({selectedPlayer.flags.length})</Text>
                {selectedPlayer.flags.length === 0 ? (
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 12 }}>
                    <MaterialIcons name="check-circle" size={20} color={theme.success} />
                    <Text style={{ fontSize: 14, color: theme.success, fontWeight: '600' }}>{isFr ? 'Aucune alerte' : 'No flags'}</Text>
                  </View>
                ) : (
                  selectedPlayer.flags.map((flag: string, fi: number) => (
                    <View key={fi} style={st.detailFlagRow}>
                      <MaterialIcons name="warning" size={14} color="#F97316" />
                      <Text style={st.detailFlagText}>{flag.replace(/_/g, ' ')}</Text>
                    </View>
                  ))
                )}
              </View>

              {/* Admin notes */}
              <View style={st.detailSection}>
                <Text style={st.detailSectionTitle}>{(et.adminNotes as any)?.[language] || 'Admin notes'}</Text>
                <TextInput
                  style={st.notesInput}
                  value={adminNotes}
                  onChangeText={setAdminNotes}
                  placeholder={isFr ? 'Notes internes...' : 'Internal notes...'}
                  placeholderTextColor={theme.textMuted}
                  multiline
                  numberOfLines={4}
                />
                <Pressable style={[st.saveNotesBtn, savingNotes && { opacity: 0.6 }]} onPress={handleSaveNotes} disabled={savingNotes}>
                  {savingNotes ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="save" size={16} color="#FFF" />}
                  <Text style={st.saveNotesBtnText}>{(et.adminSaveNotes as any)?.[language] || 'Save'}</Text>
                </Pressable>
                <Pressable
                  style={[st.resetCooldownBtn, resettingCooldownId === selectedPlayer.userId && { opacity: 0.6 }]}
                  onPress={() => handleResetCooldown(selectedPlayer.userId)}
                  disabled={resettingCooldownId === selectedPlayer.userId}
                >
                  {resettingCooldownId === selectedPlayer.userId ? <ActivityIndicator size="small" color="#8B5CF6" /> : <MaterialIcons name="notifications-active" size={14} color="#8B5CF6" />}
                  <Text style={st.resetCooldownBtnText}>
                    {isFr ? 'Reinitialiser cooldown push' : 'Reset push cooldown'}
                  </Text>
                </Pressable>
              </View>

              {/* Status actions */}
              <View style={st.detailSection}>
                <Text style={st.detailSectionTitle}>Actions</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                  {['ok', 'watch', 'flagged', 'banned', 'dismissed'].map(s => (
                    <Pressable
                      key={s}
                      style={[st.statusActionBtn, { borderColor: getStatusColor(s), backgroundColor: selectedPlayer.status === s ? getStatusColor(s) : getStatusColor(s) + '10' }]}
                      onPress={() => handleUpdateStatus(selectedPlayer.id, s)}
                    >
                      <Text style={[st.statusActionText, { color: selectedPlayer.status === s ? '#FFF' : getStatusColor(s) }]}>{getStatusLabel(s)}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            </ScrollView>
          ) : null}
        </SafeAreaView>
      </Modal>

      {/* Ban Reason Selector Modal */}
      <Modal visible={banReasonPrompt !== null} animationType="fade" transparent onRequestClose={() => setBanReasonPrompt(null)}>
        <View style={st.adjustOverlay}>
          <View style={[st.adjustContent, { maxWidth: 380, width: '100%' }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <MaterialIcons name="gpp-bad" size={22} color="#EF4444" />
              <Text style={[st.adjustTitle, { marginBottom: 0 }]}>{isFr ? 'Motif du bannissement' : 'Ban reason'}</Text>
            </View>
            <Text style={{ fontSize: 12, color: theme.textSecondary, textAlign: 'center', marginBottom: 14 }}>
              {isFr
                ? `${banReasonPrompt?.targets.length || 0} joueur(s) - Choisissez un motif`
                : `${banReasonPrompt?.targets.length || 0} player(s) - Choose a reason`}
            </Text>
            <View style={{ gap: 8, alignSelf: 'stretch', marginBottom: 16 }}>
              {([
                { value: 'cheat', labelFr: 'Triche', labelEn: 'Cheating', icon: 'gpp-bad', color: '#EF4444' },
                { value: 'spam', labelFr: 'Spam', labelEn: 'Spam', icon: 'block', color: '#F97316' },
                { value: 'harassment', labelFr: 'Harcelement', labelEn: 'Harassment', icon: 'report', color: '#DB2777' },
                { value: 'other', labelFr: 'Autre', labelEn: 'Other', icon: 'more-horiz', color: '#6B7280' },
              ] as const).map(opt => {
                const isSelected = selectedBanReason === opt.value;
                return (
                  <Pressable
                    key={opt.value}
                    style={[st.banReasonOption, isSelected && { backgroundColor: opt.color + '15', borderColor: opt.color }]}
                    onPress={() => { Haptics.selectionAsync(); setSelectedBanReason(opt.value); }}
                  >
                    <View style={[st.banReasonIcon, { backgroundColor: opt.color + (isSelected ? '25' : '12') }]}>
                      <MaterialIcons name={opt.icon as any} size={16} color={opt.color} />
                    </View>
                    <Text style={[st.banReasonLabel, isSelected && { color: opt.color, fontWeight: '800' }]}>
                      {isFr ? opt.labelFr : opt.labelEn}
                    </Text>
                    {isSelected ? (
                      <MaterialIcons name="check-circle" size={18} color={opt.color} />
                    ) : (
                      <View style={{ width: 18, height: 18, borderRadius: 9, borderWidth: 1.5, borderColor: theme.border }} />
                    )}
                  </Pressable>
                );
              })}
            </View>
            <View style={{ flexDirection: 'row', gap: 10, alignSelf: 'stretch' }}>
              <Pressable style={st.adjustCancel} onPress={() => setBanReasonPrompt(null)}>
                <Text style={st.adjustCancelText}>{t('common', 'cancel')}</Text>
              </Pressable>
              <Pressable
                style={[st.adjustConfirm, { backgroundColor: '#EF4444', flexDirection: 'row', gap: 6, justifyContent: 'center' }, bulkBusy && { opacity: 0.6 }]}
                onPress={handleConfirmBanWithReason}
                disabled={bulkBusy}
              >
                {bulkBusy ? <ActivityIndicator size="small" color="#FFF" /> : <MaterialIcons name="block" size={16} color="#FFF" />}
                <Text style={st.adjustConfirmText}>{isFr ? 'Bannir' : 'Ban'}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      {/* Statistical Detail Modal (Benford chart + ELO regression) */}
      <Modal visible={showStatModal} animationType="slide" presentationStyle="pageSheet" onRequestClose={() => setShowStatModal(false)}>
        <SafeAreaView style={st.detailContainer}>
          <View style={st.detailHeader}>
            <Pressable style={st.detailClose} onPress={() => setShowStatModal(false)}>
              <MaterialIcons name="close" size={24} color={theme.textPrimary} />
            </Pressable>
            <Text style={st.detailTitle}>{isFr ? 'Analyses statistiques' : 'Statistical analysis'}</Text>
            <View style={{ width: 40 }} />
          </View>
          <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 32 }} showsVerticalScrollIndicator={false}>
            {/* Benford */}
            {selectedPlayer?.details?.benfordAnalysis ? (
              <View style={st.detailSection}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <MaterialIcons name="insights" size={16} color="#0EA5E9" />
                  <Text style={st.detailSectionTitle}>{isFr ? 'Loi de Benford (scores + ELO)' : 'Benford Law (scores + ELO)'}</Text>
                </View>
                <Text style={{ fontSize: 12, color: theme.textSecondary, lineHeight: 17, marginBottom: 10 }}>
                  {isFr
                    ? 'Distribution des chiffres de tete observee vs attendue. Chi-carre > 15.51 = ecart significatif.'
                    : 'Observed leading-digit distribution vs expected. Chi-square > 15.51 = significant deviation.'}
                </Text>
                <View style={st.deletionSummaryRow}>
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#0EA5E9' }]}>{selectedPlayer.details.benfordAnalysis.sampleSize}</Text>
                    <Text style={st.deletionSummaryLabel}>{isFr ? 'Echantillon' : 'Sample'}</Text>
                  </View>
                  <View style={st.deletionSummaryDivider} />
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#0284C7' }]}>{selectedPlayer.details.benfordAnalysis.chiSquare}</Text>
                    <Text style={st.deletionSummaryLabel}>Chi2</Text>
                  </View>
                  <View style={st.deletionSummaryDivider} />
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#0369A1' }]}>{selectedPlayer.details.benfordAnalysis.threshold95}</Text>
                    <Text style={st.deletionSummaryLabel}>{isFr ? 'Seuil 95%' : '95%'}</Text>
                  </View>
                  <View style={st.deletionSummaryDivider} />
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#075985' }]}>{selectedPlayer.details.benfordAnalysis.threshold99}</Text>
                    <Text style={st.deletionSummaryLabel}>{isFr ? 'Seuil 99%' : '99%'}</Text>
                  </View>
                </View>
                <View style={st.benfordChart}>
                  {(() => {
                    const expected = [30.1, 17.6, 12.5, 9.7, 7.9, 6.7, 5.8, 5.1, 4.6];
                    const observed = Array.isArray(selectedPlayer.details.benfordAnalysis.digitDistribution)
                      ? selectedPlayer.details.benfordAnalysis.digitDistribution : [];
                    const maxPct = 35;
                    return Array.from({ length: 9 }, (_, i) => {
                      const obs = Number(observed[i]) || 0;
                      const exp = expected[i];
                      const obsH = Math.max(2, (obs / maxPct) * 70);
                      const expH = Math.max(2, (exp / maxPct) * 70);
                      return (
                        <View key={i} style={st.benfordBarCol}>
                          <View style={st.benfordBarWrap}>
                            <View style={[st.benfordExpected, { height: expH }]} />
                            <View style={[st.benfordObserved, { height: obsH }]} />
                          </View>
                          <Text style={st.benfordDigit}>{i + 1}</Text>
                        </View>
                      );
                    });
                  })()}
                </View>
                <View style={st.benfordLegend}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                    <View style={{ width: 10, height: 10, borderRadius: 3, backgroundColor: '#0EA5E9' }} />
                    <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Observe' : 'Observed'}</Text>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                    <View style={{ width: 10, height: 10, borderRadius: 3, backgroundColor: '#94A3B850' }} />
                    <Text style={{ fontSize: 10, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Attendu (Benford)' : 'Expected (Benford)'}</Text>
                  </View>
                </View>
              </View>
            ) : (
              <View style={st.detailSection}>
                <Text style={{ fontSize: 13, color: theme.textMuted, textAlign: 'center', paddingVertical: 12 }}>
                  {isFr ? 'Pas assez de donnees pour analyse Benford' : 'Not enough data for Benford analysis'}
                </Text>
              </View>
            )}

            {/* ELO Variance */}
            {selectedPlayer?.details?.eloVariance ? (
              <View style={st.detailSection}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <MaterialIcons name="show-chart" size={16} color="#DB2777" />
                  <Text style={st.detailSectionTitle}>{isFr ? 'Progression ELO (regression)' : 'ELO progression (regression)'}</Text>
                </View>
                <Text style={{ fontSize: 12, color: theme.textSecondary, lineHeight: 17, marginBottom: 10 }}>
                  {isFr ? 'R2 eleve = progression trop lineaire. CV faible = variance suspecte.' : 'High R2 = too-linear progression. Low CV = suspicious variance.'}
                </Text>
                {(() => {
                  const r2Val = selectedPlayer.details.eloVariance.linearityR2 || 0;
                  if (r2Val > 0.95) {
                    return (
                      <View style={st.r2AlertCritical}>
                        <MaterialIcons name="warning" size={16} color="#EF4444" />
                        <View style={{ flex: 1 }}>
                          <Text style={st.r2AlertTitle}>{isFr ? `R2 critique : ${r2Val} (> 0.95)` : `Critical R2: ${r2Val} (> 0.95)`}</Text>
                          <Text style={st.r2AlertText}>
                            {isFr
                              ? 'Progression tres lineaire, quasiment sans variance naturelle. Manipulation ELO fortement probable, action recommandee.'
                              : 'Very linear progression, near-zero natural variance. ELO manipulation highly probable, action recommended.'}
                          </Text>
                          <Pressable style={st.r2AlertLink} onPress={() => router.push('/trust-score' as any)}>
                            <MaterialIcons name="open-in-new" size={11} color="#EF4444" />
                            <Text style={st.r2AlertLinkText}>{isFr ? 'Doc anti-triche' : 'Anti-cheat docs'}</Text>
                          </Pressable>
                        </View>
                      </View>
                    );
                  }
                  if (r2Val > 0.9) {
                    return (
                      <View style={st.r2AlertWarning}>
                        <MaterialIcons name="report-problem" size={16} color="#F97316" />
                        <View style={{ flex: 1 }}>
                          <Text style={[st.r2AlertTitle, { color: '#F97316' }]}>{isFr ? `R2 eleve : ${r2Val} (> 0.9)` : `High R2: ${r2Val} (> 0.9)`}</Text>
                          <Text style={st.r2AlertText}>
                            {isFr
                              ? 'Progression trop reguliere pour etre naturelle. A verifier attentivement.'
                              : 'Progression too regular to be natural. Requires careful review.'}
                          </Text>
                          <Pressable style={[st.r2AlertLink, { borderColor: '#F9731630' }]} onPress={() => router.push('/trust-score' as any)}>
                            <MaterialIcons name="open-in-new" size={11} color="#F97316" />
                            <Text style={[st.r2AlertLinkText, { color: '#F97316' }]}>{isFr ? 'Doc anti-triche' : 'Anti-cheat docs'}</Text>
                          </Pressable>
                        </View>
                      </View>
                    );
                  }
                  return null;
                })()}
                <View style={st.deletionSummaryRow}>
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#DB2777' }]}>{selectedPlayer.details.eloVariance.matchesAnalyzed}</Text>
                    <Text style={st.deletionSummaryLabel}>{isFr ? 'Matchs' : 'Matches'}</Text>
                  </View>
                  <View style={st.deletionSummaryDivider} />
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#BE185D' }]}>{selectedPlayer.details.eloVariance.coefficientOfVariation}</Text>
                    <Text style={st.deletionSummaryLabel}>CV</Text>
                  </View>
                  <View style={st.deletionSummaryDivider} />
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#9D174D' }]}>{selectedPlayer.details.eloVariance.linearityR2}</Text>
                    <Text style={st.deletionSummaryLabel}>R2</Text>
                  </View>
                  <View style={st.deletionSummaryDivider} />
                  <View style={st.deletionSummaryItem}>
                    <Text style={[st.deletionSummaryValue, { color: '#831843' }]}>{selectedPlayer.details.eloVariance.slope}</Text>
                    <Text style={st.deletionSummaryLabel}>{isFr ? 'Pente' : 'Slope'}</Text>
                  </View>
                </View>
                <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
                  <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, alignItems: 'center' }}>
                    <Text style={{ fontSize: 16, fontWeight: '800', color: '#DB2777' }}>{selectedPlayer.details.eloVariance.meanAbsDelta}</Text>
                    <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Delta moyen (abs)' : 'Mean abs delta'}</Text>
                  </View>
                  <View style={{ flex: 1, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, alignItems: 'center' }}>
                    <Text style={{ fontSize: 16, fontWeight: '800', color: '#BE185D' }}>{selectedPlayer.details.eloVariance.positiveDeltaRatio}%</Text>
                    <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600', marginTop: 2 }}>{isFr ? 'Ratio gains' : 'Positive ratio'}</Text>
                  </View>
                </View>
                {statHistLoading ? (
                  <View style={{ paddingVertical: 20, alignItems: 'center' }}>
                    <ActivityIndicator size="small" color="#DB2777" />
                  </View>
                ) : statEloHistory.length > 0 ? (
                  <View style={{ marginTop: 12 }}>
                    <Text style={{ fontSize: 11, fontWeight: '700', color: theme.textMuted, marginBottom: 6, textTransform: 'uppercase' }}>
                      {isFr ? `Courbe cumulative (${statEloHistory.length} matchs)` : `Cumulative curve (${statEloHistory.length} matches)`}
                    </Text>
                    <View style={{ position: 'relative' as const }}>
                      <View style={st.eloSparkline}>
                        {(() => {
                          const cum: number[] = [];
                          let running = 0;
                          for (const h of statEloHistory) { running += h.delta; cum.push(running); }
                          const minVal = Math.min(...cum, 0);
                          const maxVal = Math.max(...cum, 0);
                          const range = Math.max(1, maxVal - minVal);
                          return cum.map((v, i) => {
                            const pct = (v - minVal) / range;
                            const barH = Math.max(2, pct * 40);
                            const color = statEloHistory[i].delta >= 0 ? '#22C55E' : '#EF4444';
                            return <View key={i} style={{ flex: 1, height: barH, backgroundColor: color, borderRadius: 1, opacity: 0.55 }} />;
                          });
                        })()}
                      </View>
                      {/* Linear regression overlay: predicted values */}
                      <View pointerEvents="none" style={{ position: 'absolute' as const, top: 6, left: 6, right: 6, bottom: 6 }}>
                        {(() => {
                          const cum: number[] = [];
                          let running = 0;
                          for (const h of statEloHistory) { running += h.delta; cum.push(running); }
                          const minVal = Math.min(...cum, 0);
                          const maxVal = Math.max(...cum, 0);
                          const range = Math.max(1, maxVal - minVal);
                          const nElo = cum.length;
                          let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
                          for (let i = 0; i < nElo; i++) {
                            sumX += i; sumY += cum[i]; sumXY += i * cum[i]; sumX2 += i * i;
                          }
                          const denom = nElo * sumX2 - sumX * sumX;
                          const slope = denom !== 0 ? (nElo * sumXY - sumX * sumY) / denom : 0;
                          const intercept = nElo > 0 ? (sumY - slope * sumX) / nElo : 0;
                          return cum.map((_, i) => {
                            const predicted = slope * i + intercept;
                            const pct = range > 0 ? (predicted - minVal) / range : 0.5;
                            const yBottom = Math.max(0, Math.min(40, pct * 40));
                            const xPct = nElo > 1 ? (i / (nElo - 1)) * 100 : 50;
                            return (
                              <View
                                key={`reg-${i}`}
                                style={{
                                  position: 'absolute' as const,
                                  left: `${xPct}%`,
                                  bottom: yBottom,
                                  width: 5,
                                  height: 5,
                                  borderRadius: 2.5,
                                  backgroundColor: '#DB2777',
                                  marginLeft: -2.5,
                                  marginBottom: -2.5,
                                  borderWidth: 1,
                                  borderColor: '#FFF',
                                }}
                              />
                            );
                          });
                        })()}
                      </View>
                    </View>
                    <View style={{ flexDirection: 'row', gap: 12, justifyContent: 'center', marginTop: 6 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                        <View style={{ width: 10, height: 6, borderRadius: 2, backgroundColor: '#22C55E', opacity: 0.55 }} />
                        <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Reel' : 'Actual'}</Text>
                      </View>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                        <View style={{ width: 5, height: 5, borderRadius: 2.5, backgroundColor: '#DB2777', borderWidth: 1, borderColor: '#FFF' }} />
                        <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>{isFr ? 'Regression lineaire predite' : 'Linear regression predicted'}</Text>
                      </View>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
                      <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>
                        {new Date(statEloHistory[0].recordedAt).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short' })}
                      </Text>
                      <Text style={{ fontSize: 9, color: theme.textMuted, fontWeight: '600' }}>
                        {new Date(statEloHistory[statEloHistory.length - 1].recordedAt).toLocaleDateString(isFr ? 'fr-FR' : 'en-US', { day: 'numeric', month: 'short' })}
                      </Text>
                    </View>
                  </View>
                ) : (
                  <Text style={{ fontSize: 11, color: theme.textMuted, textAlign: 'center', marginTop: 12 }}>
                    {isFr ? 'Aucun historique ELO' : 'No ELO history'}
                  </Text>
                )}
              </View>
            ) : (
              <View style={st.detailSection}>
                <Text style={{ fontSize: 13, color: theme.textMuted, textAlign: 'center', paddingVertical: 12 }}>
                  {isFr ? 'Pas assez de donnees pour analyse ELO' : 'Not enough data for ELO analysis'}
                </Text>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Adjust score modal */}
      <Modal visible={showAdjustModal} animationType="fade" transparent onRequestClose={() => setShowAdjustModal(false)}>
        <View style={st.adjustOverlay}>
          <View style={st.adjustContent}>
            <Text style={st.adjustTitle}>{(et.adminAdjustScore as any)?.[language] || 'Adjust Score'}</Text>
            <TextInput
              style={st.adjustInput}
              value={adjustScore}
              onChangeText={setAdjustScore}
              keyboardType="number-pad"
              maxLength={3}
              placeholder="0-100"
              placeholderTextColor={theme.textMuted}
              autoFocus
            />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Pressable style={st.adjustCancel} onPress={() => setShowAdjustModal(false)}>
                <Text style={st.adjustCancelText}>{t('common', 'cancel')}</Text>
              </Pressable>
              <Pressable style={st.adjustConfirm} onPress={handleAdjustScore}>
                <Text style={st.adjustConfirmText}>{t('common', 'save')}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
    </AdminGuard>
    </PageErrorBoundary>
  );
}

const st = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.backgroundSecondary },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 12, backgroundColor: theme.surface, borderBottomWidth: 1, borderBottomColor: theme.border },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: theme.textPrimary },
  headerSub: { fontSize: 11, color: theme.textMuted, marginTop: 1 },
  scanBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#EF4444', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12 },
  scanBtnText: { fontSize: 12, fontWeight: '700', color: '#FFF' },
  eloRecalcBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: '#7C3AED', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12 },
  eloRecalcBtnText: { fontSize: 12, fontWeight: '700', color: '#FFF' },
  headerIconBtn: { width: 40, height: 40, borderRadius: 12, alignItems: 'center' as const, justifyContent: 'center' as const },

  filterRow: { paddingHorizontal: 16, paddingVertical: 10, gap: 8 },
  filterChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: theme.surface, borderWidth: 1.5, borderColor: theme.border },
  filterChipText: { fontSize: 13, fontWeight: '600', color: theme.textSecondary },
  filterCount: { backgroundColor: theme.backgroundSecondary, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8, minWidth: 20, alignItems: 'center' },
  filterCountText: { fontSize: 10, fontWeight: '700', color: theme.textSecondary },

  trustFilterWrap: { marginTop: 2, marginBottom: 4 },
  trustFilterHeader: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4, paddingHorizontal: 16, paddingTop: 6, paddingBottom: 4 },
  trustFilterLabel: { fontSize: 10, fontWeight: '700' as const, color: theme.textMuted, letterSpacing: 0.5, textTransform: 'uppercase' as const },

  searchBar: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: theme.surface, marginHorizontal: 16, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1, borderColor: theme.border },
  searchInput: { flex: 1, fontSize: 14, color: theme.textPrimary, padding: 0 },

  mainScroll: { flex: 1 },
  mainScrollContent: { paddingTop: 0 },
  listInner: { paddingHorizontal: 16, paddingTop: 4 },

  playerCard: { backgroundColor: theme.surface, borderRadius: 16, padding: 14, marginBottom: 10, borderLeftWidth: 4, ...theme.shadows.card },
  playerHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 10 },
  playerAvatar: { width: 40, height: 40, borderRadius: 12, backgroundColor: theme.backgroundSecondary, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  playerName: { fontSize: 15, fontWeight: '700', color: theme.textPrimary },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, borderWidth: 1 },
  statusBadgeText: { fontSize: 10, fontWeight: '700' },
  flagCountBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: '#EF444412', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8 },
  flagCountText: { fontSize: 10, fontWeight: '700', color: '#EF4444' },
  scoreCircle: { width: 48, height: 48, borderRadius: 24, borderWidth: 3, alignItems: 'center', justifyContent: 'center' },
  scoreText: { fontSize: 16, fontWeight: '900' },

  flagsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 10 },
  flagChip: { backgroundColor: '#F9731612', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  flagChipText: { fontSize: 10, fontWeight: '600', color: '#F97316' },
  flagMore: { fontSize: 10, fontWeight: '600', color: theme.textMuted, alignSelf: 'center' },

  quickActions: { flexDirection: 'row', gap: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: theme.border + '40' },
  qAction: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 },
  qActionText: { fontSize: 12, fontWeight: '600' },

  // Detail modal
  detailContainer: { flex: 1, backgroundColor: theme.backgroundSecondary },
  detailHeader: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, backgroundColor: theme.surface, borderBottomWidth: 1, borderBottomColor: theme.border },
  detailClose: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  detailTitle: { flex: 1, fontSize: 17, fontWeight: '600', color: theme.textPrimary, textAlign: 'center' },
  detailViewBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },

  detailScoreCard: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: theme.surface, borderRadius: 16, padding: 16, marginBottom: 16, borderWidth: 1, ...theme.shadows.card },
  detailScoreCircle: { width: 64, height: 64, borderRadius: 32, borderWidth: 4, alignItems: 'center', justifyContent: 'center' },
  detailScoreValue: { fontSize: 24, fontWeight: '900' },
  detailScoreMax: { fontSize: 10, color: theme.textMuted, fontWeight: '600' },
  detailLevel: { fontSize: 16, fontWeight: '700' },
  detailStatus: { fontSize: 12, color: theme.textSecondary, marginTop: 2 },
  detailAnalyzed: { fontSize: 10, color: theme.textMuted, marginTop: 2 },
  adjustBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: theme.primary + '12', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 },
  adjustBtnText: { fontSize: 12, fontWeight: '600', color: theme.primary },

  detailSection: { backgroundColor: theme.surface, borderRadius: 16, padding: 16, marginBottom: 12, ...theme.shadows.card },
  detailSectionTitle: { fontSize: 13, fontWeight: '700', color: theme.textSecondary, letterSpacing: 0.5, marginBottom: 12, textTransform: 'uppercase' },
  detailStatsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  detailStatItem: { width: '47%', backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, alignItems: 'center' },
  detailStatValue: { fontSize: 16, fontWeight: '800', color: theme.textPrimary },
  detailStatLabel: { fontSize: 10, color: theme.textMuted, marginTop: 2, textAlign: 'center' },
  detailFlagRow: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: theme.border + '40' },
  detailFlagText: { fontSize: 13, fontWeight: '500', color: theme.textPrimary, flex: 1 },
  notesInput: { backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 14, fontSize: 14, color: theme.textPrimary, minHeight: 80, textAlignVertical: 'top', borderWidth: 1, borderColor: theme.border, marginBottom: 10 },
  saveNotesBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: theme.primary, paddingVertical: 12, borderRadius: 12 },
  saveNotesBtnText: { fontSize: 14, fontWeight: '700', color: '#FFF' },
  statusActionBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 12, borderWidth: 1.5 },
  statusActionText: { fontSize: 13, fontWeight: '700' },

  // Adjust modal
  adjustOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', paddingHorizontal: 40 },
  adjustContent: { backgroundColor: theme.surface, borderRadius: 20, padding: 24, alignItems: 'center' },
  adjustTitle: { fontSize: 18, fontWeight: '700', color: theme.textPrimary, marginBottom: 16 },
  adjustInput: { fontSize: 32, fontWeight: '900', color: theme.primary, textAlign: 'center', backgroundColor: theme.backgroundSecondary, borderRadius: 14, paddingVertical: 14, paddingHorizontal: 24, width: 140, marginBottom: 20, borderWidth: 2, borderColor: theme.primary + '30' },
  adjustCancel: { flex: 1, alignItems: 'center', paddingVertical: 14, borderRadius: 12, backgroundColor: theme.backgroundSecondary },
  adjustCancelText: { fontSize: 15, fontWeight: '600', color: theme.textSecondary },
  adjustConfirm: { flex: 1, alignItems: 'center', paddingVertical: 14, borderRadius: 12, backgroundColor: theme.primary },
  adjustConfirmText: { fontSize: 15, fontWeight: '700', color: '#FFF' },

  // Summary dashboard
  summarySection: { marginHorizontal: 16, marginBottom: 10 },
  summaryRow: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  summaryCard: { flex: 1, backgroundColor: theme.surface, borderRadius: 14, padding: 12, alignItems: 'center', ...theme.shadows.card },
  summaryValue: { fontSize: 22, fontWeight: '900', color: theme.textPrimary },
  summaryLabel: { fontSize: 10, color: theme.textMuted, marginTop: 2, textAlign: 'center', fontWeight: '600' },
  distRow: { flexDirection: 'row', backgroundColor: theme.surface, borderRadius: 14, padding: 14, gap: 6, marginBottom: 10, ...theme.shadows.card },
  distItem: { flex: 1, alignItems: 'center', gap: 4 },
  distBarTrack: { width: '100%', height: 50, backgroundColor: theme.backgroundSecondary, borderRadius: 6, overflow: 'hidden', justifyContent: 'flex-end' },
  distBarFill: { width: '100%', borderRadius: 6 },
  distPct: { fontSize: 11, fontWeight: '800' },
  distLabel: { fontSize: 8, color: theme.textMuted, fontWeight: '600', textAlign: 'center' },
  distCount: { fontSize: 10, fontWeight: '700', color: theme.textSecondary },
  batchDismissBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: '#22C55E12', borderRadius: 12, paddingVertical: 12, borderWidth: 1, borderColor: '#22C55E30' },
  batchDismissBtnText: { fontSize: 13, fontWeight: '600', color: '#22C55E' },

  // ELO Dashboard
  eloDashSection: { marginHorizontal: 16, marginBottom: 10, backgroundColor: theme.surface, borderRadius: 16, padding: 14, ...theme.shadows.card, borderWidth: 1, borderColor: '#9333EA' + '15' },
  eloDashHeader: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10, marginBottom: 12 },
  eloDashIcon: { width: 32, height: 32, borderRadius: 8, alignItems: 'center' as const, justifyContent: 'center' as const },
  eloDashTitle: { fontSize: 14, fontWeight: '700' as const, color: theme.textPrimary },
  eloDashStatsRow: { flexDirection: 'row' as const, gap: 8, marginBottom: 10 },
  eloDashStat: { flex: 1, alignItems: 'center' as const, backgroundColor: theme.backgroundSecondary, borderRadius: 10, paddingVertical: 10, paddingHorizontal: 4 },
  eloDashStatValue: { fontSize: 18, fontWeight: '900' as const },
  eloDashStatLabel: { fontSize: 9, color: theme.textMuted, marginTop: 2, fontWeight: '600' as const, textAlign: 'center' as const },
  eloDashDistRow: { flexDirection: 'row' as const, gap: 4 },
  eloDashDistItem: { flex: 1, alignItems: 'center' as const, gap: 3 },
  eloDashDistBarTrack: { width: '100%' as const, height: 44, backgroundColor: theme.backgroundSecondary, borderRadius: 6, overflow: 'hidden' as const, justifyContent: 'flex-end' as const },
  eloDashDistBarFill: { width: '100%' as const, borderRadius: 6 },
  eloDashDistPct: { fontSize: 10, fontWeight: '800' as const },
  eloDashDistLabel: { fontSize: 7, color: theme.textMuted, fontWeight: '600' as const, textAlign: 'center' as const },
  eloDashDistCount: { fontSize: 10, fontWeight: '700' as const },
  eloDashActionBtn: { flex: 1, flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const, gap: 6, paddingVertical: 10, borderRadius: 10, borderWidth: 1 },

  // Deletion alerts
  deletionSection: { marginHorizontal: 16, marginBottom: 10, backgroundColor: theme.surface, borderRadius: 16, padding: 14, ...theme.shadows.card, borderWidth: 1, borderColor: '#EF4444' + '20' },
  deletionHeader: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10, marginBottom: 12 },
  deletionIconWrap: { width: 36, height: 36, borderRadius: 10, alignItems: 'center' as const, justifyContent: 'center' as const },
  deletionTitle: { fontSize: 14, fontWeight: '700' as const, color: theme.textPrimary },
  deletionSubtitle: { fontSize: 10, color: theme.textMuted, marginTop: 1 },
  deletionCountBadge: { backgroundColor: '#EF4444', borderRadius: 12, minWidth: 24, height: 24, alignItems: 'center' as const, justifyContent: 'center' as const, paddingHorizontal: 8 },
  deletionCountText: { fontSize: 12, fontWeight: '800' as const, color: '#FFF' },
  deletionCard: { backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 12, marginBottom: 8, borderLeftWidth: 3 },
  deletionAvatar: { width: 32, height: 32, borderRadius: 10, backgroundColor: theme.surface, alignItems: 'center' as const, justifyContent: 'center' as const, overflow: 'hidden' as const },
  deletionPlayerName: { fontSize: 14, fontWeight: '700' as const, color: theme.textPrimary },
  deletionSeverity: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 3, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, borderWidth: 1 },
  deletionSeverityText: { fontSize: 9, fontWeight: '700' as const },
  deletionTrustBadge: { width: 26, height: 26, borderRadius: 13, borderWidth: 2, alignItems: 'center' as const, justifyContent: 'center' as const },
  deletionTrustText: { fontSize: 10, fontWeight: '900' as const },
  deletionStatsRow: { flexDirection: 'row' as const, alignItems: 'center' as const },
  deletionStatItem: { flex: 1, alignItems: 'center' as const },
  deletionStatValue: { fontSize: 16, fontWeight: '800' as const },
  deletionStatLabel: { fontSize: 8, color: theme.textMuted, fontWeight: '600' as const, marginTop: 2, textAlign: 'center' as const },
  deletionStatDivider: { width: 1, height: 24, backgroundColor: theme.border },
  deletionMoreText: { fontSize: 12, color: theme.textMuted, fontWeight: '600' as const, textAlign: 'center' as const, paddingTop: 4 },

  // Deletion timeline
  timelineLoadBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4, backgroundColor: '#EF444412', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  deletionSummaryRow: { flexDirection: 'row' as const, alignItems: 'center' as const, backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 12, marginBottom: 12 },
  deletionSummaryItem: { flex: 1, alignItems: 'center' as const },
  deletionSummaryValue: { fontSize: 18, fontWeight: '800' as const },
  deletionSummaryLabel: { fontSize: 9, color: theme.textMuted, fontWeight: '600' as const, marginTop: 2, textAlign: 'center' as const },
  deletionSummaryDivider: { width: 1, height: 28, backgroundColor: theme.border },
  timelineContainer: { marginBottom: 12 },
  timelineLabel: { fontSize: 11, color: theme.textMuted, fontWeight: '600' as const, marginBottom: 8 },
  timelineChart: { flexDirection: 'row' as const, alignItems: 'flex-end' as const, gap: 4, height: 110, backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 10, paddingBottom: 28 },
  timelineBarGroup: { flex: 1, alignItems: 'center' as const, gap: 2 },
  timelineBarsWrap: { flexDirection: 'row' as const, alignItems: 'flex-end' as const, gap: 1 },
  timelineBar: { width: 8, borderRadius: 4 },
  timelineBarElo: { width: 6, borderRadius: 3, opacity: 0.7 },
  timelineBarValue: { fontSize: 8, fontWeight: '800' as const, color: '#EF4444' },
  timelineBarWeek: { fontSize: 7, color: theme.textMuted, fontWeight: '500' as const },
  timelineBarEloValue: { fontSize: 7, fontWeight: '700' as const, color: '#F59E0B' },
  timelineLegend: { flexDirection: 'row' as const, justifyContent: 'center' as const, gap: 16, marginTop: 8 },
  timelineLegendItem: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4 },
  timelineLegendDot: { width: 8, height: 8, borderRadius: 4 },
  timelineLegendText: { fontSize: 10, color: theme.textMuted, fontWeight: '600' as const },
  reverseEloBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const, gap: 8, backgroundColor: '#DC2626', paddingVertical: 12, borderRadius: 12 },
  reverseEloBtnText: { fontSize: 13, fontWeight: '700' as const, color: '#FFF' },

  // Bulk reverse ELO
  bulkReverseBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const, gap: 8, backgroundColor: '#DC2626', paddingVertical: 12, borderRadius: 12, marginTop: 8 },
  bulkReverseBtnText: { fontSize: 12, fontWeight: '700' as const, color: '#FFF' },

  // Heatmap
  heatmapContainer: { backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 12, marginBottom: 12 },

  // Geo alert rows (home city mismatch examples)
  geoAlertRow: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, marginBottom: 6 },
  geoAlertIcon: { width: 28, height: 28, borderRadius: 8, alignItems: 'center' as const, justifyContent: 'center' as const },
  geoAlertTitle: { fontSize: 13, fontWeight: '600' as const, color: theme.textPrimary },
  geoAlertMeta: { fontSize: 10, color: theme.textMuted, marginTop: 2, fontWeight: '500' as const },
  geoAlertBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  geoAlertBadgeText: { fontSize: 10, fontWeight: '800' as const },

  // Geo alert pair cards (impossible travel + teleportation)
  geoAlertPairCard: { backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 12, marginBottom: 8, borderLeftWidth: 3, borderLeftColor: '#EF4444' },
  geoAlertPairTerrain: { flex: 1, fontSize: 12, fontWeight: '700' as const, color: theme.textPrimary },
  geoAlertMetric: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  geoAlertMetricValue: { fontSize: 10, fontWeight: '800' as const },
  geoAlertPairDate: { fontSize: 9, color: theme.textMuted, fontWeight: '500' as const, marginTop: 6 },

  // Device management
  deviceSection: { marginHorizontal: 16, marginBottom: 10, backgroundColor: theme.surface, borderRadius: 16, padding: 14, ...theme.shadows.card, borderWidth: 1, borderColor: '#0EA5E9' + '15' },
  deviceHeaderRow: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10 },
  deviceIcon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center' as const, justifyContent: 'center' as const },
  deviceTitle: { fontSize: 14, fontWeight: '700' as const, color: theme.textPrimary },
  deviceSubtitle: { fontSize: 10, color: theme.textMuted, marginTop: 1 },
  deviceCard: { backgroundColor: theme.backgroundSecondary, borderRadius: 12, padding: 12, marginBottom: 6 },
  deviceUnlinkBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4, backgroundColor: '#EF444410', paddingHorizontal: 10, paddingVertical: 8, borderRadius: 10 },

  // Bulk actions bar on filtered results
  bulkActionsBar: { flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'space-between' as const, backgroundColor: theme.surface, marginHorizontal: 16, marginTop: 8, paddingHorizontal: 14, paddingVertical: 10, borderRadius: 12, borderWidth: 1, borderColor: theme.primary + '30', ...theme.shadows.card },
  bulkActionsInfo: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 6 },
  bulkActionsCount: { fontSize: 12, fontWeight: '700' as const, color: theme.primary },
  bulkActionsBtns: { flexDirection: 'row' as const, gap: 8 },
  bulkActionBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8 },
  bulkActionBtnText: { fontSize: 11, fontWeight: '700' as const },

  // Reset cooldown button (detail modal admin action)
  resetCooldownBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const, gap: 8, marginTop: 8, paddingVertical: 10, borderRadius: 10, backgroundColor: '#8B5CF615', borderWidth: 1, borderColor: '#8B5CF630' },
  resetCooldownBtnText: { fontSize: 12, fontWeight: '700' as const, color: '#8B5CF6' },

  // Undo ban toast (bulk ban)
  undoToast: { position: 'absolute' as const, left: 16, right: 16, bottom: 20, flexDirection: 'row' as const, alignItems: 'center' as const, gap: 12, backgroundColor: '#1F2937', borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, shadowColor: '#000', shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.35, shadowRadius: 12, elevation: 12, zIndex: 100 },
  undoToastIcon: { width: 32, height: 32, borderRadius: 10, backgroundColor: '#EF4444', alignItems: 'center' as const, justifyContent: 'center' as const },
  undoToastLabel: { fontSize: 13, fontWeight: '800' as const, color: '#FFF' },
  undoToastSub: { fontSize: 11, color: '#9CA3AF', marginTop: 2, fontWeight: '600' as const },
  undoToastBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 6, backgroundColor: '#EF4444', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 },
  undoToastBtnText: { fontSize: 12, fontWeight: '800' as const, color: '#FFF' },

  // Admin behavioral digest history section
  digestExportBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 8, backgroundColor: '#F43F5E15', borderWidth: 1, borderColor: '#F43F5E30' },
  digestExportBtnText: { fontSize: 10, fontWeight: '800' as const, color: '#F43F5E' },
  digestRow: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, marginBottom: 6, borderLeftWidth: 3 },
  digestUser: { fontSize: 12, fontWeight: '700' as const, color: theme.textPrimary, flex: 1 },
  digestDate: { fontSize: 9, color: theme.textMuted, fontWeight: '500' as const, marginBottom: 3 },
  digestSummary: { fontSize: 10, color: theme.textSecondary, fontWeight: '500' as const, lineHeight: 14 },
  digestStatusBadge: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 3, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 7, borderWidth: 1 },
  digestStatusText: { fontSize: 9, fontWeight: '800' as const },

  // Ban reason selector
  banReasonOption: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12, backgroundColor: theme.backgroundSecondary, borderWidth: 1.5, borderColor: theme.border },
  banReasonIcon: { width: 28, height: 28, borderRadius: 8, alignItems: 'center' as const, justifyContent: 'center' as const },
  banReasonLabel: { flex: 1, fontSize: 13, fontWeight: '600' as const, color: theme.textPrimary },

  // Statistical analysis section trigger
  statAnalysisSection: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 12, backgroundColor: theme.surface, borderRadius: 16, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: '#0EA5E930', ...theme.shadows.card },
  statAnalysisTitle: { fontSize: 14, fontWeight: '700' as const, color: theme.textPrimary },
  statAnalysisSub: { fontSize: 11, color: theme.textMuted, marginTop: 2 },

  // Benford chart
  benfordChart: { flexDirection: 'row' as const, gap: 4, alignItems: 'flex-end' as const, height: 90, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 10, marginTop: 10 },
  benfordBarCol: { flex: 1, alignItems: 'center' as const, gap: 3 },
  benfordBarWrap: { width: '100%' as const, height: 70, position: 'relative' as const, justifyContent: 'flex-end' as const },
  benfordObserved: { position: 'absolute' as const, bottom: 0, left: '20%' as any, width: '30%' as any, borderRadius: 2, backgroundColor: '#0EA5E9' },
  benfordExpected: { position: 'absolute' as const, bottom: 0, right: '20%' as any, width: '30%' as any, borderRadius: 2, backgroundColor: '#94A3B850' },
  benfordDigit: { fontSize: 9, fontWeight: '800' as const, color: theme.textSecondary },
  benfordLegend: { flexDirection: 'row' as const, gap: 12, justifyContent: 'center' as const, marginTop: 8 },

  // ELO cumulative sparkline
  eloSparkline: { flexDirection: 'row' as const, alignItems: 'flex-end' as const, height: 50, backgroundColor: theme.backgroundSecondary, borderRadius: 10, padding: 6, gap: 1 },

  // Email farm bulk ban button
  emailFarmBanBtn: { flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const, gap: 8, backgroundColor: '#DC2626', paddingVertical: 12, borderRadius: 12, marginTop: 12 },
  emailFarmBanBtnText: { fontSize: 13, fontWeight: '700' as const, color: '#FFF' },

  // Farm cluster timeline visualization
  farmTimelineRow: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 8, marginBottom: 8 },
  farmTimelineLabel: { width: 96 },
  farmTimelineEmail: { fontSize: 11, fontWeight: '600' as const, color: theme.textPrimary },
  farmTimelineCurrent: { fontSize: 8, fontWeight: '800' as const, color: '#EF4444', marginTop: 1 },
  farmTimelineBar: { flex: 1, height: 14, position: 'relative' as const },
  farmTimelineTrack: { position: 'absolute' as const, left: 0, right: 0, top: 6, height: 2, backgroundColor: theme.border, borderRadius: 1 },
  farmTimelineFill: { position: 'absolute' as const, left: 0, top: 4, height: 6, borderRadius: 3 },
  farmTimelineDot: { position: 'absolute' as const, width: 12, height: 12, borderRadius: 6, borderWidth: 2, borderColor: '#FFF', marginLeft: -6, top: 1 },
  farmTimelineOffset: { fontSize: 10, fontWeight: '800' as const, color: '#DC2626', width: 44, textAlign: 'right' as const },

  // R2 threshold alerts (statistical modal)
  r2AlertCritical: { flexDirection: 'row' as const, alignItems: 'flex-start' as const, gap: 8, backgroundColor: '#FEF2F2', borderRadius: 10, padding: 10, marginBottom: 12, borderWidth: 1, borderColor: '#FECACA' },
  r2AlertWarning: { flexDirection: 'row' as const, alignItems: 'flex-start' as const, gap: 8, backgroundColor: '#FFFBEB', borderRadius: 10, padding: 10, marginBottom: 12, borderWidth: 1, borderColor: '#FDE68A' },
  r2AlertTitle: { fontSize: 12, fontWeight: '800' as const, color: '#EF4444', marginBottom: 3 },
  r2AlertText: { fontSize: 10, color: theme.textSecondary, lineHeight: 14, marginBottom: 6 },
  r2AlertLink: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4, alignSelf: 'flex-start' as const, paddingVertical: 4, paddingHorizontal: 8, borderRadius: 6, backgroundColor: '#FFF', borderWidth: 1, borderColor: '#EF444430' },
  r2AlertLinkText: { fontSize: 9, fontWeight: '800' as const, color: '#EF4444' },

  // Overview hero (top of scroll view, always visible)
  heroSection: { marginHorizontal: 16, marginTop: 12, marginBottom: 10, backgroundColor: theme.surface, borderRadius: 16, padding: 14, borderWidth: 1, borderColor: '#EF4444' + '20', ...theme.shadows.card },
  heroHeader: { flexDirection: 'row' as const, alignItems: 'center' as const, gap: 10, marginBottom: 12 },
  heroIconWrap: { width: 36, height: 36, borderRadius: 10, backgroundColor: '#EF444415', alignItems: 'center' as const, justifyContent: 'center' as const },
  heroTitle: { fontSize: 14, fontWeight: '700' as const, color: theme.textPrimary },
  heroSub: { fontSize: 11, color: theme.textMuted, marginTop: 2, lineHeight: 15 },
  heroKpis: { flexDirection: 'row' as const, gap: 6 },
  heroKpi: { flex: 1, alignItems: 'center' as const, backgroundColor: theme.backgroundSecondary, borderRadius: 10, paddingVertical: 10, borderWidth: 1 },
  heroKpiValue: { fontSize: 20, fontWeight: '900' as const },
  heroKpiLabel: { fontSize: 9, color: theme.textMuted, marginTop: 2, fontWeight: '700' as const, textAlign: 'center' as const, textTransform: 'uppercase' as const, letterSpacing: 0.3 },
  heroCTA: { flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const, gap: 8, backgroundColor: '#EF4444', paddingVertical: 12, borderRadius: 12, marginTop: 12 },
  heroCTAText: { fontSize: 13, fontWeight: '700' as const, color: '#FFF' },
  heroActionsRow: { flexDirection: 'row' as const, gap: 8, marginTop: 10 },
  heroQuickAction: { flex: 1, flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const, gap: 5, paddingVertical: 8, borderRadius: 10, backgroundColor: theme.backgroundSecondary, borderWidth: 1, borderColor: theme.border },
  heroQuickActionText: { fontSize: 11, fontWeight: '700' as const },
});
